import { Component } from "@angular/core";

@Component({
    selector: "second",
    template: `<div class="bg-info p-a-1">Second Component</div>`
})
export class SecondComponent { }
