/*
 * Copyright (c) 1998, 2007, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */

/*
 * (C) Copyright IBM Corp. 1998 - All Rights Reserved
 *
 * The original version of this source code and documentation
 * is copyrighted and owned by IBM. These materials are provided under
 * terms of a License Agreement between IBM and Sun. This technology
 * is protected by multiple US and International patents.
 *
 * This notice and attribution to IBM may not be removed.
 *
 */

package sun.text.resources;

import sun.util.EmptyListResourceBundle;

public class FormatData_fr_LU extends EmptyListResourceBundle {
}
