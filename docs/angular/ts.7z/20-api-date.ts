// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {DateFormatPattern, DateTimeFormat, DateTimeFormatter} from './date/dateformatter';

{

  const date: Date = new Date('121');
  console.log(date);
}

/**
 *
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date
 * @see https://www.htmlgoodies.com/html5/javascript/calculating-the-difference-between-two-dates-in-javascript.html
 * @see https://docs.oracle.com/javase/7/docs/api/java/text/SimpleDateFormat.html
 * @see http://www.i-programmer.info/programming/javascript/6322-date-hacks-doing-javascript-date-calculations.html
 * @see http://slingfive.com/pages/code/jsDate/jsDate.html
 * @see https://www.htmlgoodies.com/html5/javascript/calculating-the-difference-between-two-dates-in-javascript.html
 * @see https://docs.microsoft.com/en-us/scripting/javascript/calculating-dates-and-times-javascript
 *
 * @see https://marcoscaceres.github.io/jsi18n/
 * @see http://norbertlindenberg.com/2012/12/ecmascript-internationalization-api/index.html
 * @see https://nodejs.org/api/intl.html
 *
 *
 */
class DateTimeHelper {
  private static WeekDayRange: {min: number, max: number} = {min: 1, max: 7};
  private static MonthDayRange: {min: number, max: number} = {min: 1, max: 31};
  private static MonthRange: {min: number, max: number} = {min: 1, max: 12};
  private static YearRange: {min: number, max: number} = {min: 0, max: 9999};

  /**
   *
   * @param {Date} date
   * @param {number} offset
   */
  static addDays(date: Date, offset: number) {
    date.setDate(date.getDate() + offset);
  }

  /**
   *
   * @param {Date} date
   * @param {number} offset
   */
  static addMonths(date: Date, offset: number) {
    date.setMonth(date.getMonth() + offset);
  }

  /**
   *
   * @param {Date} date
   * @param {number} offset
   */
  static addYears(date: Date, offset: number) {
    date.setFullYear(date.getFullYear() + offset);
  }


  /**
   * Removes the time component resp. zero out their parts.
   * @param {Date} date
   */
  static zeroTime(date: Date) {
    date.setHours(0, 0, 0, 0);

  }

  /**
   * Copying a date.
   * @param {Date} date
   * @returns {Date}
   */
  static clone(date: Date): Date {
    const dt: Date = new Date();
    dt.setTime(date.getTime());
    return dt;
  }


  /**
   * Calculates the difference of 2 dates in days.
   * If the second date is not provided the difference is calculated form the current date.
   * @param {Date} d1
   * @param {Date} d2 <optional>
   * @returns {number}
   */
  static diff(d1: Date, d2?: Date) {
    // Get 1 day in milliseconds
    const ref_day_ms = 1000 * 60 * 60 * 24;

    // Convert both dates to milliseconds
    let d1_ms = d1.getTime();
    let d2_ms =  d2 ? d2.getTime() : new Date().getTime();

    // Calculate the difference in milliseconds
    let diff_ms = d2_ms - d1_ms;

    // Convert back to days and return
    return Math.round(diff_ms / ref_day_ms);
  }

  /**
   * Test for the current date. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isCurrentDate(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() === d.getFullYear() &&
      curr.getMonth() === d.getMonth() &&
      curr.getDate() === d.getDate();
  }

  /**
   * Test for the current Month. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isCurrentMonth(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() === d.getFullYear() &&
      curr.getMonth() === d.getMonth();
  }

  /**
   * Test for the current Year. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isCurrentYear(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() === d.getFullYear();
  }

  /**
   * Test for the past Date. Time component is ignored.
   * @param {Date} d
   * @returns {boolean}
   */
  static isPastDate(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() >= d.getFullYear() &&
      curr.getMonth() >= d.getMonth() &&
      curr.getDate() > d.getDate();
  }

  /**
   * Test for the past Month. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isPastMonth(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() >= d.getFullYear() && curr.getMonth() > d.getMonth();
  }

  /**
   * Test for the past Year. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isPastYear(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() > d.getFullYear();
  }

  /**
   * Test for future Date. Time component is ignored.
   * @param {Date} d
   * @returns {boolean}
   */
  static isFutureDate(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() <= d.getFullYear() &&
      curr.getMonth() <= d.getMonth() &&
      curr.getDate() < d.getDate();
  }

  /**
   * Test for future Month. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isFutureMonth(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() <= d.getFullYear() && curr.getMonth() < d.getMonth();
  }

  /**
   * Test for future Year. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  static isFutureYear(d: Date) {
    const curr: Date = new Date();
    return curr.getFullYear() < d.getFullYear();
  }

  /**
   * Calculate the dates week no. of the iso year.
   * @param {Date} date
   * @returns {number}
   */
  static getWeekOfYear(date: Date) {
    // Remove time components of date
    const target: Date = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    // ISO week date weeks start on monday
    // so correct the day number
    let dayNr   = (date.getDay() + 6) % 7;
    // Set the target to the thursday of this week so the
    // target date is in the right year
    target.setDate(target.getDate() - dayNr + 3);
    // ISO 8601 states that week 1 is the week
    // with january 4th in it
    let jan4: Date    = new Date(target.getFullYear(), 0, 4);
    // Number of days between target date and january 4th
    // var dayDiff: any = (target - jan4) / 86400000;
    let dayDiff: number = DateTimeHelper.diff(jan4, target);
    // Calculate week number: Week 1 (january 4th) plus the
    // number of weeks between target date and january 4th
    let weekNr = 1 + Math.ceil(dayDiff / 7);
    return weekNr;
  }


  /**
   * Gets the current or past date for: date, date+month or date+month+year.
   * @param {number} date
   * @param {number} month
   * @param {number} year
   * @returns {Date}
   */
  static currentPastBy(date: number, month?: number, year?: number): Date {
    const curr: Date = new Date();
    const result: Date = new Date();
    let y = 0;
    let m = 0;
    let d = 0;
    if (year) {
      y = year;
      m = month;
      d = date;
    } else if (month) {
      // input -> current => computed
      // i.e. 1210 -> 091117 => 121017; 0911 -> 091117 => 091117; 0912 -> 091117 => 091216
      y = month <= curr.getMonth() ? curr.getFullYear() : curr.getFullYear() - 1;
      m = month;
      d = date;
    } else {
      // input -> current => computed
      // i.e. 08 -> 091117 => 081117; 09 -> 091117 => 091117; 11 -> 091117 => 091216
      y = curr.getFullYear();
      m = date <= curr.getDate() ? curr.getMonth() : curr.getMonth() - 1;
      d = date ;
    }
    return new Date(y, m, d, 0, 0, 0, 0);
  }

  /**
   * Gets the current or past date for: date, date+month or date+month+year.
   * @param {number} date
   * @param {number} month
   * @param {number} year
   * @returns {Date}
   */
  static currentFutureBy(date: number, month?: number, year?: number): Date {
    const curr: Date = new Date();
    const result: Date = new Date();
    let y = 0;
    let m = 0;
    let d = 0;
    if (year) {
      y = year <= curr.getFullYear() ? curr.getFullYear() : year;
      m = month <= curr.getMonth() ? curr.getMonth() : curr.getMonth() + 1;
      d = date <= curr.getDate() ? curr.getDate() : date + 1;
    } else if (month) {
      y = curr.getFullYear();
      m = month <= curr.getMonth() ? curr.getMonth() : month;
      d = date >= curr.getDate() ? curr.getDate() : curr.getDate() - 1;
    } else {
      y = curr.getFullYear();
      m = curr.getMonth();
      d = date >= curr.getDate() ? curr.getDate() : curr.getDate() - 1;
    }
    return new Date(y, m, d, 0, 0, 0, 0);
  }

  static getDayOfWeek(date: Date) {
    let dow = date.getDay();
    if (dow === 0) {
      dow = 7;
    }
    return dow;
  }

  /**
   * Returns the numeric value corresponding to the time for
   * the specified date according to universal time.
   * You can use this method to help assign a date and time to another Date object.
   * This method is functionally equivalent to the valueOf() method.
   * @param {Date} date
   * @returns {number}
   *
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getTime
   */
  static getUTCLong(date: Date): number {
    return date.getTime();
  }

  /**
   *
   * @param {Date} date
   * @returns {number}
   */
  static toNumber(date: Date): number {
    return date.valueOf();
  }
}

{
  const date: Date = new Date();
  console.log(`getDate:${date.getDate()} getUTCDate: ${date.getUTCDate()} type: ${ typeof date.getUTCDate()}`);
  console.log(`getDay:${date.getDay()} getUTCDay: ${date.getUTCDay()} type: ${ typeof date.getUTCDate()}`);
  console.log(`getMonth:${date.getMonth()} getUTCMonth: ${date.getUTCMonth()} type: ${ typeof date.getUTCMonth()}`);
  console.log(`getYear:${date.getFullYear()} getUTCFullYear: ${date.getUTCFullYear()} type: ${ typeof date.getUTCFullYear()}`);

  console.log(`getHours:${date.getHours()} getUTCDate: ${date.getUTCHours()} type: ${ typeof date.getUTCHours()}`);
  console.log(`getMinutes:${date.getMinutes()} getUTCMinutes: ${date.getUTCMinutes()} type: ${ typeof date.getUTCMinutes()}`);
  console.log(`getSeconds:${date.getSeconds()} getUTCSeconds: ${date.getUTCSeconds()} type: ${ typeof date.getUTCSeconds()}`);
  console.log(`getMilliseconds:${date.getMilliseconds()} getUTCMilliseconds: ${date.getUTCMilliseconds()} type: ${ typeof date.getUTCMilliseconds()}`);

  const utc: boolean = true;
  const _ = utc ? 'getUTC' : 'get';
  console.log(date[ _ + 'Date']());

  console.log(`DateTimeHelper.getDayOfWeek:${DateTimeHelper.getDayOfWeek(date)}`);
  console.log(`DateTimeHelper.getWeekOfYear:${DateTimeHelper.getWeekOfYear(date)}`);

  console.log('####### CALC');
  const options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  };

  let startDate: Date = new Date(1990, 1, 29);
  let endDate: Date = DateTimeHelper.clone(startDate);
  DateTimeHelper.addDays(endDate, 4);

  console.log(` OLD: year: ${startDate.getFullYear()} month: ${startDate.getMonth()} day: ${startDate.getDate()} week: ${DateTimeHelper.getWeekOfYear(startDate)} string: ${startDate}`);
  // console.log(new Intl.DateTimeFormat('en', options).format(myDate));


  console.log(` NEW: year: ${endDate.getFullYear()} month: ${endDate.getMonth()} day: ${endDate.getDate()} week: ${DateTimeHelper.getWeekOfYear(endDate)} string: ${endDate}`);
  // console.log(myDate.toDateString());
  console.log('####### diff: ' + DateTimeHelper.diff(startDate, endDate));
  console.log('####### diff current: ' + DateTimeHelper.diff(startDate));
  console.log('####### CALC');

  console.log(`utc - start: ${DateTimeHelper.getUTCLong(startDate)} utc - end: ${DateTimeHelper.getUTCLong(endDate)}`);

  console.log(`num - start: ${DateTimeHelper.toNumber(startDate)} num - end: ${DateTimeHelper.toNumber(endDate)}`);



}

{
  let refDate: Date = new Date(2017, 11, 12);
  let newDate = DateTimeHelper.currentPastBy(refDate.getDate(), refDate.getMonth());

  console.log(` ref: year: ${refDate.getFullYear()} month: ${refDate.getMonth()} day: ${refDate.getDate()}`);
  console.log(` ^new: year: ${newDate.getFullYear()} month: ${newDate.getMonth()} day: ${newDate.getDate()}`);
}

{
  console.log(DateFormatPattern.HOUR_IN_DAY_0_23);
  console.log(DateFormatPattern['HOUR_IN_DAY_0_23']);

  console.log(DateTimeFormat.DEFAULT);
  console.log(DateTimeFormat['DEFAULT']);

  let mask = 'test';
  let utc: boolean;
  let gmt: boolean;
  mask = null;
  mask = String(DateTimeFormat[mask] || mask || DateTimeFormat['DEFAULT']);
  console.log(mask);


}

{
  let refDate: Date = new Date();
  let fmt: DateTimeFormatter = new DateTimeFormatter('en_gb');
  console.log(fmt.format(refDate, 'HHmmss'));
  console.log(fmt.format(refDate, 'dd/MM/yy HH:mm'));
  console.log(fmt.format(refDate, 'MM.yyyy'));
  console.log(fmt.format(refDate, 'EEEE dd.MM.yyyy'));
}
