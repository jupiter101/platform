// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export enum DateFormatPattern {
  ERA = 'G',
  YEAR = 'y',
  MONTH = 'M',
  WEEK_IN_YEAR = 'w',
  WEEK_IN_MONTH = 'W',
  DAY_IN_YEAR = 'D',
  DAY_IN_MONTH = 'd',
  DAY_OF_WEEK_IN_MONTH = 'F',
  DAY_IN_WEEK = 'E',
  DAYLIGHT_MARKER = 'a',
  HOUR_IN_DAY_0_23 = 'H',
  HOUR_IN_DAY_1_24 = 'k',
  HOUR_IN_DAYLIGHT_0_11 = 'K',
  HOUR_IN_DAYLIGHT_1_12 = 'h',
  MINUTE = 'm',
  SECOND = 's',
  MILLISECOND = 'S',
  TIMEZONE = 'z',
  TIMEZONE_RFC822 = 'Z',
}

export enum DateTimeFormat {
  DEFAULT =               'EEE MMM dd yyyy HH:mm:ss',
  shortDate =             'M/d/yy',
  mediumDate =            'MMM d, yyyy',
  longDate =              'MMMM d, yyyy',
  fullDate =              'EEEE, MMMM d, yyyy',
  shortTime =             'h:mm TT',
  mediumTime =            'h:mm:ss TT',
  longTime =              'h:mm:ss TT Z',
  isoDate =               'yyyy-MM-dd',
  isoTime =               'HH:mm:ss',
  isoDateTime =           'yyyy-MM-dd\'T\'HH:mm:sso',
  isoUtcDateTime =        'UTC:yyyy-MM-dd\'T\'HH:mm:ss\'Z\'',
  expiresHeaderFormat =   'EEE, dd MMM yyyy HH:mm:ss Z'
}

const i18n_names: any = {
  de_de: {
    dayNames: [
      'So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa',
      'Sontag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'
    ],
    monthNames: [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez',
      'Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'
    ],
    timeNames: [
      'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
  },
  en_gb: {
    dayNames: [
      'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
      'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
    ],
    monthNames: [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
      'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
    ],
    timeNames: [
      'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
  }
};

const i18nTimeNames = (locale: string) => (index: number) => i18n_names[locale].timeNames[index];
const i18nMonthNames = (locale: string) => (index: number) => i18n_names[locale].monthNames[index];
const i18nDayNames = (locale: string) => (index: number) => i18n_names[locale].dayNames[index];
const regexp = {
  pattern: /E{3,4}|d{1,2}|M{1,4}|yy(?:yy)?|([HhmsTt])\1?|[LloSZWN]|'[^']*'|'[^']*'/g,
  timezone: /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
  timezoneClip: /[^-+\dA-Z]/g
};

const pad = (val: number, len: number = 2): string => {
  let padded = String(val);
  while (padded.length < len) {
    padded = '0' + padded;
  }
  return padded;
};

const datediff = (d1: Date, d2?: Date) => {
  return Math.round((d2 ? d2.getTime() - d1.getTime() : new Date().getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
};

const getWeekOfYear = (date: Date) => {
  const target: Date = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  target.setDate(target.getDate() - ((date.getDay() + 6) % 7) + 3);
  return 1 + Math.ceil(datediff(new Date(target.getFullYear(), 0, 4), target) / 7);
};

const getDayOfWeek = (date: Date) => date.getDay() === 7 ? 7 : date.getDay();

const adjustH = (n: number) => n % 12 || 12;
const adjustOffset = (o: number) => (o > 0 ? '-' : '+') + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4);

const patternComponents = (locale: string) => (dt: Date) => {
  const d = dt.getDate();
  const D = dt.getDay();
  const M = dt.getMonth();
  const y = dt.getFullYear();
  const H = dt.getHours();
  const m = dt.getMinutes();
  const s = dt.getSeconds();
  const L = dt.getMilliseconds();
  const o = dt.getTimezoneOffset();
  const W = getWeekOfYear(dt);
  const N = getDayOfWeek(dt);
  const timeNames = i18nTimeNames(locale);
  const monthNames = i18nMonthNames(locale);
  const dayNames = i18nDayNames(locale);
  return {
    d: dt,
    dd: pad(d),
    EEE: dayNames(D),
    EEEE: dayNames(D + 7),
    M: M + 1,
    MM: pad(M + 1),
    MMM: monthNames(M),
    MMMM: monthNames(M + 12),
    yy: String(y).slice(2),
    yyyy: y,
    h: adjustH(H),
    hh: pad(adjustH(H)),
    H: H,
    HH: pad(H),
    m: m,
    mm: pad(m),
    s: s,
    ss: pad(s),
    l: pad(L, 3),
    L: pad(Math.round(L / 10)),
    t: H < 12 ? timeNames(0) : timeNames(1),
    tt: H < 12 ? timeNames(2) : timeNames(3),
    T: H < 12 ? timeNames(4) : timeNames(5),
    TT: H < 12 ? timeNames(6) : timeNames(7),
    Z: 'GMT',
    o: adjustOffset(o),
    S: ['', 'th', 'st', 'nd', 'rd'][0],
    W: W,
    N: N
  };
};

export class DateTimeFormatter {
  private localPatternComponents: (dt: Date) => any;
  constructor(locale: string) {
    this.localPatternComponents = patternComponents(locale);
  }

  format(d: Date, pattern: string): string {
    let compiledPattern = this.localPatternComponents(d);
    // console.log(compiledPattern);
    return pattern.replace(regexp.pattern, function (match) {
      // console.log('MATCH: ' + match);
      if (match in compiledPattern) {
        return compiledPattern[match];
      }
      return match.slice(1, match.length - 1);
    });
  }
}
