// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import NumberFormat = Intl.NumberFormat;


import {DateFormatter, IFormat} from './format/dateformatter';
import {parse, ParserResult, getKernelFunction} from './format/dateparser';


// ICU: International Components for Unicode
// https://nodejs.org/api/intl.html
// https://github.com/nodejs/node/wiki/Intl
// https://www.npmjs.com/package/icu4c-data
{
  const hasICU = typeof Intl === 'object';
  console.log(hasICU ? 'Internationalization API supported!' : 'Internationalization API NOT supported!');

  const hasFullICU = (() => {
    try {
      const january = new Date(9e8);
      const spanish = new Intl.DateTimeFormat('es', { month: 'long' });
      return spanish.format(january) === 'enero';
    } catch (err) {
      return false;
    }
  })();

  console.log(hasFullICU ? 'Full ICU supported!' : 'Only small ICU (with English locale) supported!');
  console.log('Please, check https://www.npmjs.com/package/icu4c-data');

  // node --icu-data-dir=C:/Entwicklung/node/prefix/node_modules/icu4c-data -e "console.dir(new Date().toLocaleString('ru',{month:'long'}));"

  // Check version to install
  // node -e 'console.dir("npm install icu4c-data@"+process.config.variables.icu_ver_major+process.config.variables.icu_endianness)'

  // i.e. npm install -g icu4c-data@58l

  // set env.
  // NODE_ICU_DATA=C:/Entwicklung/node/prefix/node_modules/icu4c-data
  // NODE_ICU_DATA=C:/Users/stp/AppData/Roaming/npm/node_modules/icu4c-data

}


{
  const date = new Date();
  console.log(date.toLocaleDateString('de'));
}

{
  const nf: NumberFormat = new Intl.NumberFormat(undefined, {style: 'currency', currency: 'GBP'});
  console.log(nf.format(100));
}

{
  let options = {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  }, lang = ['de'],
    dates = [new Date('1.1.1'),
      new Date('2/2/2'),
      new Date('3/3/3')], date, result;

  let formatter = new Intl.DateTimeFormat(lang, options);

// loop through dates formatting each one
  for (let i = 0; i < dates.length; i++) {
    date = dates[i];
    result = formatter.format(date);
    console.log(result);
  }

  const january = new Date(9e8);
  const english = new Intl.DateTimeFormat('en', { month: 'long' });
  const spanish = new Intl.DateTimeFormat('es', { month: 'long' });

  console.log(english.format(january));
// Prints "January"
  console.log(spanish.format(january));
}

{
  let formatter: IFormat = new DateFormatter('de');
  // console.log(formatter.format(new Date(), 'yyyy-dd.MM'));
  console.log(formatter.format(new Date(), 'HH:mm'));
}

{

  let result: ParserResult = parse('12.11.2017 23:14', 'dd/MM/yyyy HH:mm');
  console.log('####### ParserResult: ');
  console.log(result);
  console.log('####### ParserResult.');

  result = parse('2.11.2 23:14', 'd/MM/y');
  console.log('####### ParserResult: ');
  console.log(result);
  console.log('####### ParserResult.');

}
