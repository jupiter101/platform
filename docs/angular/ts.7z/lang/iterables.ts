// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Arrays} from './arrays';

/**
 *
 * Hint: set compiler option "downlevelIteration": true for ES5 target and below
 * @see https://blog.mariusschulz.com/2017/06/30/typescript-2-3-downlevel-iteration-for-es3-es5
 * @see https://github.com/Microsoft/TypeScript/issues/6842
 */
export namespace Iterables {
  namespace base {
    export const list = ( iterable ) => Array.from( iterable );
  }

  /**
   * Returns the iterator for the input iterable.
   *
   * @param {Iterable} iterable - The input iterable.
   * @returns {Iterator} IterableIterator<any>
   *
   */
  const iter = ( iterable ) => iterable[Symbol.iterator]( );

  /**
   * Returns the next event of the input iterator.
   *
   * @param {Iterator} iterator - The input iterator.
   * @returns {{done: Boolean, value: Object}}
   */
  const _next = ( iterator ) => iterator.next( );

  /**
   * Yields values in a range, separated by a fixed constant called step. If
   * this step is negative, the range has to be given in reverse order, that is,
   * largest value first, smallest value second.
   *
   * @param {Number} start - The starting value.
   * @param {Number} stop - The stopping value.
   * @param {Number} step - The step value.
   * @returns {Iterator}
   */
  function* _range ( start , stop , step ) {
    if ( step < 0 ) {
      for ( ; start > stop ; start += step ) yield start ;
    }
    else {
      for ( ; start < stop ; start += step ) yield start ;
    }
  }

  /**
   * Yields values in a range, separated by a fixed constant called step. If this
   * step is negative, the range has to be given in reverse order, that is,
   * largest value first, smallest value second. Both the starting value and the
   * step value are optional. By default the starting value is <code>0</code>.
   * The default for the step value is <code>1</code>.
   *
   * @param {Number} [start=0] - The starting value.
   * @param {Number} stop - The stopping value.
   * @param {Number} [step=1] - The step value.
   * @returns {Iterator}
   */
  export const range = ( start , stop = 1 , step = 1 ) => _range( start , stop , step ) ;

  /**
   * Applies a given callable to each of the elements of the input iterable.
   *
   * @example
   * // return [ 0 , 1 , 4 , 9 ]
   * list( map( x => x**2 , range( 4 ) ) ) ;
   *
   * @param {Function} callable - The callable to use.
   * @param {Iterable} iterable - The input iterable.
   * @returns {Iterator}
   */
  export function* map ( callable , iterable ) {
    for ( let item of iterable ) yield callable( item ) ;
  }

  // TS doesn't support iterating IterableIterator with ES5 target, only strings and arrays.
  // Error: Type 'IterableIterator<any>' is not an array type or a string type
  // Solution: transpiling TS to ES6 (Target: ES6) and then ES6 to ES5

  /**
   * Zips iterables together. Yields a tuple containing the first element of each
   * iterable, then a tupe containing the second element of each iterable, etc.
   * Stops when one of the iterables runs out of elements.
   *
   * @example
   * // returns [ [ 'a' , 1 ] , [ 'b' , 2 ] , [ 'c' , 3 ] ]
   * list( _zip( [ 'abcd' , range(3) ] ) ) ;
   *
   * @param {Iterable[]} iterables - The iterables to zip.
   * @returns {Iterator}
   *
   */
  function* _zip (iterables ) {
    let iterators = base.list( map( iter , iterables ) ) ;
    if ( iterators.length === 0 ) return ;
    while ( true ) {
      let buffer = [ ] ;
      for ( let result of map( _next , iterators ) ) {
        if ( result.done ) return ;
        buffer.push( result.value ) ;
      }
      yield buffer ;
    }
  }

  /**
   * Zips iterables together. Yields a tuple containing the first element of each
   * iterable, then a tupe containing the second element of each iterable, etc.
   * Stops when one of the iterables runs out of elements.
   *
   * @example
   * // returns [ [ 'a' , 1 ] , [ 'b' , 2 ] , [ 'c' , 3 ] ]
   * list( zip( 'abcd' , range(3) ) ) ;
   *
   * @param {...Iterable} iterables - The iterables to zip.
   * @returns {Iterator}
   *
   */
  export const zip = ( ...iterables ) => _zip( iterables ) ;



}


