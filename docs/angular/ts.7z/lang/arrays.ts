// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export namespace Arrays {
  export const isArray = (value: any): boolean => Array.isArray(value);
  export const create = <T>(size: number, mapper: (v: T, i: number) => T) => Array.from<T>(new Array<T>(size), mapper);

  /**
   * Removes holes from an array.
   *
   * @example Remove NaN and undefined entries
   *
   * ```typescript
   * Arrays.removeHoles([1, NaN, 2, undefined], (v) => (!isNaN(value - parseFloat(value))) && true ));
   * ```
   *
   * @param {T[]} value
   * @param {(obj?) => boolean} predicate
   * @see http://exploringjs.com/es6/ch_arrays.html#sec_array-holes
   * @author Stephan Petzchen
   */
  export const removeHoles = <T>(value: T[], predicate: (obj?) => boolean = () => true) => value.filter(predicate);
  export const flatten = <T>(a: T[][]) => (<T[]>[]).concat(...a);

  /**
   * Returns an array containing all elements of the input iterable.
   *
   * @example
   * // return [0,1,2]
   * list( range( 3 ) ) ;
   *
   * @param {Iterable} iterable - The input iterable.
   * @returns {Array}
   *
   */
  export const list = ( iterable ) => Array.from( iterable );
}
