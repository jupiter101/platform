// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
export namespace Maps {
  // export const fromIterable = <K, V>(value: Iterable<[K, V]>): Map => new Map([...value]);
}
