// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

Date.prototype['getCentury'] = function() {
  let century: number;
  let year: number = this.getFullYear();
  if (year % 100 === 0) {
    century = year / 100;
  } else {
    century = (year / 100) + 1;
  }
  return century;
};

export {Numbers}  from './numbers';
export {Strings}  from './strings';

export {Arrays}  from './arrays';
export {Maps}  from './maps';
export {Sets}  from './sets';
export {Promises}  from './promises';
export {Observables}  from './observables';

export {Dates}  from './dates';
export {Meta}  from './meta';
export {Iterables} from './iterables';
