// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
export namespace Sets {

}
