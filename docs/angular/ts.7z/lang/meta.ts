// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export namespace Meta {
  export function addN(n) {
    const args = [];
    for (let i = 0; i < n; i++) {
      args.push('a' + i);
    }
    args.push('return ' + args.join(' + '));
    return Function.apply(null, args);
  }

  export function add() {
    let sum = 0;
    for (let i = 0; i < arguments.length; i++) {
      sum += arguments[i];
    }
    return sum;
  }

  export function stopWatch(f, n) {
    const start = Date.now();
    for (let i = 0; i < n; i++) {
      f(3, 4, 5, 6, 7);
    }
    return (Date.now() - start) / 1000;
  }
}

