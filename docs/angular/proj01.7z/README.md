# NDR MIDaS Angular Frontend with Node Backend for Testing

## Directory structure
+ src/client holds the MIDaS client frontend code
+ src/server holds the server code for backend emulation.
+ src/auth-server holds authentication server code for emulation auth2 authentication server

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.3.2.

Prerequisites:
  +  For bcrypt on Windows the windows build tools are required to build the binaries with python 2.7 and vc9.
    Open command line console as Administrator and run:
    `npm install --global --production windows-build-tools`
  + TODO: include to the maven frontend plugin, so that the build pipeline is complete for the frontend.

**Note** <br>
Always make sure you make a copy of `.env.sample`, rename it to `.env`, and add in the necessary environment variables for both the JWT secret and the MongoDB connection string.
You need to register at [mLab](https://mlab.com/) to use the testing facilities for the MongoDB Provider.

Add the necessary Map provider api keys to the MIDaS angular environment files. 
  
## Build tasks

Different `npm` scripts for the dev and deployment workflow:
  * `npm run build`: this will run a production build of the MIDaS app, and place the bundles in `dist` directory
  * `npm start`: this will run a production build of the MIDaS app, and place the bundles in `dist` directory, and then will start the Node + Express app. This is typically what you would want to do if deploying the applicaiton.
  * `npm run watch`: this will utilize webpack-dev-server to run the MIDaS app in a live development server, watching for any changes, and also start the Express app at port 3000. Since the app is running on port 4200, I supply a proxy config file to proxy all requests to `/api` to `localhost:3000/api`. Making changes to your code will live reload both the client and the server. Use this for development.
  * `npm run sample`: this will seed the mLab database with initial cities, events, statistics and users. Make sure to create the collections (cities, events, statistics, users) beforehand.


