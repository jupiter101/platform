/**
 * Node Server main module.
 * @author Stephan Petzchen
 */
const fs = require('fs');
const path = require('path');
const process = require('process');
const express = require('express');
const MongoClient = require('mongodb').MongoClient;
const createExpressApp = require('./create-express-app');

const environment = require('dotenv').config();


// Connect to database and start server process listening on port 3000
MongoClient.connect(process.env.DB_CONN, {loggerLevel: 'info'}, (err, db)=>{
  //3.1 Error handling: send status 500 with error message
  if(err){
    console.log('Error connecting to mongodb...' + err);
    return -1;
  }
  console.log('connected to mongodb...');

  createExpressApp(db).listen(3000, () => {
      console.log('listening on port 3000...');
    });
});
