/**
 * Database seed script.
 * @author Stephan Petzchen
 */
require('dotenv').config();


const users = require('./users');
const statistics = require('./stats.json');
const events = require('./events.json');
const cities = require('./cities-small.json');



const MongoClient = require('mongodb').MongoClient;
const bcrypt = require('bcrypt');

function seedCollection(name, records) {
  MongoClient.connect(process.env.DB_CONN, (err, db)=>{
    console.log('connected to mongodb...');

    const collection = db.collection(name);
    collection.deleteMany({}, function(err, result){
      console.log(`${result.deletedCount} records deleted.`);
    });

    records.forEach((item)=>{
      if(item.password){
        item.password = bcrypt.hashSync(item.password, 10);
      }
    });

    collection.insertMany(records, (err, result)=>{
      console.log(`${result.insertedCount} records inserted.`);
      console.log('Closing connection...');
      db.close();
      console.log('...DONE.');
    })
  })

}

seedCollection('users', users);
seedCollection('stats', statistics);
seedCollection('events', events);
seedCollection('cities', cities);
