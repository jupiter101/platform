/**
 * API Router.
 * @author Stephan Petzchen
 */

const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const checkJWT = require('express-jwt');

/*

JWT

A. Test your webtoken
1. jwt.io

B. Create a secret
1. www.grc.com/passwords.htm

C. node jwt lib
1. github.com/auth0/node-jsonwebtoken
2. https://github.com/auth0/express-jwt
   Middleware that validates JsonWebTokens

 */

/**
 * Defines the API routes.
 * @param database
 */
function apiRouter(database){
  const router = express.Router();

  // https://github.com/jfromaniello/express-unless
  // https://github.com/jfromaniello/express-unless/issues/13
  // /v1/geo/cities/states/:id
  router.use(checkJWT({ secret: process.env.JWT_SECRET }).unless(
    {
      path:[
        {url: '/api/v1/authenticate', methods: ['POST']},
        { url:  /^\/api\/v1\/stats\/brands\//, methods: ['GET']  },
        { url:  /^\/api\/v1\/events\/(cities|venues)\/.*/, methods: ['GET']  },
        { url:  /^\/api\/v1\/geo\/.*/, methods: ['GET']  }
      ]
    }));


  //handle middleware error
  router.use((err, req, resp, next) => {
    if(err.name === 'UnauthorizedError'){
      resp.status(401).send({error: err.message});
    }
  });


  /**
   * Request Markenstatistic
   */
  router.get('/v1/stats/brands/:ids', function(req, resp) {
    let returnDoc ={
      titel: "", type: "", state_id: "", state: "", brand: "", brand_ids: "", events: "", visitor: "",
      accompanying_media: "", costs: "", costs_per_event: "", costs_per_1k_visitor: ""
    };

    const contactsCollection = database.collection('stats');
    contactsCollection.find({ type: 'brand', brand_ids: {$in: req.params.ids.split(',')} }).toArray((err, docs)=>{

      docs.forEach(doc => {
        returnDoc.titel = returnDoc.titel===''? doc.titel : returnDoc.titel + '|' + doc.titel;
        returnDoc.type = "brand";
        returnDoc.events = Number(returnDoc.events) + Number(doc.events);
        returnDoc.visitor = Number(returnDoc.visitor) + Number(doc.visitor);
        returnDoc.accompanying_media = Number(returnDoc.accompanying_media) + Number(doc.accompanying_media);
        returnDoc.costs = Number(returnDoc.costs) + Number(doc.costs);
        returnDoc.costs_per_event = Number(returnDoc.costs_per_event) + Number(doc.costs_per_event);
        returnDoc.costs_per_1k_visitor = Number(returnDoc.costs_per_1k_visitor) + Number(doc.costs_per_1k_visitor);
      });
      return resp.json([returnDoc]);
    });
  });

  /**
   * Request Bundeslandstatistic
   */
  router.get('/v1/stats/states/:state_id', function(req, resp) {

    if( req.params.state_id){
      const contactsCollection = database.collection('stats');
      contactsCollection.find({ type: 'state', state_id:  req.params.state_id }).toArray((err, docs)=>{
        return resp.json(docs);
      });
    }
  });

  /**
   * Request Sendegebietsstatistic
   */
  router.get('/v1/stats/', function(req, resp) {
    const contactsCollection = database.collection('stats');
    contactsCollection.find({ type: 'total' }).toArray((err, docs)=>{
      return resp.json(docs);
    });

  });

  /**
   * Request Veranstaltungsinformation je Stadt
   */
  router.get('/v1/events/cities/:id', function(req, resp) {
    console.log(`/v1/events/cities/${req.params.id}`);
    console.log(`header::Midas-Access: ${req.header('Midas-Access')}`);
    const contactsCollection = database.collection('events');
    contactsCollection.find({ city_id: req.params.id }).toArray((err, docs)=>{
      return resp.json(docs);
    });

  });

  /**
   * Request Veranstaltungsinformation je Stadt und Marke
   */
  router.get('/v1/events/cities/:id/brands/:brands', function(req, resp) {
    console.log(`/v1/events/cities/${req.params.id}/brands/${req.params.brands}`);
    const contactsCollection = database.collection('events');
    contactsCollection.find({ city_id: req.params.id, brand_id: {$in: req.params.brands.split(',').map( s => Number(s))} }).toArray((err, docs)=>{
      return resp.json(docs);
    });

  });

  /**
   * Request Veranstaltungsinformation je Veranstaltungsort
   */
  router.get('/v1/events/venues/:id', function(req, resp) {
    console.log(`/v1/events/venues/${req.params.id}`);
    const contactsCollection = database.collection('events');
    contactsCollection.find({ venue_id: req.params.id }).toArray((err, docs)=>{
      return resp.json(docs);
    });

  });

  // v1/events/venues/500101/brands/8
  /**
   * Request Veranstaltungsinformation je Veranstaltungsort und Marke
   */
  router.get('/v1/events/venues/:id/brands/:brands', function(req, resp) {
    console.log(`/v1/events/venues/${req.params.id}/brands/${req.params.brands}`);
    const contactsCollection = database.collection('events');
    contactsCollection.find({ venue_id: req.params.id,
      brand_id: {$in: req.params.brands.split(',').map( s => Number(s))}}).toArray((err, docs)=>{
      return resp.json(docs);
    });

  });


  /**
   * Request spatial data for cities
   */
  router.get('/v1/geo/cities', function(req, resp) {
    console.log(`/v1/geo/cities`);

    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find({ "properties.type": "city"}).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });

  /**
   * Request spatial data for cities and brands
   */
  router.get('/v1/geo/cities/brands/:id', function(req, resp) {
    console.log(`/v1/geo/cities/brands/${req.params.id.split(',')}`);
    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find({ "properties.type": "city",
      "properties.brands": {$in: req.params.id.split(',').map( s => Number(s))}}).toArray((err, docs)=>{
      docs.forEach(doc => {
        console.log(doc);
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });

  /**
   * Request spatial data for cities in a state
   */
  router.get('/v1/geo/cities/states/:id', function(req, resp) {
    console.log(`/v1/geo/cities/states/${req.params.id}`);
    console.log(`header::Midas-Access: ${req.header('Midas-Access')}`);
    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find( {$and: [{ "properties.type": "city"} , { "properties.state_id": req.params.id}]}).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });

  /**
   * Request spatial data for cities in a state
   */
  router.get('/v1/geo/cities/states/:id/brands/:brands', function(req, resp) {
    console.log(`/v1/geo/cities/states/${req.params.id}/brands/${req.params.brands}`);

    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find( {$and: [{ "properties.type": "city"} , { "properties.state_id": req.params.id} ,
      { "properties.brands": {$in: req.params.brands.split(',').map( s => Number(s))}}]}).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });


  /**
   * Request spatial data for venues
   */
  router.get('/v1/geo/venues', function(req, resp) {
    console.log(`/v1/geo/venue`);

    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find({ "properties.type": "venue" }).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });

  /**
   * Request spatial data for venues in a state
   */
  router.get('/v1/geo/venues/states/:id', function(req, resp) {
    console.log(`/v1/geo/venues/states/${req.params.id}`);

    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find( {$and: [{ "properties.type": "venue"} , { "properties.state_id": req.params.id}]}).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });

  /**
   * Request spatial data for cities in a state
   */
  router.get('/v1/geo/venues/states/:id/brands/:brands', function(req, resp) {
    console.log(`/v1/geo/cities/states/${req.params.id}/brands/${req.params.brands}`);

    let returnDoc ={
      type: "FeatureCollection", features: []
    };

    const contactsCollection = database.collection('cities');
    contactsCollection.find( {$and: [{ "properties.type": "venue"} , { "properties.state_id": req.params.id} ,
      { "properties.brands": {$in: req.params.brands.split(',').map( s => Number(s))}}]}).toArray((err, docs)=>{
      docs.forEach(doc => {
        delete doc._id;
        returnDoc.features.push(doc);
      });

      return resp.json([returnDoc]);
    });

  });
  /**
   * Athentication service
   *
   * Test in Postman
   * Header: Content-Type: application/json
   * Body: { "username": "midas", "password": "Pt4bvZSSI4KN4g"}
   */
  router.post('/v1/authenticate', (req, resp) => {
    const user = req.body;
    const userCollection = database.collection('users');
    userCollection.findOne(
      { username: user.username}, (err, result) => {
        if(!result){
          return resp.status(404).json({error:'User not found.'})
        }

        if(!bcrypt.compareSync(user.password, result.password)){
          return resp.status(404).json({error:'Invalid password.'})
        }

        const payload = {
          username: result.username,
          admin: result.admin
        };

        const expiration = 60*60; // 1 houre in seconds
        const curDate = new Date();
        const expirationDate = new Date();

        expirationDate.setTime(expirationDate.getTime() + expiration*1000); // MS since 1. Januar 1970, 00:00:00 UTC
        // console.log('curTime(ms): '+curDate.getTime());
        // console.log('expirationTime(ms): '+expirationDate.getTime());
        // console.log('diff (ms): '+ (expirationDate.getTime() - curDate.getTime()));
        // console.log('diff (sec): '+ ((expirationDate.getTime() - curDate.getTime())/1000));
        // console.log('expiration(sec): '+expiration);
        const jwtoken = jwt.sign(payload, process.env.JWT_SECRET, {expiresIn: expiration});

        return resp.json({
          message: 'successfully authenticated.',
          token: jwtoken,
          iat: curDate.getTime(),
          expAt: expirationDate.getTime(),
          scope: (result.admin? 'midas': 'ndr')
        });


      });

  });

  return router;
}

module.exports = apiRouter;
