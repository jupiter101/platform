/**
 * Express App Module: Function to create the Express App with the necessary API Routing.
 * @author Stephan Petzchen
 */
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const apiRouter = require('./api-router');

function createExpressApp(database){
  const app = express();

  // experimental: app.basepath = '/midasGeo';

  app.use(express.static(path.join(__dirname, '../../dist')));

  //activate express middleware: body-parser
  app.use(bodyParser.json());

  // API routes
  app.use('/api', apiRouter(database));

  // Wildcard route: fallback when no route match for single-page-app
  app.get('*', (req, resp) => {
    // resp.sendFile(path.join(__dirname,'public/index.html'));
    resp.sendFile(path.join(__dirname,'../../dist/index.html'));
  });

  return app;
}

module.exports = createExpressApp;
