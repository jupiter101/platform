// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  apiUrl: '/api/v1',
  imageBasePath: '/midasGeo/assets/themes/default/assets/images/',
  zoom: 7,
  minZoom: 7,
  maxZoom: 14,
  maxBounds: [[55.254077, 15.106201], [51.200000, 5.888672]],
  center: {lat: 52.994950, lng: 13.305176},
  MapBox_apiKey: 'pk.eyJ1IjoibmRybWFwIiwiYSI6ImNpbDBzZzVmYTAwOGt3eG00Nml5dG82aHUifQ.EIafRePfFSmfsgjaDWNyPg'
};
