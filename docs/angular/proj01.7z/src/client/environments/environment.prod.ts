export const environment = {
  production: true,
  apiUrl: '/midasGeo/api/v1',
  imageBasePath: '/midasGeo/assets/themes/default/assets/images/',
  zoom: 7,
  minZoom: 7,
  maxZoom: 14,
  maxBounds: [[55.254077, 15.106201], [51.200000, 5.888672]],
  center: {lat: 52.994950, lng: 13.305176},
  MapBox_apiKey: 'pk.eyJ1IjoibmRybWFwIiwiYSI6ImNpbDBzZzVmYTAwOGt3eG00Nml5dG82aHUifQ.EIafRePfFSmfsgjaDWNyPg'
};
