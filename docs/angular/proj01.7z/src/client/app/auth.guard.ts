import {Inject, Injectable} from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
// import { AuthService} from './spi/impl/auth.service';
import {IAuthService} from './spi/auth.service.spi';

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(@Inject('IAuthService') private auth: IAuthService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    if (this.auth.isLoggedIn()) {
      return true;
    }else {
      this.router.navigate(['/login']);
      return false;
    }

  }
}
