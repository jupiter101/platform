import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
// import {AuthService} from '../spi/impl/auth.service';
import {Router} from '@angular/router';
import {IAuthService} from '../spi/auth.service.spi';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit, OnDestroy {
  isLoggedIn = false;
  subscription: any;

  constructor(@Inject('IAuthService') private auth: IAuthService, private router: Router) { }

  ngOnInit() {
    this.subscription = this.auth.AuthEvent
      .subscribe(item => this.isLoggedIn = item);
    this.isLoggedIn = this.auth.isLoggedIn();
  }

  onLogout(event: Event) {
    this.auth.logout();
    this.isLoggedIn = false;
    this.router.navigate(['/login']);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
