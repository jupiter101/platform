// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {EventAggregationType, IEvent} from '../model/event.model';
import {MD_DIALOG_DATA, MdDialogRef} from '@angular/material';
import {Subscription} from 'rxjs/Subscription';
import {IDialogEventParameter} from '../../spi/dialog.service.spi';
import {IEventApiService} from '../../spi/event-api.service.spi';
import {EventsParameterType} from '../../spi/impl/EventsDialogEventParameter';
import {IAuthService} from '../../spi/auth.service.spi';

/**
 *
 *
 * @see https://material.angular.io/components/grid-list/examples
 * @see https://www.tutorialspoint.com/angular_material/angular_material_grids.htm
 * @see https://github.com/angular/material2/blob/master/src/demo-app/grid-list/grid-list-demo.html
 */
@Component({
  selector: 'app-event-dialog',
  templateUrl: './event-dialog.component.html',
  styleUrls: ['./event-dialog.component.scss']
})
export class EventDialogComponent implements OnInit, OnDestroy {
  loading = false;
  isLoggedIn = false;
  subscription: Subscription;
  titel: string;
  events: IEvent[];

  constructor(@Inject(MD_DIALOG_DATA) private data: IDialogEventParameter<EventDialogComponent>,
              @Inject('IAuthService') private auth: IAuthService,
              @Inject('IEventApiService') private eventApiService: IEventApiService) {
    this.loading = true;
    this.isLoggedIn = auth.isLoggedIn();
  }

  ngOnInit() {
    this.titel = (<EventsParameterType>this.data.parameter).ref.name;

    const brands = ((<EventsParameterType>this.data.parameter).brandFilter) ?
      (<EventsParameterType>this.data.parameter).brandFilter.getSelectedList() : '';
    switch (<EventAggregationType>this.data.viewType) {
      case EventAggregationType.CITY:
        this.subscription = this.eventApiService.getCityEvents(
          (<EventsParameterType>this.data.parameter).ref.id, brands)
          .subscribe(data => {
            this.events = data;
            this.titel = (this.events.length > 0) ? this.events[0].city : (<EventsParameterType>this.data.parameter).ref.name;
            this.loading = false;
        });
        break;
      case EventAggregationType.VENUE:
        this.subscription = this.eventApiService.getVenueEvents(
          (<EventsParameterType>this.data.parameter).ref.id,
          brands)
            .subscribe(data => {
              this.events = data;
              this.titel = (this.events.length > 0) ? `${this.events[0].city}: ${this.events[0].venue}` :
                (<EventsParameterType>this.data.parameter).ref.name;
              this.loading = false;
        });
        break;
      default:
        throw new Error('Invalid argument!');
    }

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
