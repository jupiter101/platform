import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StatDialogComponent } from './stat-dialog.component';

describe('StatPopComponent', () => {
  let component: StatDialogComponent;
  let fixture: ComponentFixture<StatDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StatDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StatDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
