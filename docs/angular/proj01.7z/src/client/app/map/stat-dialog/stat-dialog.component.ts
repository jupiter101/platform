import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {MD_DIALOG_DATA} from '@angular/material';
import {Subscription} from 'rxjs/Subscription';
import 'rxjs/add/operator/share';

import {IStatistics, StatisticsType} from '../model/stat.model';
import {IStatisticApiService} from '../../spi/statistic-api.service.spi';
import {IDialogEventParameter} from '../../spi/dialog.service.spi';
import {IStateFilterItem} from '../model/state-filter.model';
import {IBrandFilter} from '../model/brand-filter.model';

/**
 * Statistic Dialog Component.
 * @author Stephan Petzchen
 *
 */
@Component({
  selector: 'app-stat-dialog',
  templateUrl: './stat-dialog.component.html',
  styleUrls: ['./stat-dialog.component.scss']
})
export class StatDialogComponent implements OnInit, OnDestroy {
  loading = false;
  statistics: IStatistics;
  subscription: Subscription;


  /**
   * Statistic Dialog Component constructor.
   * @param {IDialogEventParameter<StatDialogComponent>} data provided parameter data to retrieve the statistic data
   *                                                     with the IStatisticApiService service.
   * @param {IStatisticApiService} statApiService statistic api service
   *
   * @author Stephan Petzchen
   */
  constructor(@Inject(MD_DIALOG_DATA) private data: IDialogEventParameter<StatDialogComponent>,
              @Inject('IStatisticApiService') private statApiService: IStatisticApiService) {
    this.loading = true;
  }

  /**
   * Initialize the dialog by retrieving the presented data first.
   */
  ngOnInit() {

    switch (<StatisticsType>this.data.viewType) {
      case StatisticsType.Area:
        this.subscription = this.statApiService.getAreaStatistics().subscribe(data => {
          this.statistics = data.length > 0 ? data[0] : null;
          this.loading = false;
        });
        break;
      case StatisticsType.State:
        this.subscription = this.statApiService.getStateStatistics((<IStateFilterItem>this.data.parameter).state.id)
          .subscribe(data => {
            this.statistics = data.length > 0 ? data[0] : null;
            this.loading = false;
        });
        break;
      case StatisticsType.Brand:
        this.subscription = this.statApiService.getBrandStatistics((<IBrandFilter>this.data.parameter).getSelectedList())
          .subscribe(data => {
            this.statistics = data.length > 0 ? data[0] : null;
            this.loading = false;
        });
        break;
      default:
        throw new Error('Invalid argument!');
    }

  }

  /**
   * Unsubscribe to the event subscription.
   */
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }


}
