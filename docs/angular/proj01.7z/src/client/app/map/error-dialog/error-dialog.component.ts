// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnInit} from '@angular/core';
import {MD_DIALOG_DATA} from '@angular/material';
import {IDialogEventParameter} from '../../spi/dialog.service.spi';
import {ErrorDialogEventParameter, ErrorParameterType} from '../../spi/impl/ErrorDialogEventParameter';
import {ErrorType} from '../model/error.model';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.scss']
})
export class ErrorDialogComponent implements OnInit {
  loading = false;
  titel: string;
  errMessage: string;

  constructor(@Inject(MD_DIALOG_DATA) private data: IDialogEventParameter<ErrorDialogEventParameter>) {
    this.loading = true;
  }

  ngOnInit() {
    const vt: ErrorType = this.data.parameter.viewType;
    switch (vt) {
      case ErrorType.Network:
        this.titel = 'Netzwerkfehler';
        break;
      default:
        this.titel = 'Interner Fehler';
    }

    this.errMessage = (<ErrorParameterType>this.data.parameter).errMessage;
    this.loading = false;
  }

}
