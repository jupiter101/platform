// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Native} from './map-native';
import {IMapProviderFactory, MapProviderFactory, MapProviderType} from './map-provider';

/**
 * Map Control Interface
 * @author Stephan Petzchen
 */
export interface IMapControl {
  init();
}

/**
 * Map Layer Control.
 * @author Stephan Petzchen
 *
 * @see http://leafletjs.com/reference-1.1.0.html#layerscontrolevent
 * @see http://leafletjs.com/reference-1.1.0.html#event
 */
export class LayerControl implements IMapControl {

  static of(map: Native.Leaflet.Map, baseMaps: any, overlays: any) {
    return new LayerControl(map, baseMaps, overlays);
  }

  constructor(private map: Native.Leaflet.Map, private baseMaps: any, private overlays: any) {}
  init() {
    Native.Leaflet.control.layers(this.baseMaps, this.overlays, {position: 'topleft'}).addTo(this.map);
    return this;
  }
}

/**
 * Map Zoom Control
 * @author Stephan Petzchen
 */
export class ZoomControl implements IMapControl {
  static of(map: Native.Leaflet.Map) {
    return new ZoomControl(map);
  }
  constructor(private map: Native.Leaflet.Map) {}
  init() {
    Native.Leaflet.control.zoom({ position: 'topleft' }).addTo(this.map);
    return this;
  }
}

