// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {IMapFeatureGroup} from './map-feature-group.spi';
import {Native} from '../map-native';
import {IStateFilterItem} from '../../model/state-filter.model';

export interface IAreaFeatureGroup extends IMapFeatureGroup {
  render(map: Native.Leaflet.Map): this;
  setStateVisibility(stateFilterItem: IStateFilterItem);
  destroy();
  removeLayers();
}
