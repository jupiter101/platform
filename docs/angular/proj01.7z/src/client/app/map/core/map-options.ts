// tslint:disable:no-trailing-whitespace
import {Native} from './map-native';
import {environment} from '../../../environments/environment';
import {IMapProviderFactory, MapProviderFactory, MapProviderType} from './map-provider';

const providerFactory: IMapProviderFactory = new MapProviderFactory();
const OSM = providerFactory.get(MapProviderType.OSM);
const MAPBOX = providerFactory.get(MapProviderType.MapBox);
const CartoDB = providerFactory.get(MapProviderType.CartoDB);
const HERE = providerFactory.get(MapProviderType.HERE);

/**
 * Base maps structure.
 * @type {{OpenStreetMap: L.TileLayer; OpenStreetMap_BlackAndWhite: L.TileLayer; MapBox: L.TileLayer}}
 *
 * @author Stephan Petzchen
 */
const baseMaps: any = {
  OpenStreetMap: Native.Leaflet.tileLayer(OSM.url, {
    attribution: OSM.options.attribution
  }),
  OpenStreetMap_BlackAndWhite: Native.Leaflet.tileLayer(OSM.variants.BlackAndWhite.url, {
    attribution: OSM.options.attribution
  }),
  MapBox:  Native.Leaflet.tileLayer(MAPBOX.url, MAPBOX.options),
  CartoDB:  Native.Leaflet.tileLayer(CartoDB.url, CartoDB.options),
  OpenTopoMap:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.OpenTopoMap).url,
    providerFactory.get(MapProviderType.OpenTopoMap).options),
  Thunderforest:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.Thunderforest).url,
    providerFactory.get(MapProviderType.Thunderforest).options),
  OpenMapSurfer:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.OpenMapSurfer).url,
    providerFactory.get(MapProviderType.OpenMapSurfer).options),
  Esri:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.Esri).url,
    providerFactory.get(MapProviderType.Esri).options),
  HERE:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.HERE).url,
    providerFactory.get(MapProviderType.HERE).options),
  MtbMap:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.MtbMap).url,
    providerFactory.get(MapProviderType.MtbMap).options),
  HikeBike:  Native.Leaflet.tileLayer(providerFactory.get(MapProviderType.HikeBike).url,
    providerFactory.get(MapProviderType.HikeBike).options)
};

/**
 * Map Default option interface
 *
 * @author Stephan Petzchen
 */
interface MapOptions {
  preferCanvas?: boolean;

  // Control options
  attributionControl?: boolean;
  zoomControl?: boolean;

  // Interaction options
  closePopupOnClick?: boolean;
  zoomSnap?: number;
  zoomDelta?: number;
  trackResize?: boolean;
  boxZoom?: boolean;
  doubleClickZoom?: Native.Leaflet.Zoom;
  dragging?: boolean;

  // Map state options
  crs?: Native.Leaflet.CRS;
  center?: Native.Leaflet.LatLngExpression;
  zoom?: number;
  minZoom?: number;
  maxZoom?: number;
  layers?: Native.Leaflet.Layer[];
  maxBounds?: Native.Leaflet.LatLngBoundsExpression;
  renderer?: Native.Leaflet.Renderer;

  // Animation options
  fadeAnimation?: boolean;
  markerZoomAnimation?: boolean;
  transform3DLimit?: number;
  zoomAnimation?: boolean;
  zoomAnimationThreshold?: number;

  // Panning inertia options
  inertia?: boolean;
  inertiaDeceleration?: number;
  inertiaMaxSpeed?: number;
  easeLinearity?: number;
  worldCopyJump?: boolean;
  maxBoundsViscosity?: number;

  // Keyboard navigation options
  keyboard?: boolean;
  keyboardPanDelta?: number;

  // Mousewheel options
  scrollWheelZoom?: Native.Leaflet.Zoom;
  wheelDebounceTime?: number;
  wheelPxPerZoomLevel?: number;

  // Touch interaction options
  tap?: boolean;
  tapTolerance?: number;
  touchZoom?: Native.Leaflet.Zoom;
  bounceAtZoomLimits?: boolean;
}

/**
 * MapDefaultOption type
 * @type {{zoomControl: boolean;
 *        maxBounds: Native.Leaflet.LatLngBoundsExpression;
 *        center: Native.Leaflet.LatLngExpression;
 *        zoom: number; minZoom: number;
 *        maxZoom: number;
 *        layers: Native.Leaflet.Layer[]}}
 *
 * @author Stephan Petzchen
 */
const DefaultOptions = {
  zoomControl: false,
  maxBounds: <Native.Leaflet.LatLngBoundsExpression>environment.maxBounds,
  center: <Native.Leaflet.LatLngExpression>environment.center,
  zoom: environment.zoom,
  minZoom: environment.minZoom,
  maxZoom: environment.maxZoom,
  layers: <Native.Leaflet.Layer[]>[]
};

/**
 * Default export Map options structure with basemaps and MapDefaultOptions.
 *
 * @author Stephan Petzchen
 */
export default {
  options: DefaultOptions,
  baseMaps:  baseMaps,
  setDefaultProvider: (provider) => { DefaultOptions.layers.push(provider); }
};


