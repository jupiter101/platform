// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {ICity} from '../model/city.model';
import {Native} from './map-native';


export class MapCityLayer extends Native.Leaflet.Marker {
  constructor(
              private city: ICity,
              latlng: Native.Leaflet.LatLngExpression,
              options?: any) {
    super(latlng, options);

  }

  get City(): ICity { return this.city; }

  setVisibility(map: Native.Leaflet.Map, flag: boolean) {
  }

  removeLayers(): void {
  }
}
