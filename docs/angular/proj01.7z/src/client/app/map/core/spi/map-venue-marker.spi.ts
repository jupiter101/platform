// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Native} from '../map-native';
import {IMapMarker} from './map-marker.spi';
import {IVenue} from '../../model/venue.model';

export interface IVenueMapMarkerOptions {
  markerOptions?: Native.Leaflet.MarkerOptions;
}

export interface IVenueMapMarker extends IMapMarker {
  Venue: IVenue;
  options: IVenueMapMarkerOptions;
}
