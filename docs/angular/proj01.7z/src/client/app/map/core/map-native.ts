// tslint:disable:no-trailing-whitespace
import 'leaflet';

/**
 *  Native namespace for the leaflet library.
 * @author Stephan Petzchen
 */
export namespace Native {
  export namespace Leaflet {
    export type Map = L.Map;

    export type Renderer = L.Renderer;
    export type Point = L.Point;
    export type PointTuple = L.PointTuple;
    export type LatLng = L.LatLng;
    export type LatLngExpression = L.LatLngExpression;
    export type LatLngBounds = L.LatLngBounds;
    export type LatLngBoundsExpression = L.LatLngBoundsExpression;
    export type Direction = L.Direction;
    // TODO DEPRECATED
    export type DefaultMapPanes = L.DefaultMapPanes;

    export type Event = L.Event;
    export type KeyboardEvent = L.KeyboardEvent;
    export type MouseEvent = L.MouseEvent;
    export type LocationEvent = L.LocationEvent;
    export type ErrorEvent = L.ErrorEvent;
    export type LayerEvent = L.LayerEvent;
    export type LayersControlEvent = L.LayersControlEvent;
    export type TileEvent = L.TileEvent;
    export type TileErrorEvent = L.TileErrorEvent;
    export type ResizeEvent = L.ResizeEvent;
    export type GeoJSONEvent = L.GeoJSONEvent;
    export type PopupEvent = L.PopupEvent;
    export type TooltipEvent = L.TooltipEvent;
    export type DragEndEvent = L.DragEndEvent;
    export type ZoomAnimEvent = L.ZoomAnimEvent;

    // TODO DEPRECATED
    export type InteractiveLayerOptions = L.InteractiveLayerOptions;
    export type PathOptions = L.PathOptions;
    export type MarkerOptions = L.MarkerOptions;
    // TODO DEPRECATED
    export type DivOverlayOptions = L.DivOverlayOptions;
    export type TooltipOptions = L.TooltipOptions;
    export type GeoJSONOptions = L.GeoJSONOptions;

    export type Pane = HTMLElement;
    export type Content = string | HTMLElement;

    export type CRS = L.CRS;
    export type Zoom = L.Zoom;

    // TODO DEPRECATED
    export type EventHandlerFn = L.EventHandlerFn;

    export type StyleFunction = L.StyleFunction;

    export class GeoJSON extends L.GeoJSON {}
    export class Layer extends L.Layer {}
    export class LayerGroup extends L.LayerGroup {}
    export class FeatureGroup extends L.FeatureGroup {}
    export class Marker extends L.Marker {}
    export class Icon extends L.Icon {}
    export class DivIcon extends L.DivIcon {}
    export class Tooltip extends L.Tooltip {}
    export class Handler extends L.Handler {}




    export const map = L.map;
    // TODO DEPRECATED
    export const geoJSON = L.geoJSON;
    export const tileLayer = L.tileLayer;
    export const marker = L.marker;
    export const icon = L.icon;
    export const divIcon = L.divIcon;

    export namespace control {
      export const layers = L.control.layers;
      // TODO DEPRECATED
      export const attribution = L.control.attribution;
      export const zoom = L.control.zoom;
      // TODO DEPRECATED
      export const scale = L.control.scale;
    }

    // L.Zoom
  }

}




export type MapPoint = Native.Leaflet.Point | Native.Leaflet.PointTuple;
export type MapEvent =  Native.Leaflet.Event | Native.Leaflet.KeyboardEvent | Native.Leaflet.MouseEvent |
  Native.Leaflet.LocationEvent | Native.Leaflet.ErrorEvent | Native.Leaflet.LayerEvent |
  Native.Leaflet.LayersControlEvent | Native.Leaflet.TileEvent | Native.Leaflet.TileErrorEvent |
  Native.Leaflet.ResizeEvent | Native.Leaflet.GeoJSONEvent | Native.Leaflet.PopupEvent |
  Native.Leaflet.TooltipEvent | Native.Leaflet.DragEndEvent | Native.Leaflet.ZoomAnimEvent;





