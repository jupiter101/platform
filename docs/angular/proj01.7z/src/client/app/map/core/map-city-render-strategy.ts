// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IMapRenderStrategy} from './spi/map-render-strategy.spi';
import {Native} from './map-native';
import {IMapPane} from './spi/map-pane';
import {IState} from '../model/state.model';
import {IDialogService} from '../../spi/dialog.service.spi';
import {EventDialogComponent} from '../event-dialog/event-dialog.component';
import {IconMapMarker, TextMapMarker} from './map-marker';
import {MapEventsGroup} from './map-events-group';
import {IEventsFeatureGroup} from './spi/map-events-group.spi';

export class MapCityRenderStrategy implements IMapRenderStrategy {

  constructor(private state: IState,
              private pane: IMapPane,
              private evdialogService: IDialogService<EventDialogComponent>) {
  }

  render(data?: any): IEventsFeatureGroup {
    const state = this.state;
    const evtDialogService = this.evdialogService;
    const pane = this.pane;

    return <IEventsFeatureGroup> new MapEventsGroup(this.state, data, {
      pane: pane.id,
      pointToLayer: function(feature, latlng) {
        const marker: Native.Leaflet.Marker =  new TextMapMarker(evtDialogService).get(latlng,
          feature.properties['city'],
          feature.properties['id'], 'city',
          {
            pane: pane.id,
            offset: [0, 0], // offset: [-5, -20],
            direction: 'center',
            permanent: true,
            sticky: false,
            interactive: false,
            opacity: 1.0,
            className: 'leaflet-tooltip-text'
          });

        return marker;

      },
      // TODO DEPRECATED
      onEachFeature: function(feature, layer) {
        // console.log(layer);
        // console.log(feature);
        // layer.bindPopup(feature.properties.city);
      }
    });
  }
}
