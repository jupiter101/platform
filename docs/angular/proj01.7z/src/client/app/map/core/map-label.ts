// tslint:disable:no-trailing-whitespace

import {MapPoint, Native} from './map-native';
import {IMapEventHandler} from './map-event';
import {MapIcon} from './map-icon';


interface IMapDivOverlayOptions {
  offset?: MapPoint;
  zoomAnimation?: boolean;
  className?: string;
  pane?: string;
}

export interface IMapLabelOptions extends IMapDivOverlayOptions {
  pane?: string;
  offset?: MapPoint;
  direction?: Native.Leaflet.Direction;
  permanent?: boolean;
  sticky?: boolean; // If true, the tooltip will follow the mouse instead of being fixed at the feature center.
  interactive?: boolean; // If true, the tooltip will listen to the feature events.
  opacity?: number; // Tooltip container opacity (makes label transparent with 0.0).
  className: string;
}

const defaultOptions = <IMapLabelOptions>{
  offset: [0, 0], // offset: [-5, -20],
  direction: 'center',
  permanent: true,
  sticky: false,
  interactive: false,
  opacity: 1.0,
  className: 'leaflet-tooltip-text'
};

export interface IMapLabel {
  text: string;
  options: IMapLabelOptions;
}

export class MapLabel implements IMapLabel {
  text: string;
  options: IMapLabelOptions;

  static of(coord: Native.Leaflet.LatLngExpression, text: string,
            options?: IMapLabelOptions,
            handler?: IMapEventHandler[]): Native.Leaflet.Marker {

    const marker = L.marker(coord, {
      icon: MapIcon.getDefault(),
      opacity: 0.0
    });

    marker.bindTooltip(text, (options ? options : defaultOptions));
    if (handler) {
      handler.forEach( h => marker.on(h.type, h.fn));
    }

    return marker;

  }

  constructor(text: string, options?: IMapLabelOptions) {
    this.text = text;
    this.options = (options ? options : defaultOptions);
  }
}
