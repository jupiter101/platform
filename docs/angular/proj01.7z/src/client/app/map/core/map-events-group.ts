// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from './map-native';
import {IEventsFeatureGroup} from './spi/map-events-group.spi';
import {IState} from '../model/state.model';

export class MapEventsGroup extends Native.Leaflet.GeoJSON implements IEventsFeatureGroup {

  constructor(private state: IState, geojson?: any, options?: Native.Leaflet.GeoJSONOptions) {
    super(geojson, options);
  }


  get State(): IState { return this.state; }

  removeLayers() {
  }
}
