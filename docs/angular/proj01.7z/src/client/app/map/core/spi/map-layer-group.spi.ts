// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Native} from '../map-native';
import {IMapLayer} from './map-layer.spi';

export interface IMapLayerGroup extends IMapLayer {
  /**
   * Adds the given layer to the group.
   */
  addLayer(layer: Native.Leaflet.Layer): this;

  /**
   * Removes the layer with the given internal ID or the given layer from the group.
   */
  removeLayer(layer: number | Native.Leaflet.Layer): this;

  /**
   * Returns true if the given layer is currently added to the group.
   */
  hasLayer(layer: Native.Leaflet.Layer): boolean;

  /**
   * Removes all the layers from the group.
   */
  clearLayers(): this;

  /**
   * Calls methodName on every layer contained in this group, passing any additional parameters.
   * Has no effect if the layers contained do not implement methodName.
   */
  invoke(methodName: string, ...params: any[]): this;

  /**
   * Iterates over the layers of the group,
   * optionally specifying context of the iterator function.
   */
  eachLayer(fn: (layer: Native.Leaflet.Layer) => void, context?: any): this;

  /**
   * Returns the layer with the given internal ID.
   */
  getLayer(id: number): Native.Leaflet.Layer | undefined;

  /**
   * Returns an array of all the layers added to the group.
   */
  getLayers(): Native.Leaflet.Layer[];

  /**
   * Calls setZIndex on every layer contained in this group, passing the z-index.
   */
  setZIndex(zIndex: number): this;

  /**
   * Returns the internal ID for a layer
   */
  getLayerId(layer: Native.Leaflet.Layer): number;

  // feature?: GeoJSONFeatureCollection<GeoJSONGeometryObject> | GeoJSONFeature<GeoJSONMultiPoint> | GeoJSONGeometryCollection;
}
