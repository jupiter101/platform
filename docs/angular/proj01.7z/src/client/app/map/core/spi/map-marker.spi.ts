// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from '../map-native';
import {IMapLayer} from './map-layer.spi';

export interface IMapMarker extends IMapLayer {
  options: Native.Leaflet.MarkerOptions;
  dragging?: Native.Leaflet.Handler;
  constructor(latlng: Native.Leaflet.LatLngExpression, options?: Native.Leaflet.MarkerOptions);
  getLatLng(): Native.Leaflet.LatLng;
  setLatLng(latlng: Native.Leaflet.LatLngExpression): this;
  setZIndexOffset(offset: number): this;
  setIcon(icon: Native.Leaflet.Icon | Native.Leaflet.DivIcon): this;
  setOpacity(opacity: number): this;
  getElement(): HTMLElement | undefined;
}
