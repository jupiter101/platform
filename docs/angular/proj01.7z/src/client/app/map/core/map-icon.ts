// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import { environment} from '../../../environments/environment';
import {Native} from './map-native';

export enum MapIconType {
  RASTER,
  SVG,
  DIV,
  NDR,
  DIVText
}

/**
 *
 * @todo Replace default marker icon
 *
 * @see https://github.com/Leaflet/Leaflet/issues/4604
 */
export class MapIcon {
  private static defaultIcon: Native.Leaflet.Icon = Native.Leaflet.icon({
    iconUrl: `${environment.imageBasePath}/marker-icon.png`,
    iconSize: [31, 41], // size of the icon
    iconAnchor: [15, 20], // point of the icon which will correspond to marker's location
    popupAnchor: [0, -10]  // point from which the popup should open relative to the iconAnchor
  });


  static of(type: MapIconType, options?) {
    switch (type) {
      // TODO DEPRECATED
      case MapIconType.DIVText:
        return Native.Leaflet.divIcon({
          iconSize: [40, 40],
          iconAnchor: [20, 40],
          popupAnchor: [1, -34],
          className: 'leaflet-venue-image',
          // html: `<img class="leaflet-venue-image" src="${environment.imageBasePath}/ndr-marker-icon.png"/>
          // <span class="leaflet-venue-image-span"></span>`
        });
      // TODO DEPRECATED
      case MapIconType.DIV:
        return Native.Leaflet.divIcon({
          iconSize: [14, 14],
          className: `${(options) ? options.classNames : 'leaflet-pulsing-icon leaflet-pulsing-icon-blue'}`
        });

      case MapIconType.NDR:
        return Native.Leaflet.divIcon({
          iconSize: [52, 32],
          className: `${(options) ? options.classNames : 'leaflet-venue-image'}`
        });

      // TODO DEPRECATED
      case MapIconType.RASTER:
        return  Native.Leaflet.icon({
          iconUrl: `${environment.imageBasePath}/ndr-marker-icon.png`,
          // iconRetinaUrl: 'marker-icon-2x.png',
          iconSize: [40, 40],
          iconAnchor: [20, 40],
          popupAnchor: [1, -34],
          // shadowUrl: 'marker-shadow.png',
          shadowSize:  [41, 41]
        });
      // TODO DEPRECATED
      case MapIconType.SVG:
        const CustomIcon = Native.Leaflet.Icon.extend({
          options: {
            iconSize:     [41, 41],
            // shadowSize:   [50, 64],
            // iconAnchor:   [22, 94],
            // shadowAnchor: [4, 62],
            popupAnchor:  [1, -40]
          }
        });

        const svgrect = `<svg xmlns='http://www.w3.org/2000/svg'>
                            <rect x='0' y='0' width='10' height='10' fill='#5d52cf' fill-opacity='0.8' ></rect>
                            <rect x='10' y='0' width='10' height='10' fill='#5a7cd2'fill-opacity='0.5'></rect>
                         </svg>`;
        const url = encodeURI('data:image/svg+xml,' + svgrect).replace('#', '%23');

        return new CustomIcon({iconUrl: url});
      default:
        throw new Error('MapIcon Error');
    }
  }

  static getDefault(): Native.Leaflet.Icon {
    return MapIcon.defaultIcon;
  }

  constructor() {
    L.Icon.Default.imagePath = environment.imageBasePath;
  }
}
