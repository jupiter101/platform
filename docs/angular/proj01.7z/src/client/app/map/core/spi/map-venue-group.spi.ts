// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {IMapFeatureGroup} from './map-feature-group.spi';
import {IVenue} from '../../model/venue.model';

/**
 * Holds the layers and features of a city.
 */
export interface IVenueFeatureGroup extends IMapFeatureGroup {
  Venue: IVenue;
  removeLayers();
}
