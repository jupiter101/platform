// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Native} from '../map-native';
import {IEventsFeatureGroup} from './map-events-group.spi';

export interface IMapRenderStrategy {
  render(content?: any): Native.Leaflet.Layer | Native.Leaflet.LayerGroup | IEventsFeatureGroup;
}

