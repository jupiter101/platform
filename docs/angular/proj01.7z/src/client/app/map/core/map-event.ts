// tslint:disable:no-trailing-whitespace
import {Native} from './map-native';

export type MapEventHandlerCallback = (event: Native.Leaflet.Event) => void;


/**
 * Defines a generic event listener type.
 * Adds a listener function (fn) to a particular event type of the object.
 * You can optionally specify the context of the listener (object the this
 * keyword will point to). You can also pass several space-separated types
 * (e.g. 'click dblclick').
 */
export interface IMapEventHandler {
  type: string;
  fn: MapEventHandlerCallback;
  context?: any;
}
