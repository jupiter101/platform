// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {IMapLayerGroup} from './map-layer-group.spi';
import {Native} from '../map-native';


export interface IMapFeatureGroup extends IMapLayerGroup {
  setStyle(style: Native.Leaflet.PathOptions): this;
  bringToFront(): this;
  bringToBack(): this;
  getBounds(): Native.Leaflet.LatLngBounds;
}

export interface IGeoJSONFeatureGroup extends IMapFeatureGroup {
  options: Native.Leaflet.GeoJSONOptions;
  addData(data: GeoJSONGeoJsonObject): Native.Leaflet.Layer;
  resetStyle(layer: Native.Leaflet.Layer): Native.Leaflet.Layer;
  setStyle(style: Native.Leaflet.StyleFunction): this;
}
