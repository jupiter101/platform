// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IGeoJSONFeatureGroup} from './map-feature-group.spi';
import {IState} from '../../model/state.model';


/**
 * Holds the layers and features of a city.
 */
export interface IEventsFeatureGroup extends IGeoJSONFeatureGroup {
  State: IState;
  removeLayers();
}
