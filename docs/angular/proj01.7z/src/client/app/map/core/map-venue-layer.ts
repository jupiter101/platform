// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from './map-native';
import {IVenue} from '../model/venue.model';

export interface IVenueLayer extends Native.Leaflet.Marker {
  Venue: IVenue;
  getLatLng(): Native.Leaflet.LatLng;
  setLatLng(latlng: Native.Leaflet.LatLngExpression): this;
  setZIndexOffset(offset: number): this;
  setIcon(icon: Native.Leaflet.Icon | Native.Leaflet.DivIcon): this;
  setOpacity(opacity: number): this;
  getElement(): HTMLElement | undefined;
  setVisibility(map: Native.Leaflet.Map, flag: boolean);
  removeLayers();
}

export class MapVenueLayer extends Native.Leaflet.Marker implements IVenueLayer {
  private venue: IVenue;

  constructor(private city: IVenue,
              latlng: Native.Leaflet.LatLngExpression,
              options?: Native.Leaflet.MarkerOptions) {
    super(latlng, options);
  }

  get Venue(): IVenue { return this.venue; }

  setVisibility(map: Native.Leaflet.Map, flag: boolean) {
  }

  removeLayers(): void {
  }
}
