// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {IMapMarker} from './map-marker.spi';
import {ICity} from '../../model/city.model';
import {Native} from '../map-native';

export interface ICityMapMarkerOptions {
  markerOptions?: Native.Leaflet.MarkerOptions;
}

export interface ICityMapMarker extends IMapMarker {
  City: ICity;
  options: ICityMapMarkerOptions;
}
