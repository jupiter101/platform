// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from '../map-native';

export interface IMapPane {
  id: string;
  element: Native.Leaflet.Pane;
}
