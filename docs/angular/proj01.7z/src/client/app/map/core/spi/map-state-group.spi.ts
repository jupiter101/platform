// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IMapFeatureGroup} from './map-feature-group.spi';
import {IState} from '../../model/state.model';
import {Native} from '../map-native';


/**
 * Holds the layers and features of a state.
 */
export interface IStateFeatureGroup extends IMapFeatureGroup {
  State: IState;
  // Cities: Map<number, ICityFeatureGroup>;
  render(map: Native.Leaflet.Map, data): this;
  hide();
  unhide();
  // setVisibility(map: Native.Leaflet.Map, flag: boolean);
  destroy();
  removeLayers();
}
