// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from './map-native';
import {IMapLabel, IMapLabelOptions, MapLabel} from './map-label';
import {IMapEventHandler} from './map-event';
import {MapIcon, MapIconType} from './map-icon';
import {EventsDialogEventParameter} from '../../spi/impl/EventsDialogEventParameter';
import {EventAggregationType} from '../model/event.model';
import {IDialogService} from '../../spi/dialog.service.spi';
import {EventDialogComponent} from '../event-dialog/event-dialog.component';
import {EventDialogService} from '../event-dialog.service';
import {MapCityLayer} from './map-city-layer';
import {environment} from '../../../environments/environment';


export interface IMapMarker {
  get(coord: Native.Leaflet.LatLngExpression,
      text: string,
      id: number,
      type: string,
      options?: IMapLabelOptions | any,
      handler?: IMapEventHandler[]): Native.Leaflet.Marker;
}

export class TextMapMarker implements IMapMarker {
  private evdialogService: IDialogService<EventDialogComponent>;

  constructor(evdialogService: IDialogService<EventDialogComponent>) {
    this.evdialogService = evdialogService;
  }

  get(coord: Native.Leaflet.LatLngExpression,
      text: string,
      id: number,
      type: string,
      options?: IMapLabelOptions,
      handler?: IMapEventHandler[]): Native.Leaflet.Marker {

    let marker;

    const lablel: IMapLabel = new MapLabel(text, options);
    if ( type === 'city') {
      marker = L.marker(coord, {
        icon: MapIcon.getDefault(),
        opacity: 0.0
      });

      marker.bindTooltip(lablel.text, lablel.options);

      // TODO DEPRECATED
      const tooltip = marker.getTooltip();

    } else if ( type === 'venue') {
      marker = L.marker(coord, {
        icon: MapIcon.getDefault(),
        opacity: 1.0
      });
      // marker = L.marker(coord, {
      //   pane: options.pane,
      //   icon: MapIcon.of(MapIconType.NDR),
      //   opacity: 1.0,
      //   zIndexOffset: 1000
      // });
      // marker.bindTooltip(lablel.text, lablel.options);
    }

    Object.defineProperty(marker, '__refid', {value: id});
    Object.defineProperty(marker, '__refname', {value: text});
    Object.defineProperty(marker, '__reftype', {value: type});

    if (handler) {
      handler.forEach(h => marker.on(h.type, h.fn));
    } else {
      [
        {
          type: 'click', fn: this.showDialog.bind(this)
        },
        {
          type: 'mouseover', fn: function (e: L.MouseEvent) {
          (<HTMLElement>e.originalEvent.target).style.cursor = 'pointer';

        }
        }
      ].forEach(h => marker.on(h.type, h.fn));

      return marker;
    }
  }

  /**
   * EventHandler for the markers click event.
   * @param {L.Event} e
   */
  showDialog(e: L.Event) {
    if (e.target.__reftype === 'city') {
      this.evdialogService.ShowDialogRequestEvent
        .emit(
          new EventsDialogEventParameter(
            EventAggregationType.CITY,
            {ref: {id: e.target.__refid, name: e.target.__refname}, brandFilter: null}
          )
        );
    } else if (e.target.__reftype === 'venue') {
      this.evdialogService.ShowDialogRequestEvent
        .emit(
          new EventsDialogEventParameter(
            EventAggregationType.VENUE,
            {ref: {id: e.target.__refid, name: e.target.__refname}, brandFilter: null}
          )
        );
    }
  }



}

// TODO DEPRECATED
export class IconMapMarker implements IMapMarker {

  private evdialogService: IDialogService<EventDialogComponent>;

  constructor(evdialogService: IDialogService<EventDialogComponent>) {
    this.evdialogService = evdialogService;
  }

  get(coord: Native.Leaflet.LatLngExpression,
      text: string,
      id: number,
      type: string,
      options?: any,
      handler?: IMapEventHandler[]): Native.Leaflet.Marker {

    const marker = L.marker(coord, {
      pane: options.pane,
      icon: MapIcon.of(MapIconType.NDR),
      opacity: 1.0,
      zIndexOffset: 1000
    });

    Object.defineProperty(marker, '__refid', {value: id});
    Object.defineProperty(marker, '__refname', {value: text});
    Object.defineProperty(marker, '__reftype', {value: type});

    if (handler) {
      handler.forEach(h => marker.on(h.type, h.fn));
    } else {
      [
        {
          type: 'click', fn: this.showDialog.bind(this)
        },
        {
          type: 'mouseover', fn: function (e: L.MouseEvent) {
          (<HTMLElement>e.originalEvent.target).style.cursor = 'pointer';

        }
        }
      ].forEach(h => marker.on(h.type, h.fn));
      // console.log(marker);
      return marker;
    }
  }

  /**
   * EventHandler for the markers click event.
   * @param {L.Event} e
   */
  showDialog(e: L.Event) {
    if (e.target.__reftype === 'city') {
      this.evdialogService.ShowDialogRequestEvent
        .emit(
          new EventsDialogEventParameter(
            EventAggregationType.CITY,
            {ref: {id: e.target.__refid, name: e.target.__refname}, brandFilter: null}
          )
        );
    } else if (e.target.__reftype === 'venue') {
      this.evdialogService.ShowDialogRequestEvent
        .emit(
          new EventsDialogEventParameter(
            EventAggregationType.VENUE,
            {ref: {id: e.target.__refid, name: e.target.__refname}, brandFilter: null}
          )
        );
    }

  }
}
