// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {TextMapMarker, IconMapMarker} from './map-marker';
import {IMapPane} from './spi/map-pane';
import {IState} from '../model/state.model';
import {IDialogService} from '../../spi/dialog.service.spi';
import {EventDialogComponent} from '../event-dialog/event-dialog.component';
import {IMapRenderStrategy} from './spi/map-render-strategy.spi';
import {IEventsFeatureGroup} from './spi/map-events-group.spi';
import {MapEventsGroup} from './map-events-group';
import {Native} from './map-native';

export class MapVenueRenderStrategy implements IMapRenderStrategy {

  constructor(private state: IState,
              private pane: IMapPane,
              private evdialogService: IDialogService<EventDialogComponent>) {
  }

  render(data?: any): IEventsFeatureGroup {
    const state = this.state;
    const evtDialogService = this.evdialogService;
    const pane = this.pane;

    return <IEventsFeatureGroup> new MapEventsGroup(this.state, data, {
      pane: pane.id,
      pointToLayer: function(feature, latlng) {
        const marker: Native.Leaflet.Marker =  new TextMapMarker(evtDialogService).get(latlng,
          feature.properties['name'],
          feature.properties['id'], 'venue',
          {
            pane: pane.id,
            offset: [-15, 25],
            direction: 'center',
            permanent: true,
            sticky: false,
            interactive: false,
            opacity: 1.0,
            className: 'leaflet-tooltip-text-venue'
          });

        return marker;

      },
      // TODO DEPRECATED
      onEachFeature: function(feature, layer) {
        // console.log(layer);
        // console.log(feature);
        // layer.bindPopup(feature.properties.city);
      }
    });
  }
}
