// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IGeoApiService} from '../../../spi/geo-api.service.spi';
import {IDialogService} from '../../../spi/dialog.service.spi';
import {EventDialogComponent} from '../../event-dialog/event-dialog.component';
import {IStateFilterService} from '../../../spi/state-filter.service.spi';
import {IBrandFilterService} from '../../../spi/brand-filter.service.spi';

export interface IMapServiceParameter {
  geoApiService: IGeoApiService;
  eventsDialogService: IDialogService<EventDialogComponent>;
  filter: {state: IStateFilterService, brand: IBrandFilterService};
}
