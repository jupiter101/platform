// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import {Native} from './map-native';
import MapDefaultOptions from './map-options';
import {IStateFilterItem} from '../model/state-filter.model';
import {IMapControl, LayerControl, ZoomControl} from './map-control';
import {IAreaFeatureGroup} from './spi/map-area.group.spi';
import {MapAreaGroup} from './map-area-group';
import {IMapServiceParameter} from './spi/map.spi';

export class EventsMap {
  private map: Native.Leaflet.Map;
  private layersCtrl: IMapControl;
  private zoomCtrl: IMapControl;
  private options: any;

  areaLayer: IAreaFeatureGroup;

  constructor(private services: IMapServiceParameter) {
    // this.areaLayer = new MapAreaGroup(services);
  }

  /**
   * Method to create the map.
   * @param options
   *
   * @author Stephan Petzchen
   */
  create(options?: any) {
    // 0. get default option if not given
    if (!options) {
      MapDefaultOptions.setDefaultProvider(MapDefaultOptions.baseMaps.MapBox);
      options = MapDefaultOptions.options;
    }
    this.options = options;

    this.map = Native.Leaflet.map('map', this.options);
    this.areaLayer = new MapAreaGroup(this.services);
    this.zoomCtrl = ZoomControl.of(this.map).init();
    // this.layersCtrl = LayerControl.of(this.map, MapDefaultOptions.baseMaps, null).init();
    this.areaLayer.render(this.map).addTo(this.map);

    /* LINKS:
        // 4. Register events
        //
        // this.registerMapEvents();

        // LINKS:

        // JSDoc
        // http://usejsdoc.org/

        // TSLint
        // https://palantir.github.io/tslint/rules/no-bitwise/
        // https://palantir.github.io/tslint/usage/rule-flags/

        // Leaflet
        // https://leanpub.com/leaflet-tips-and-tricks/read

        // Event Listener
        // http://leafletjs.com/reference-1.1.0.html#map-baselayerchange
        // https://gis.stackexchange.com/questions/172508/add-an-event-listener-on-a-marker-in-leaflet
        // https://gis.stackexchange.com/questions/180644/how-to-use-leaflets-overlayadd-event

        // Layer Groups:
        // http://jsfiddle.net/nathansnider/s408tnwv/
        // https://gis.stackexchange.com/questions/178003/hide-unhide-layers-in-leaflet
        //

        // GeoJSON
        // http://bl.ocks.org/ThomasG77/61fa02b35abf4b971390
        // http://leafletjs.com/examples/geojson/
        // https://gis.stackexchange.com/questions/41928/adding-removing-leaflet-geojson-layers
        //

        // ICON
        // https://gis.stackexchange.com/questions/121424/leaflet-how-to-use-a-custom-marker-on-a-geojson-layer

        // Marker
        // https://gis.stackexchange.com/questions/108183/how-to-change-leaflet-marker-color-on-mouseover
        // https://gis.stackexchange.com/questions/130368/change-markers-size-by-with-zoom-in-leaflet
     */

  }

  render(options?: any) {
    if (this.map) {
      this.map.remove();
    }

    if (!options) {
      MapDefaultOptions.setDefaultProvider(MapDefaultOptions.baseMaps.MapBox);
      options = MapDefaultOptions.options;
    }
    this.options = options;

    this.map = Native.Leaflet.map('map', this.options);
    this.areaLayer = new MapAreaGroup(this.services);
    this.zoomCtrl = ZoomControl.of(this.map).init();
    // this.layersCtrl = LayerControl.of(this.map, MapDefaultOptions.baseMaps, null).init();
    this.areaLayer.render(this.map).addTo(this.map);
  }

  rerender() {
    console.log('MAP::rerender');
    this.map.remove();
    delete this.areaLayer;
    this.map = Native.Leaflet.map('map', this.options);
    this.areaLayer = new MapAreaGroup(this.services);
    this.zoomCtrl = ZoomControl.of(this.map).init();
    // this.areaLayer.removeLayers();
    // this.areaLayer.remove();
    this.areaLayer.render(this.map).addTo(this.map);
  }

  /**
   * Getter for the native map reference.
   * @returns {Native.Leaflet.Map}
   * @constructor
   *
   * @author Stephan Petzchen
   */
  get Map (): Native.Leaflet.Map { return this.map; }

  /**
   * Destroys the map.
   *
   * @author Stephan Petzchen
   */
  destroy() {
    this.areaLayer.destroy();
    this.map.remove();
    delete this.areaLayer;
    delete this.map;
  }

  // ############################ Map Service Methods ############################

  /**
   * Setting visibility of the selected state layer.
   *
   * @param {IStateFilterItem} state
   *
   * @author Stephan Petzchen
   *
   * TODO Remove here and in map.service
   */
  setStateVisibility(state: IStateFilterItem) {
    // this.areaLayer.setStateVisibility(state);
  }

  // TODO DEPRECATED
  getBounds(): L.LatLngBounds {
    return this.map.getBounds();
  }

  // TODO DEPRECATED
  setMaxBounds(bounds: L.LatLngBounds) {
    this.map.setMaxBounds(bounds);
  }

  // TODO DEPRECATED
  setZoom(zoom: number, options?: L.ZoomPanOptions) {
    options ? this.map.setZoom(zoom, options) : this.map.setZoom(zoom);
  }

  // TODO DEPRECATED
  setView(center: L.LatLngExpression, zoom: number, options?: L.ZoomPanOptions) {
    options ? this.map.setView(center, zoom, options) : this.map.setView(center, zoom);
  }

  // TODO DEPRECATED
  flyToBounds(bounds: L.LatLngBoundsExpression, options?: L.FitBoundsOptions) {
    options ? this.map.flyToBounds(bounds, options) : this.map.flyToBounds(bounds);
  }


  disableMouseEvent(elementId: string) {
    const element = <HTMLElement>document.getElementById(elementId);

    L.DomEvent.disableClickPropagation(element);
    L.DomEvent.disableScrollPropagation(element);
  }

  // TODO DEPRECATED
  onMapEvent(event: L.Event) {
  }

  // TODO DEPRECATED
  private registerMapEvents() {
// 4.1 Map state change events
    this.map.on('zoomlevelschange', this.onMapEvent);
    this.map.on('resize', this.onMapEvent);
    this.map.on('unload', this.onMapEvent);
    this.map.on('viewreset', this.onMapEvent);
    this.map.on('load', this.onMapEvent);
    this.map.on('zoomstart', this.onMapEvent);
    this.map.on('movestart', this.onMapEvent);
    this.map.on('zoom', this.onMapEvent);
    this.map.on('move', this.onMapEvent);
    this.map.on('zoomend', this.onMapEvent);
    this.map.on('moveend', this.onMapEvent);

    // 4.2 Interaction events
    this.map.on('click', this.onMapEvent);
    this.map.on('dblclick', this.onMapEvent);
    this.map.on('mousedown', this.onMapEvent);
    this.map.on('mouseup', this.onMapEvent);
    this.map.on('mouseover', this.onMapEvent);
    this.map.on('mouseout', this.onMapEvent);
    this.map.on('mousemove', this.onMapEvent);
    this.map.on('contextmenu', this.onMapEvent);
    this.map.on('keypress', this.onMapEvent);
  }
}

