// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from '../map-native';

export interface IMapLayer {
  addTo(map: Native.Leaflet.Map|Native.Leaflet.LayerGroup): this;
  remove(): this;
  removeFrom(map: Native.Leaflet.Map): this;
  getPane(name?: string): HTMLElement | undefined;
  bindTooltip(content: ((layer: Native.Leaflet.Layer) => Native.Leaflet.Content) |
    Native.Leaflet.Tooltip | Native.Leaflet.Content, options?: Native.Leaflet.TooltipOptions): this;
  unbindTooltip(): this;
  openTooltip(latlng?: Native.Leaflet.LatLngExpression): this;
  closeTooltip(): this;
  toggleTooltip(): this;
  isTooltipOpen(): boolean;
  setTooltipContent(content: Native.Leaflet.Content | Native.Leaflet.Tooltip): this;
  getTooltip(): Native.Leaflet.Tooltip | undefined;

  // Extension methods
  onAdd(map: Native.Leaflet.Map): this;
  onRemove(map: Native.Leaflet.Map): this;
  getEvents?(): {[name: string]: (event: Event) => void};
  getAttribution?(): string | null;
  beforeAdd?(map: Native.Leaflet.Map): this;
}
