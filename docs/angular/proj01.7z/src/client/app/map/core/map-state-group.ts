// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from './map-native';
import {IStateFeatureGroup} from './spi/map-state-group.spi';
import {IState} from '../model/state.model';
import {IStateFilterItem} from '../model/state-filter.model';
import {environment} from '../../../environments/environment';
import {IMapPane} from './spi/map-pane';
import {IMapServiceParameter} from './spi/map.spi';
import {IEventsFeatureGroup} from './spi/map-events-group.spi';
import {MapCityRenderStrategy} from './map-city-render-strategy';
import {IconMapMarker} from './map-marker';
import {MapEventsGroup} from './map-events-group';
import {GeoDataFilterType, GeoDataRequestType} from '../../spi/geo-api.service.spi';
import {MapVenueRenderStrategy} from './map-venue-render-strategy';

export class MapStateGroup extends Native.Leaflet.FeatureGroup implements IStateFeatureGroup {
  private map: Native.Leaflet.Map;
  private eventsGroup: IEventsFeatureGroup;
  private venueEventsGroup: IEventsFeatureGroup;
  private subscriptions: any[] = [];
  private pane: IMapPane;
  private venuePane: IMapPane;
  private stateBBox: Native.Leaflet.LatLngBounds;

  constructor(private state: IState, private services: IMapServiceParameter) {
    super();
    this.subscriptions[0] = this.services.filter.state.StateFilterChangeEvent.subscribe(
      data => {
        // this.setVisibility(data);
      });

    this.stateBBox = this.services.filter.state.getBBox(this.state.id);

  }

  get Map(): Native.Leaflet.Map {
    return this.map;
  }

  get State(): IState {
    return this.state;
  }

  render(map: Native.Leaflet.Map, data): this {
    this.map = map;
    this.pane = {id: this.state.name, element: this.map.createPane(this.state.name)};
    this.venuePane = {id: this.state.name + '-Venue', element: this.map.createPane(this.state.name + '-Venue')};
    const dialogService = this.services.eventsDialogService;
    const paneId = this.pane.id;
    const that = this;

    // this.eventsGroup = new MapEventsGroup(this.state, data.features, {
    //   pane: paneId,
    //   pointToLayer: function(feature, latlng) {
    //     let classNameLst: string = 'leaflet-pulsing-icon leaflet-pulsing-icon-blue';
    //
    //     if (data.id === 1) {
    //       classNameLst = 'leaflet-pulsing-icon leaflet-pulsing-icon-dark-red';
    //     }else if (data.id === 2) {
    //       classNameLst = 'leaflet-pulsing-icon leaflet-pulsing-icon-blue';
    //     }else if (data.id === 3) {
    //       classNameLst = 'leaflet-pulsing-icon leaflet-pulsing-icon-pink';
    //     }else if (data.id === 4) {
    //       classNameLst = 'leaflet-pulsing-icon leaflet-pulsing-icon-green';
    //     }else if (data.id === 5) {
    //       classNameLst = 'leaflet-pulsing-icon leaflet-pulsing-icon-red';
    //     }
    //
    //     // console.log(latlng, feature);
    //     // console.log(feature.properties['city']);
    //     // const cityL = new Native.Leaflet.LayerGroup();
    //
    //     // MapLabel.of(latlng, feature.properties['city']);
    //     // const mLabel: Native.Leaflet.Marker =  new TextMapMarker(dialogService).get(latlng,
    //     //   feature.properties['city'],
    //     //   feature.properties['id']);
    //     // const cityMarker = new MapCityLayer(
    //     //   dialogService,
    //     //   {id: feature.properties['id'], name: feature.properties['city']},
    //     //   latlng,
    //     //   {pane: pane, classNames: classNameLst});
    //     // console.log(paneId);
    //
    //     const mIcon = new IconMapMarker(dialogService).get(latlng,
    //       feature.properties['city'],
    //       feature.properties['id'],
    //       {pane: paneId, classNames: classNameLst});
    //
    //     // that.addLayer(mIcon);
    //
    //     // cityL.addLayer(mIcon);
    //     // cityL.addLayer(mLabel);
    //     return mIcon;
    //
    //   },
    //   onEachFeature: function(feature, layer) {
    //     // console.log(layer);
    //     // console.log(feature);
    //     // layer.bindPopup(feature.properties.city);
    //   }
    // }).addTo(this);

    this.renderCities();

    const localMap = this.map;
    const state = this.state;
    const stateBBox = this.stateBBox;
    const pane = this.pane;
    const venuePpane = this.venuePane;
    const renderCities = this.renderCities;
    const renderVenues = this.renderVenues;


    this.map.on('zoomend', function(e: Native.Leaflet.Event) {
      that.pane.element.style.fontSize = `${e.target._zoom * 1.5}px`;

      if (e.target._zoom < 11 && that.venueEventsGroup) {
        that.venueEventsGroup.remove();
        delete that.venueEventsGroup;
        that.venuePane.element.style.display = 'none';
      }
      if (e.target._zoom >= 11 ) {
        that.pane.element.style.display = 'none';
        that.venuePane.element.style.display = 'block';
      } else {
        that.pane.element.style.display = 'block';
        that.venuePane.element.style.display = 'none';
      }
      if (e.target._zoom === 11 && !that.venueEventsGroup) {
        that.renderVenues(that);
      }
    });

    return this;
  }

  hide() {
    this.pane.element.style.display = 'none';
    this.venuePane.element.style.display = 'block';
  }

  unhide() {
    this.pane.element.style.display = 'block';
    this.venuePane.element.style.display = 'none';
  }

  destroy() {
    this.subscriptions.forEach( s => s.unsubscribe());
  }

  removeLayers() {
    this.eachLayer(function (layer) {
      this.removeLayer(layer);
    }, this);
  }

  private renderCities() {
    if (this.services.filter.brand.brandFilter.hasSelectedItems()) {
      if (this.services.filter.state.stateFilter.getSelected().state.id === this.state.id ||
        this.services.filter.state.stateFilter.getSelected().state.id === 0) {
        this.services.geoApiService.get(GeoDataRequestType.CITIES, GeoDataFilterType.ALL,
          {
            state: this.state.id,
            brands: this.services.filter.brand.brandFilter.getSelectedList()
          })
          .subscribe( data => {
            // console.log(data);
            this.eventsGroup = new MapCityRenderStrategy(
              this.state, this.pane, this.services.eventsDialogService)
              .render(data)
              .addTo(this);
            this.pane.element.style.fontSize = '10.5px';
          });
      }
    } else {
      if (this.services.filter.state.stateFilter.getSelected().state.id === this.state.id ||
          this.services.filter.state.stateFilter.getSelected().state.id === 0) {
        this.services.geoApiService.get(GeoDataRequestType.CITIES, GeoDataFilterType.STATE,
          {
            state: this.state.id,
            brands: null
          })
          .subscribe( data => {
            // console.log(data);
            this.eventsGroup = new MapCityRenderStrategy(
              this.state, this.pane, this.services.eventsDialogService)
              .render(data)
              .addTo(this);
            this.pane.element.style.fontSize = '10.5px';
          });
      }
    }
  }

  private renderVenues(that) {
    const filterType = (that.services.filter.brand.brandFilter.hasSelectedItems() ? GeoDataFilterType.ALL : GeoDataFilterType.STATE);
    if (that.services.filter.state.stateFilter.getSelected().state.id === that.state.id ||
      that.services.filter.state.stateFilter.getSelected().state.id === 0) {
      that.services.geoApiService.get(GeoDataRequestType.VENUES, filterType,
        {
          state: that.state.id,
          brands: (that.services.filter.brand.brandFilter.hasSelectedItems() ?
            that.services.filter.brand.brandFilter.getSelectedList() : null)
        })
        .subscribe( data => {
          that.venueEventsGroup = new MapVenueRenderStrategy(
            that.state, that.venuePane, that.services.eventsDialogService)
            .render(data)
            .addTo(that);
          that.venuePane.element.style.zIndex = '5000';
          that.venueEventsGroup.bringToFront();
          that.pane.element.style.display = 'none';
          that.venuePane.element.style.display = 'block';
        });
    }
  }



  private setVisibility(stateFilterItem: IStateFilterItem) {
    console.log('MapStateGroup::setVisibility');
    if (stateFilterItem.state.id === 0) {
      this.unhide();
    } else {
      if (this.state.id === stateFilterItem.state.id && (stateFilterItem.isSelected)) {
        this.unhide();
      } else {
        this.hide();
      }
    }
  }
}
