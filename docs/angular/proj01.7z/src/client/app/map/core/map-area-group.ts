// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Native} from './map-native';
import {IAreaFeatureGroup} from './spi/map-area.group.spi';
import {IStateFilterItem} from '../model/state-filter.model';
import {IStateFeatureGroup} from './spi/map-state-group.spi';
import {MapStateGroup} from './map-state-group';
import {GeoDataFilterType, GeoDataRequestType} from '../../spi/geo-api.service.spi';
import {IMapServiceParameter} from './spi/map.spi';

export class MapAreaGroup extends Native.Leaflet.FeatureGroup implements IAreaFeatureGroup {
  private states: Map<number, IStateFeatureGroup> = new Map();
  private map: Native.Leaflet.Map;
  constructor( private services: IMapServiceParameter) {
    super();
    this.services.filter.state.stateFilter.filter.forEach( s => {
      if ( s.state.id > 0) {
        this.states.set(
          s.state.id,
          <IStateFeatureGroup> new MapStateGroup( s.state, this.services)
        );
      }
    });
  }

  render(map: Native.Leaflet.Map): this {
    this.map = map;

    this.states.forEach((v, k) => {
      if (k > 0) {
        v.render(map, null).addTo(this);
      }
    });
    return this;
  }

  // TODO DEPRECATED
  setStateVisibility(stateFilterItem: IStateFilterItem) {
  }

  destroy() {
    this.states.forEach((v, k) => {
      v.destroy();
    });
    delete this.states;
  }

  removeLayers() {
    this.states.forEach((v, k) => {
      if (k > 0) {
        v.removeLayers();
      }
    });
  }
}
