// tslint:disable:no-trailing-whitespace

/**
 *
 *
 * @see https://www.w3schools.com/cssref/pr_class_cursor.asp
 * TODO DEPRECATED
 */
export enum CursorType {
  Default,
  Pointer
}
