import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'deIntegerFormat'
})
export class DeIntegerFormater implements PipeTransform {

  transform(value: any, args?: any): any {
    return String(new Intl.NumberFormat('de-DE')
      .format(Number(value)));
  }

}

@Pipe({
  name: 'deDecimalFormat'
})
export class DeDecimalFormater implements PipeTransform {

  transform(value: any, args?: any): any {
    return String(new Intl.NumberFormat('de-DE', { maximumFractionDigits: 2, minimumFractionDigits: 2 })
      .format(Number(value)));
  }

}
