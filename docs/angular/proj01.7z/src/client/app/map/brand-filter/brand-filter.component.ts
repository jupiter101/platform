// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnInit} from '@angular/core';
import {IBrandFilter, IBrandFilterItem} from '../model/brand-filter.model';
import {StatisticsType} from '../model/stat.model';
import {IBrandFilterService} from '../../spi/brand-filter.service.spi';
import {IDialogService} from '../../spi/dialog.service.spi';
import {StatDialogComponent} from '../stat-dialog/stat-dialog.component';
import {StatisticDialogEventParameter} from '../../spi/impl/StatisticDialogEventParameter';


@Component({
  selector: 'app-brand-filter',
  templateUrl: './brand-filter.component.html',
  styleUrls: ['./brand-filter.component.scss']
})
export class BrandFilterComponent implements OnInit {
  brandFilter: IBrandFilter;

  constructor(@Inject('IBrandFilterService') private brandFilterService: IBrandFilterService,
              @Inject('IDialogService<StatDialogComponent>') private dialogService: IDialogService<StatDialogComponent>) {
    this.brandFilter = this.brandFilterService.brandFilter;
  }

  ngOnInit() {
  }


  onSelectionChange(brand: IBrandFilterItem) {
    this.brandFilterService.BrandFilterChangeEvent.emit(this.brandFilter);
  }

  onBrandStatisticsRequest() {
    this.dialogService.ShowDialogRequestEvent.emit(new StatisticDialogEventParameter(StatisticsType.Brand, this.brandFilter));
  }
}
