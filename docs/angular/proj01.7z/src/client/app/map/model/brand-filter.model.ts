
import {IBrand} from './brand.model';

export interface IBrandFilterItem {
  brand: IBrand;
  isSelected: boolean;
}

export interface IBrandFilter {
  filter: IBrandFilterItem[];
  getSelected(): IBrandFilterItem[];
  getSelectedList(): string;
  hasSelectedItems(): boolean;
}

export class BrandFilter implements IBrandFilter {
  filter = [
    {brand: {id: 17, name: 'NDR'}, isSelected: false},
    {brand: {id: 14, name: 'NDR - Fernsehen'}, isSelected: false},
    {brand: {id: 2, name: 'Hamburg Journal'}, isSelected: false},
    {brand: {id: 4, name: 'Nord Magazin'}, isSelected: false},
    {brand: {id: 6, name: 'Hallo Niedersachsen'}, isSelected: false},
    {brand: {id: 8, name: 'Schleswig-Holstein Magazin'}, isSelected: false},
    {brand: {id: 5, name: 'NDR1 Niedersachsen'}, isSelected: false},
    {brand: {id: 3, name: 'NDR1 Radio MV'}, isSelected: false},
    {brand: {id: 7, name: 'NDR1 Welle Nord'}, isSelected: false},
    {brand: {id: 1, name: 'NDR 90.3'}, isSelected: false},
    {brand: {id: 9, name: 'NDR2'}, isSelected: false},
    {brand: {id: 11, name: 'NDR Info'}, isSelected: false},
    {brand: {id: 13, name: 'NJOY'}, isSelected: false}
  ];

  getSelected() {
    return this.filter.filter(b => b.isSelected);
  }

  getSelectedList() {
    return this.filter.filter(b => b.isSelected).map(b => b.brand.id).join();
  }

  hasSelectedItems() {
    return this.filter.filter(b => b.isSelected).length > 0;
  }
}
