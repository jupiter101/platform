
export enum StatisticsType {
  Area,
  State,
  Brand
}

export interface IStatistics {
  titel: string;
  type: string;
  state_id: string;
  state: string;
  brand: string;
  events: string;
  visitor: string;
  accompanying_media: string;
  costs: string;
  costs_per_event: string;
  costs_per_1k_visitor: string;
}
