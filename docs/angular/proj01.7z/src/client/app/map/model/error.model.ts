// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Error model.
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error
 */
export enum ErrorType {
  Eval,       //  representing an error that occurs regarding the global function eval()
  Network,
  Internal,   // representing an error that occurs when an internal error in the JavaScript engine is thrown
  Range,      // representing an error that occurs when a numeric variable or parameter is outside of its valid range
  Reference,  // representing an error that occurs when de-referencing an invalid reference
  Syntax,     // representing a syntax error that occurs while parsing code in eval()
  Type,       // representing an error that occurs when a variable or parameter is not of a valid type
  URI         // representing an error that occurs when encodeURI() or decodeURI() are passed invalid parameters
}
