// tslint:disable:no-trailing-whitespace
import {IState} from './state.model';
import {MapDirection, StateBBoxMap} from '../../spi/state-filter.service.spi';

/**
 *
 */
export interface IStateFilterItem {
  state: IState;
  isSelected: boolean;
}

/**
 *
 */
export interface IStateFilter {
  filter: IStateFilterItem[];
  stateBBoxMap: StateBBoxMap;
  getSelected(): IStateFilterItem;
  getSelectedList(): string;
  hasSelectedItems(): boolean;
  setSelection(stateItem: IStateFilterItem);
}

/**
 *
 */
export class StateFilter implements IStateFilter {
  filter = [
    {state: {id: 0, name: 'gesamtes Sendegebiet'}, isSelected: false},
    {state: {id: 1, name: 'Bremen'}, isSelected: false},
    {state: {id: 22, name: 'Hamburg'}, isSelected: false},
    {state: {id: 24, name: 'Mecklenburg-Vorpommern'}, isSelected: false},
    {state: {id: 23, name: 'Niedersachsen'}, isSelected: false},
    {state: {id: 21, name: 'Schleswig-Holstein'}, isSelected: false},
  ];

  stateBBoxMap: StateBBoxMap = new Map([
    [ 6, {bbox: new Map([
      [MapDirection.NORTH, 49.7913749328],
      [MapDirection.WEST, 7.5113934084],
      [MapDirection.SOUTH, 47.5338000528],
      [MapDirection.EAST, 10.4918239143]
    ]), center: {lat: 48.6625874928, long: 9.00160866135}, zoom: 7}
    ],
    [ 7, {bbox: new Map([
      [MapDirection.NORTH, 50.5644529365],
      [MapDirection.WEST, 8.9771580802],
      [MapDirection.SOUTH, 47.2703623267],
      [MapDirection.EAST, 13.8350427083]
    ]), center: {lat: 48.9174076316, long: 11.40610039425}, zoom: 7}
    ],
    [ 8, {bbox: new Map([
      [MapDirection.NORTH, 52.6697240587],
      [MapDirection.WEST, 13.0882097323],
      [MapDirection.SOUTH, 52.3418234221],
      [MapDirection.EAST, 13.7606105539]
    ]), center: {lat: 52.50577374046, long: 13.4244101431}, zoom: 7}
    ],
    [ 9, {bbox: new Map([
      [MapDirection.NORTH, 53.5579500214],
      [MapDirection.WEST, 11.268166444],
      [MapDirection.SOUTH, 51.360662705],
      [MapDirection.EAST, 14.76471050129]
    ]), center: {lat: 52.4593063636, long: 13.016438472645}, zoom: 7}
    ],
    [ 1, {bbox: new Map([
      [MapDirection.NORTH, 53.6061664164],
      [MapDirection.WEST, 8.4813576818],
      [MapDirection.SOUTH, 53.0103701114],
      [MapDirection.EAST, 8.9830477728]
    ]), center: {lat: 53.308268263900004, long: 8.7322027273}, zoom: 7}
    ],
    [ 22, {bbox: new Map([
      [MapDirection.NORTH, 53.9644376366],
      [MapDirection.WEST, 8.42136432788],
      [MapDirection.SOUTH, 53.3949251389],
      [MapDirection.EAST, 10.3242585128]
    ]), center: {lat: 53.67968138775, long: 9.37281142034}, zoom: 10}
    ],
    [ 24, {bbox: new Map([
      [MapDirection.NORTH, 51.65404960664],
      [MapDirection.WEST, 7.7731704009],
      [MapDirection.SOUTH, 49.394822919],
      [MapDirection.EAST, 10.2340156149]
    ]), center: {lat: 50.524436262820004, long: 9.003593007900001}, zoom: 7}
    ],
    [ 23, {bbox: new Map([
      [MapDirection.NORTH, 54.6849886830],
      [MapDirection.WEST, 10.5932460856],
      [MapDirection.SOUTH, 53.1158637944],
      [MapDirection.EAST, 14.4122799503]
    ]), center: {lat: 53.612651, long: 12.429595}, zoom: 9}
    ],
    [ 21, {bbox: new Map([
      [MapDirection.NORTH, 53.8941514415],
      [MapDirection.WEST, 6.6545841239],
      [MapDirection.SOUTH, 51.2954150799],
      [MapDirection.EAST, 11.59769814]
    ]), center: {lat: 52.772414, long: 9.004464}, zoom: 8}
    ],
    [ 11, {bbox: new Map([
      [MapDirection.NORTH, 52.5310351488],
      [MapDirection.WEST, 5.8659988131],
      [MapDirection.SOUTH, 50.322698943],
      [MapDirection.EAST, 9.4476584861]
    ]), center: {lat: 51.426867045899996, long: 7.6568286495999995}, zoom: 7}
    ],
    [ 12, {bbox: new Map([
      [MapDirection.NORTH, 50.9404435711],
      [MapDirection.WEST, 6.1173598760],
      [MapDirection.SOUTH, 48.9662745077],
      [MapDirection.EAST, 8.5084754437]
    ]), center: {lat: 49.9533590394, long: 7.31291765985}, zoom: 7}
    ],
    [ 13, {bbox: new Map([
      [MapDirection.NORTH, 49.6393467247],
      [MapDirection.WEST, 6.3584695643],
      [MapDirection.SOUTH, 49.1130992988],
      [MapDirection.EAST, 7.40349010787]
    ]), center: {lat: 49.37622301175, long: 6.880979836085}, zoom: 7}
    ],
    [ 14, {bbox: new Map([
      [MapDirection.NORTH, 51.6831408995],
      [MapDirection.WEST, 11.8723081683],
      [MapDirection.SOUTH, 50.1715419914],
      [MapDirection.EAST, 15.0377433357]
    ]), center: {lat: 50.92734144545, long: 13.455025752000001}, zoom: 7}
    ],
    [ 15, {bbox: new Map([
      [MapDirection.NORTH, 53.0421316033],
      [MapDirection.WEST, 10.5614755400],
      [MapDirection.SOUTH, 50.9379979829],
      [MapDirection.EAST, 13.1865600846]
    ]), center: {lat: 51.990064793100004, long: 11.8740178123}, zoom: 7}
    ],
    [ 5, {bbox: new Map([
      [MapDirection.NORTH, 55.0573747014],
      [MapDirection.WEST, 7.8685145620],
      [MapDirection.SOUTH, 53.3590675115],
      [MapDirection.EAST, 11.3132037822]
    ]), center: {lat: 54.20822110645, long: 9.5908591721}, zoom: 9}
    ],
    [ 16, {bbox: new Map([
      [MapDirection.NORTH, 51.6490678544],
      [MapDirection.WEST, 9.8778443239],
      [MapDirection.SOUTH, 50.2042330625],
      [MapDirection.EAST, 12.6531964048]
    ]), center: {lat: 50.92665045845, long: 11.26552036435}, zoom: 7}
    ],
    [ 0, {bbox: new Map([
      [MapDirection.NORTH, 55.254077],
      [MapDirection.WEST, 15.106201],
      [MapDirection.SOUTH, 51.200000],
      [MapDirection.EAST, 5.888672]
    ]), center: {lat: 52.994950, long: 13.305176}, zoom: 7}
    ]
  ]);

  selectedState: IStateFilterItem;

  constructor() {
    this.selectedState = this.filter[0];
  }

  /**
   *
   * @param {IStateFilterItem} stateItem
   */
  setSelection(stateItem: IStateFilterItem): void {
    this.selectedState.isSelected = false;
    this.selectedState = stateItem;
    this.selectedState.isSelected = true;
  }

  /**
   *
   * @returns {IStateFilterItem}
   */
  getSelected(): IStateFilterItem {
    return this.selectedState;
  }

  /**
   *
   * @returns {string}
   */
  getSelectedList(): string {
    return this.filter.filter(s => s.isSelected).map(s => s.state.id).join();
  }

  /**
   *
   * @returns {boolean}
   */
  hasSelectedItems(): boolean {
    return this.filter.find( i => i.isSelected === true && (i.state.id !== 0)) != null;
  }

}
