export enum EventAggregationType {
  VENUE,
  CITY
}

export interface IEvent {
  id: number;
  name: string;
  city_id: string;
  brand_id: string;
  venue_id: string;
  city: string;
  venue: string;
  brand: string;
  date: string;
}

