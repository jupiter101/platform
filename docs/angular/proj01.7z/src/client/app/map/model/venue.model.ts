export interface IVenue {
  id: number;
  name: string;
}
