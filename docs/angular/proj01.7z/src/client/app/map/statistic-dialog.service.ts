// tslint:disable:no-trailing-whitespace
import { Injectable } from '@angular/core';
import {DialogService} from '../spi/impl/dialog.service';
import {StatDialogComponent} from './stat-dialog/stat-dialog.component';

/**
 * StatisticsDialog service.
 * @author Stephan Petzchen
 */
@Injectable()
export class StatisticDialogService extends DialogService<StatDialogComponent> {}
