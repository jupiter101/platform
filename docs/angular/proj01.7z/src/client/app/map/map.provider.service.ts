// tslint:disable:interface-over-type-literal
import {Injectable} from '@angular/core';
import { environment} from '../../environments/environment';

export type MapProviderOption = {key: string, value: string};

export interface IMapProvider {
  id: string;
  name: string;
  url: string;
  apiKeyEnv: string;
  apiKey: string;
  options: MapProviderOption[];
  get(apiKey?: string);
}

export interface IMapProviderService {
  get(id: string): IMapProvider;
  list(): IMapProvider[];
}


@Injectable()
export class MapProviderService implements IMapProviderService {
  get(id: string): IMapProvider {

    return null;
  }

  list(): IMapProvider[] {

    //
    return null;
  }

  private buildProviderList() {

  }
}
