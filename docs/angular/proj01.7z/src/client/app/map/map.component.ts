// tslint:disable:no-trailing-whitespace
import {Component, OnInit, ViewContainerRef, OnDestroy, Inject} from '@angular/core';
import {IDialogEventParameter, IDialogService} from '../spi/dialog.service.spi';
import {StatDialogComponent} from './stat-dialog/stat-dialog.component';
import {EventDialogComponent} from './event-dialog/event-dialog.component';
import {IMapService} from '../spi/map-service.spi';
import {IAuthService} from '../spi/auth.service.spi';
import {IBrandFilterService} from '../spi/brand-filter.service.spi';
import {ErrorDialogComponent} from './error-dialog/error-dialog.component';
import {IUrlService} from '../spi/url-service.spi';

/**
 * Map component
 * @author Stephan Petzchen
 */
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit, OnDestroy {
  isLoggedIn = false;
  dialogResult: any;
  subscriptions: any[] = [];

  constructor(private viewContainerRef: ViewContainerRef,
              @Inject('IUrlService') private urlService: IUrlService,
              @Inject('IMapService') private mapService: IMapService,
              @Inject('IAuthService') private auth: IAuthService,
              @Inject('IBrandFilterService')private brandFilterApiService: IBrandFilterService,
              @Inject('IDialogService<ErrorDialogComponent>') private errDialogService: IDialogService<ErrorDialogComponent>,
              @Inject('IDialogService<StatDialogComponent>') private statDialogService: IDialogService<StatDialogComponent>,
              @Inject('IDialogService<EventDialogComponent>') private eventDialogService: IDialogService<EventDialogComponent>) { }

  ngOnInit() {
    this.subscriptions[0] = this.statDialogService.ShowDialogRequestEvent
      .subscribe(data  => this.showStatDialog(data));

    this.subscriptions[1] = this.eventDialogService.ShowDialogRequestEvent
      .subscribe(data => this.showEventsDialog(data));

    this.subscriptions[1] = this.errDialogService.ShowDialogRequestEvent
      .subscribe(data => this.showErrorDialog(data));

    this.preAuth();

    this.mapService.createMap();
    this.isLoggedIn = this.auth.isLoggedIn();

  }

  ngOnDestroy() {
    this.mapService.destroyMap();
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  showStatDialog(data: IDialogEventParameter<StatDialogComponent>) {
    this.statDialogService.showDialog(this.viewContainerRef, StatDialogComponent, data)
      .subscribe(res => this.dialogResult = res);
  }

  showEventsDialog(data: IDialogEventParameter<EventDialogComponent>) {
    data.parameter.brandFilter = this.brandFilterApiService.brandFilter;
    this.eventDialogService.showDialog(this.viewContainerRef, EventDialogComponent, data)
      .subscribe(res => this.dialogResult = res);
  }

  showErrorDialog(data: IDialogEventParameter<ErrorDialogComponent>) {
    this.errDialogService.showDialog(this.viewContainerRef, ErrorDialogComponent, data)
      .subscribe(res => this.dialogResult = res);
  }

  private preAuth(): void {
    this.auth.preauth();
  }
}
