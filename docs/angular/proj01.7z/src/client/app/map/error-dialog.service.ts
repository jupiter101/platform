// tslint:disable:no-trailing-whitespace
import { Injectable } from '@angular/core';
import {DialogService} from '../spi/impl/dialog.service';
import {ErrorDialogComponent} from './error-dialog/error-dialog.component';

/**
 * ErrorDialog service.
 *
 * @author Stephan Petzchen
 *
 * TODO Integration pending.
 */
@Injectable()
export class ErrorDialogService extends DialogService<ErrorDialogComponent> {}
