// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnInit} from '@angular/core';
import {IStateFilter, IStateFilterItem} from '../model/state-filter.model';
import {IStateFilterService} from '../../spi/state-filter.service.spi';
import {IDialogService} from '../../spi/dialog.service.spi';

import {StatDialogComponent} from '../stat-dialog/stat-dialog.component';
import {StatisticsType} from '../model/stat.model';
import {StatisticDialogEventParameter} from '../../spi/impl/StatisticDialogEventParameter';
import {StateFilterService} from '../../spi/impl/state-filter.service';


/**
 *
 * UI Component to present the state list for filtering.
 *
 * @author Stephan Petzchen
 */
@Component({
  selector: 'app-state-filter',
  templateUrl: './state-filter.component.html',
  styleUrls: ['./state-filter.component.scss']
})
export class StateFilterComponent implements OnInit {
  stateFilter: IStateFilter;
// @Inject('IStateFilterService')
  constructor(@Inject('IStateFilterService') private stateFilterService: StateFilterService,
              @Inject('IDialogService<StatDialogComponent>') private dialogService: IDialogService<StatDialogComponent>) {

    this.stateFilter = this.stateFilterService.stateFilter;
  }

  ngOnInit() {
  }

  /**
   * Handle state selection from the user.
   * @param {IStateFilterItem} filterItem
   */
  onSelectionChange(filterItem: IStateFilterItem) {
    // console.log(name);
    this.stateFilter.setSelection(filterItem);
    this.stateFilterService.StateFilterChangeEvent.emit(filterItem);
  }

  /**
   * Use the dialog service to show the area statistics dialog.
   *
   * @author Stephan Petzchen
   */
  onAreaStatisticsRequest() {
    this.dialogService.ShowDialogRequestEvent.emit(new StatisticDialogEventParameter(StatisticsType.Area));
  }

  /**
   * Use the dialog service to show the state statistics dialog.
   * @author Stephan Petzchen
   */
  onStateStatisticsRequest() {
    this.dialogService.ShowDialogRequestEvent.emit(new StatisticDialogEventParameter(StatisticsType.State, this.stateFilter.getSelected()));
  }
}
