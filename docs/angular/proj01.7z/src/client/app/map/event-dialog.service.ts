// tslint:disable:no-trailing-whitespace
import { Injectable } from '@angular/core';
import {DialogService} from '../spi/impl/dialog.service';
import {EventDialogComponent} from './event-dialog/event-dialog.component';

/**
 * EventDialog service.
 * @author Stephan Petzchen
 */
@Injectable()
export class EventDialogService extends DialogService<EventDialogComponent> {
}
