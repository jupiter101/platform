import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import {
  MdButtonModule, MdCheckboxModule, MdDialogModule, MdProgressBarModule, MdRadioModule, MdSidenavModule,
  MdTabsModule
} from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { ApiService } from './spi/impl/api.service';
import { AuthService } from './spi/impl/auth.service';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './auth.guard';
import { MapComponent } from './map/map.component';
import { MapService } from './spi/impl/map.service';

// import 'leaflet';
import { StateFilterComponent } from './map/state-filter/state-filter.component';
import { BrandFilterComponent } from './map/brand-filter/brand-filter.component';
import { StateFilterService } from './spi/impl/state-filter.service';
import { BrandFilterService } from './spi/impl/brand-filter.service';
import { StatApiService } from './spi/impl/statistic-api.service';
import { DeDecimalFormater, DeIntegerFormater} from './map/pipes/de-number-format.pipe';
import { StatDialogComponent } from './map/stat-dialog/stat-dialog.component';
import { EventDialogComponent } from './map/event-dialog/event-dialog.component';
import { StatisticDialogService } from './map/statistic-dialog.service';
import { EventDialogService } from './map/event-dialog.service';
import {ErrorDialogService} from './map/error-dialog.service';
import { EventApiService } from './spi/impl/event-api.service';
import { GeoApiService } from './spi/impl/geo-api.service';
import { IApiService } from './spi/api-service.spi';
import { IMapService } from './spi/map-service.spi';
import { IAuthService } from './spi/auth.service.spi';
import { ErrorDialogComponent } from './map/error-dialog/error-dialog.component';
import {UrlService} from './spi/impl/url.service';



@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    LoginComponent,
    MapComponent,
    StateFilterComponent,
    BrandFilterComponent,
    StatDialogComponent,
    DeIntegerFormater, DeDecimalFormater, EventDialogComponent, ErrorDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    MdButtonModule, MdRadioModule, MdCheckboxModule, MdSidenavModule, MdTabsModule, MdDialogModule, MdProgressBarModule,
    AppRoutingModule
  ],
  entryComponents: [
    StatDialogComponent, EventDialogComponent
  ],
  providers: [
    { provide: 'IApiService', useClass: ApiService },
    { provide: 'IStatisticApiService', useClass: StatApiService },
    { provide: 'IEventApiService', useClass: EventApiService },
    { provide: 'IGeoApiService', useClass: GeoApiService },
    { provide: 'IStateFilterService', useClass: StateFilterService },
    { provide: 'IBrandFilterService', useClass: BrandFilterService },
    { provide: 'IMapService', useClass: MapService },
    { provide: 'IDialogService<ErrorDialogComponent>', useClass: ErrorDialogService },
    { provide: 'IDialogService<StatDialogComponent>', useClass: StatisticDialogService },
    { provide: 'IDialogService<EventDialogComponent>', useClass: EventDialogService },
    { provide: 'IUrlService', useClass: UrlService },
    { provide: 'IAuthService', useClass: AuthService },
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
