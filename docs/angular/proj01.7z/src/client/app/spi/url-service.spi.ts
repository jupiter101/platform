// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
export interface IUrlService {
  get(): string;
  getParameter(param: string, isBase64: boolean): string;
}
