// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 *
 * @see http://jasonwatmore.com/post/2016/12/01/angular-2-communicating-between-components-with-observable-subject
 *
 * @author Stephan Petzchen
 */
export interface IMessagingApiService {
  get(): any;
  send(msg: any);
}
