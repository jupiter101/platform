
import {StatisticsType} from '../map/model/stat.model';
import {EventAggregationType} from '../map/model/event.model';
import {EventEmitter, ViewContainerRef} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {ErrorType} from '../map/model/error.model';

/**
 * Generic Dialog type interface.
 * @author Stephan Petzchen
 */
export interface DialogType<T> {
  new (...args: any[]): T;
}

/**
 * Dialog paramter interface.
 * @author Stephan Petzchen
 */
export interface IDialogEventParameter<T>{
  dialogType: DialogType<T>;
  viewType: StatisticsType | EventAggregationType | ErrorType | null;
  parameter: any;
  dialogWidth?: string;
}

/**
 * Service interface for managing dialogs.
 * @author Stephan Petzchen
 */
export interface IDialogService<T>{
  ShowDialogRequestEvent: EventEmitter<IDialogEventParameter<T>>;
  showDialog(viewContainerRef: ViewContainerRef, dialogComponent: DialogType<T>, data: IDialogEventParameter<T>): Observable<boolean>;
}
