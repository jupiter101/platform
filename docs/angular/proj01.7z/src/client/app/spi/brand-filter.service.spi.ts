
import {EventEmitter} from '@angular/core';
import {IBrandFilter} from '../map/model/brand-filter.model';

/**
 * Service interface for administering the brand filtering.
 *
 * @author Stephan Petzchen
 */
export interface IBrandFilterService {
  brandFilter: IBrandFilter;
  BrandFilterChangeEvent: EventEmitter<IBrandFilter>;
}
