import {Observable} from 'rxjs/Observable';

/**
 * API service interface for retrieving statistic data from the server.
 *
 *
 * @author Stephan Petzchen
 */
export interface IStatisticApiService {
  getAreaStatistics(): Observable<any>;
  getStateStatistics(id: number): Observable<any>;
  getBrandStatistics(id: string): Observable<any>;
}
