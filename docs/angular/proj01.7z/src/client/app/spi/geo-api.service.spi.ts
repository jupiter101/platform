// tslint:disable:no-trailing-whitespace
import {Observable} from 'rxjs/Observable';

/**
 * Defines the service interface for retrieving geo data.
 * @author Stephan Petzchen
 */
export interface IGeoApiService {
  get(type: GeoDataRequestType, filter: GeoDataFilterType, params?: IGeoDataRequestParameter): Observable<any>;
}

/**
 * Defines the kind of geo data request required.
 * @author Stephan Petzchen
 */
export enum GeoDataRequestType {
  CITIES,
  VENUES
}

/**
 * Defines the kind of geo data filter required.
 * @author Stephan Petzchen
 */
export enum GeoDataFilterType {
  NONE,
  STATE,
  BRAND,
  ALL
}

/**
 * Defines the geo data request parameter type.
 * @author Stephan Petzchen
 */
export interface IGeoDataRequestParameter {
  state: number;
  brands: string;
}


