// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IStateFilterItem} from '../map/model/state-filter.model';
import {IBrandFilter} from '../map/model/brand-filter.model';

/**
 * API service interface for Map service.
 *
 * @author Stephan Petzchen
 */
export interface IMapService {
  createMap(options?: any);
  destroyMap();
  applyStateFilter(e: IStateFilterItem);
  applyBrandFilter(e: IBrandFilter);
}
