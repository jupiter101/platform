// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Observable} from 'rxjs/Observable';

/**
 * Service interface for svg icon registration and caching.
 *
 * @author Stephan Petzchen
 */
export interface IIconRegistryService<T> {
  load(url: string): Observable<T>;
  unload(url: string);
}
