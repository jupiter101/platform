
import {Observable} from 'rxjs/Observable';

/**
 * API service interface for retrieving event data from the server.
 *
 *
 * @author Stephan Petzchen
 */
export interface IEventApiService {
  getCityEvents(id: number, brand_ids?: string): Observable<any>;
  getVenueEvents(id: number, brand_ids?: string): Observable<any>;
}
