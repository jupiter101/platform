import {EventEmitter, Injectable, ViewContainerRef} from '@angular/core';
import {MdDialog, MdDialogConfig, MdDialogRef} from '@angular/material';
import {Observable} from 'rxjs/Observable';
import {DialogType, IDialogEventParameter, IDialogService} from '../dialog.service.spi';

/**
 * Generic Implementation of the IDialogService service interface
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class DialogService<T> implements IDialogService<T> {

  /**
   * Event declaration for subscriber and publisher.
   * @type {EventEmitter<IDialogEventParameter<T>>}
   *
   * @author Stephan Petzchen
   */
  ShowDialogRequestEvent: EventEmitter<IDialogEventParameter<T>> = new EventEmitter();

  constructor(private dialog: MdDialog) { }

  /**
   * Generic method to open the dialog.
   * @param {ViewContainerRef} viewContainerRef view container reference
   * @param {DialogType<T>} dialogComponent the dialog component to open
   * @param {IDialogEventParameter<T>} data the dialog paramter
   * @returns {Observable<boolean>}
   *
   * @author Stephan Petzchen
   */
  public showDialog(viewContainerRef: ViewContainerRef,
                    dialogComponent: DialogType<T>,
                    data: IDialogEventParameter<T>): Observable<boolean> {

    let dialogRef: MdDialogRef<T>;
    const config = new MdDialogConfig();
    config.viewContainerRef = viewContainerRef;
    config.disableClose = false;
    config.width = data.dialogWidth;
    config.data = data;

    dialogRef = this.dialog.open<T>(dialogComponent, config);
    return dialogRef.afterClosed();

  }

}
