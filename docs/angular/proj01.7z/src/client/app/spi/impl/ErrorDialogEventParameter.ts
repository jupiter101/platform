// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:interface-over-type-literal
import {DialogType, IDialogEventParameter} from '../dialog.service.spi';
import {ErrorDialogComponent} from '../../map/error-dialog/error-dialog.component';
import {ErrorType} from '../../map/model/error.model';

export type ErrorParameterType = {errMessage: string};

/**
 *
 */
export class ErrorDialogEventParameter implements IDialogEventParameter<ErrorDialogComponent> {
  dialogType: DialogType<ErrorDialogComponent>;
  viewType: ErrorType;
  parameter: ErrorParameterType;
  dialogWidth: string;

  /**
   *
   * @param {ErrorType} viewType
   * @param {ErrorParameterType} params
   */
  constructor(viewType: ErrorType, params: ErrorParameterType) {
    this.viewType = viewType;
    this.parameter = params;
    this.dialogWidth = '350px';
  }
}
