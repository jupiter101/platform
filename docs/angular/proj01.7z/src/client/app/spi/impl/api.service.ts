// tslint:disable:no-trailing-whitespace
import { Inject, Injectable } from '@angular/core';
import { Http, Request, RequestOptions, RequestMethod, Response, Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import { IApiService } from '../api-service.spi';
import { IAuthService } from '../auth.service.spi';
import {ErrorDialogComponent} from '../../map/error-dialog/error-dialog.component';
import {IDialogService} from '../dialog.service.spi';

/**
 * Implementation of the IApiService service interface.
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class ApiService implements IApiService {
  private apiUrl: string = environment.apiUrl;
  constructor(@Inject('IAuthService') private auth: IAuthService,
              @Inject('IDialogService<ErrorDialogComponent>') private errDialogService: IDialogService<ErrorDialogComponent>,
              private http: Http) { }

  /**
   * Http get service method.
   * @param {string} url
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  get(url: string) {
    return this.request(url, RequestMethod.Get);
  }

  /**
   * Http post service method.
   * @param {string} url
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  post(url: string, body: Object ) {
    return this.request(url, RequestMethod.Post, body);
  }

  /**
   * Http put service method.
   * @param {string} url
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  put(url: string, body: Object) {
    return this.request(url, RequestMethod.Put);
  }

  /**
   * Http delete service method.
   * @param {string} url
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  delete(url: string) {
    return this.request(url, RequestMethod.Delete);
  }


  /**
   * Centralized request helper for api calls.
   * @param {string} url
   * @param {RequestMethod} method
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  private request(url: string, method: RequestMethod, body?: Object) {
    const headers: Headers = new Headers();
    headers.append('Content-Type', 'application/json');
    headers.append('Authorization', `Bearer ${this.auth.getToken()}`);

    if (this.auth.isLoggedIn()) {
      headers.append('Midas-Access', `${this.auth.getToken()}`);
    }


    const requestOptions: RequestOptions = new RequestOptions({
      url: `${ this.apiUrl }/${url}`,
      method: method,
      headers: headers
    });
    if (body) {
      requestOptions.body = body;
    }

    const request: Request = new Request(requestOptions);

    return this.http.request(request)
      .map((resp: Response) => resp.json())
      .catch((resp: Response) => this.onRequestError(resp));
  }

  /**
   * Centralized error handler.
   * @param {Response} resp
   * @returns {Observable<{errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  private onRequestError(resp: Response) {
    const statusCode = resp.status;
    const body = resp.json();

    const error = {
      errorCode: statusCode,
      error: body.error
    };
    return Observable.throw(error);
  }
}
