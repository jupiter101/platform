// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Injectable} from '@angular/core';
import {IIconRegistryService} from '../icon-registry.service.spi';
import {Observable} from 'rxjs/Observable';
import {Http, Response} from '@angular/http';

import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/share';

/**
 * Registry to load and cache svg icons from url
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class SVGIconRegistryService implements IIconRegistryService<SVGElement> {

  private iconCache = new Map<string, SVGElement>();
  private iconRepository = new Map<string, Observable<SVGElement>>();

  constructor(private http: Http) {
  }

  load(url: string): Observable<SVGElement> {
    if (this.iconCache.has(url)) {
      return Observable.of(this.iconCache.get(url));
    } else if (this.iconRepository.has(url)) {
      return this.iconRepository.get(url);
    } else {
      const o = <Observable<SVGElement>> this.http.get( url )
        .map( (res: Response) => {
          const div = document.createElement('DIV');
          div.innerHTML = res.text();
          return <SVGElement>div.querySelector('svg');
        })
        .do(svg => {
          this.iconCache.set(url, svg);
        })
        .finally(() => {
          this.iconRepository.delete(url);
        })
        .share();

      this.iconRepository.set(url, o);
      return o;
    }
  }

  unload(url: string) {
    if (this.iconCache.has(url)) {
      this.iconCache.delete(url);
    }
  }
}
