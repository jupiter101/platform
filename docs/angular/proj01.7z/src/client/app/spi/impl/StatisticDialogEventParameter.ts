
import {DialogType, IDialogEventParameter} from '../dialog.service.spi';
import {StatDialogComponent} from '../../map/stat-dialog/stat-dialog.component';
import {StatisticsType} from '../../map/model/stat.model';
import {IStateFilterItem} from '../../map/model/state-filter.model';
import {IBrandFilterItem} from '../../map/model/brand-filter.model';


/**
 * StatisticDialog event parameter.
 * @author Stephan Petzchen
 */
export class StatisticDialogEventParameter implements IDialogEventParameter<StatDialogComponent> {
  dialogType: DialogType<StatDialogComponent>;
  viewType: StatisticsType;
  parameter: IStateFilterItem | IBrandFilterItem[];
  dialogWidth: string;

  /**
   * Custom StatisticDialogEventParameter constructor.
   * @param {StatisticsType} viewType
   * @param params
   */
  constructor(viewType: StatisticsType, params?: any) {
    this.viewType = viewType;
    this.parameter = params;
    this.dialogWidth = '400px';
  }
}
