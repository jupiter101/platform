// tslint:disable:no-trailing-whitespace
import {EventEmitter, Injectable} from '@angular/core';
import {IStateFilterService, MapBBoxFormat, MapDirection} from '../state-filter.service.spi';
import {IStateFilter, IStateFilterItem, StateFilter} from '../../map/model/state-filter.model';


/**
 * Implementation of the IStateFilterService service interface.
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class StateFilterService implements IStateFilterService {
  stateFilter: IStateFilter = new StateFilter();
  StateFilterChangeEvent: EventEmitter<IStateFilterItem> = new EventEmitter();
  constructor() {}

  /**
   * Retrieve the bounding box setting for the given state.
   * @param {number} state
   * @param {MapBBoxFormat} format
   * @returns {L.LatLngBounds}
   *
   * @author Stephan Petzchen
   */
  getBBox(state: number, format?: MapBBoxFormat) {
    const mfmt: MapBBoxFormat = (format) ? format : MapBBoxFormat.SWNE;

    switch (format) {
      case MapBBoxFormat.SWNE:
        return L.latLngBounds(
          L.latLng(this.stateFilter.stateBBoxMap.get(state).bbox.get(MapDirection.SOUTH), this.stateFilter.stateBBoxMap
            .get(state).bbox.get(MapDirection.WEST)),
          L.latLng(this.stateFilter.stateBBoxMap.get(state).bbox.get(MapDirection.NORTH), this.stateFilter.stateBBoxMap
            .get(state).bbox.get(MapDirection.EAST)));
      default:
        return L.latLngBounds(
          L.latLng(this.stateFilter.stateBBoxMap.get(state).bbox.get(MapDirection.NORTH), this.stateFilter.stateBBoxMap
            .get(state).bbox.get(MapDirection.WEST)),
          L.latLng(this.stateFilter.stateBBoxMap.get(state).bbox.get(MapDirection.SOUTH), this.stateFilter.stateBBoxMap
            .get(state).bbox.get(MapDirection.EAST)));

    }
  }

  /**
   * Retrieve the center setting for the given state.
   * @param {number} state
   * @returns {L.LatLng}
   *
   * @author Stephan Petzchen
   */
  getCenter(state: number) {
    return L.latLng(this.stateFilter.stateBBoxMap.get(state).center.lat, this.stateFilter.stateBBoxMap.get(state).center.long);
  }

  /**
   * Retrieve the zoom setting for the given state.
   * @param {number} state
   * @returns {number}
   *
   * @author Stephan Petzchen
   */
  getZoom(state: number): number {
    return this.stateFilter.stateBBoxMap.get(state).zoom;
  }

}



