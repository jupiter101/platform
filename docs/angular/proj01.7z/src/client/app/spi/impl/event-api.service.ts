import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {IEventApiService} from '../event-api.service.spi';
import {IApiService} from '../api-service.spi';

/**
 * Implementation of the IEventApiService service interface.
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class EventApiService implements IEventApiService {

  constructor(@Inject('IApiService') private apiService: IApiService) { }

  /**
   * Retrieve city event data optionally for single brand.
   * @param {string} id
   * @param {string} [brand_ids] optional brand id parameter
   * @returns {Observable<any>}
   *
   * @author Stephan Petzchen
   */
  getCityEvents(id: number, brand_ids?: string): Observable<any> {
    if (brand_ids) {
      return this.apiService.get(`events/cities/${id}/brands/${brand_ids}`);
    }else {
      return this.apiService.get(`events/cities/${id}`);
    }
  }

  /**
   * Retrieve venue event data optionally for single brand.
   * @param {string} id
   * @param {string} brand_id
   * @returns {Observable<any>}
   *
   * @author Stephan Petzchen
   */
  getVenueEvents(id: number, brand_ids?: string): Observable<any> {
    if (brand_ids) {
      return this.apiService.get(`events/venues/${id}/brands/${brand_ids}`);
    }else {
      return this.apiService.get(`events/venues/${id}`);
    }
  }
}
