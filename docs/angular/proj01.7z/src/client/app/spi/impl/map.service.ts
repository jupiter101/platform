// tslint:disable:no-trailing-whitespace
import {Inject, Injectable, OnDestroy} from '@angular/core';
import {EventsMap} from '../../map/core/map';
import {GeoApiService} from './geo-api.service';
import {EventApiService} from './event-api.service';
import {IDialogService} from '../dialog.service.spi';
import {EventDialogComponent} from '../../map/event-dialog/event-dialog.component';
import {StateFilterService} from './state-filter.service';

import {IApiService} from '../api-service.spi';
import {IStateFilterItem} from '../../map/model/state-filter.model';
import {IBrandFilter} from '../../map/model/brand-filter.model';
import {IStateFilterService} from '../state-filter.service.spi';
import {IBrandFilterService} from '../brand-filter.service.spi';
import {IGeoApiService} from '../geo-api.service.spi';
import {IMapService} from '../map-service.spi';
import {ErrorDialogComponent} from '../../map/error-dialog/error-dialog.component';


/**
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class MapService implements IMapService, OnDestroy {
  private evtMap: EventsMap;
  private subscriptions: any[] = [];
  // private map: Native.Leaflet.Map;

  constructor(@Inject('IApiService')private apiService: IApiService,
              @Inject('IGeoApiService')private geoApiService: GeoApiService,
              @Inject('IStateFilterService')private stateFilterApiService: StateFilterService,
              @Inject('IBrandFilterService')private brandFilterApiService: IBrandFilterService,
              @Inject('IEventApiService')private eventApiService: EventApiService,
              @Inject('IDialogService<EventDialogComponent>') private evdialogService: IDialogService<EventDialogComponent>) {

    this.subscriptions[0] = this.stateFilterApiService.StateFilterChangeEvent
      .subscribe(data  => this.applyStateFilter(data));

    this.subscriptions[0] = this.brandFilterApiService.BrandFilterChangeEvent
      .subscribe(data  => this.applyBrandFilter(data));

  }


  /**
   * Dispose observable subscriptions.
   * @author Stephan Petzchen
   */
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  // ############################ Map Lifecycle Methods ############################
  /**
   * Initialize the event map
   * @author Stephan Petzchen
   */
  createMap(options?: any) {
    this.evtMap = new EventsMap(
      {geoApiService: <IGeoApiService>this.geoApiService,
        eventsDialogService: this.evdialogService,
        filter: {state: <StateFilterService> this.stateFilterApiService, brand: this.brandFilterApiService}
      });
    this.evtMap.render();
  }

  /**
   * Destroys the map
   * @author Stephan Petzchen
   */
  destroyMap() {
    this.evtMap.destroy();
    delete this.evtMap;
  }


  applyStateFilter(e: IStateFilterItem) {
    // this.evtMap.setStateVisibility(e);
    this.evtMap.render();
  }

  applyBrandFilter(e: IBrandFilter) {
    this.evtMap.render();
  }

}






