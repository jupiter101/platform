import {EventEmitter, Injectable} from '@angular/core';
import {IBrandFilterService} from '../brand-filter.service.spi';
import {BrandFilter, IBrandFilter} from '../../map/model/brand-filter.model';



@Injectable()
export class BrandFilterService implements IBrandFilterService {
  brandFilter: IBrandFilter = new BrandFilter();
  BrandFilterChangeEvent: EventEmitter<IBrandFilter> = new EventEmitter();
}
