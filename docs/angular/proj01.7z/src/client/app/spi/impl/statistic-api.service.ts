import {Inject, Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {IStatisticApiService} from '../statistic-api.service.spi';
import {IApiService} from '../api-service.spi';

/**
 * API service class for serving statistic data from the server.
 *
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class StatApiService implements IStatisticApiService {
  constructor(@Inject('IApiService')private apiService: IApiService) { }

  /**
   * Retrieve area statistics.
   * @returns {Observable<any>}
   *
   * @author Stephan Petzchen
   */
  getAreaStatistics(): Observable<any> {
    return this.apiService.get('stats');
  }

  /**
   * Retrieve state statistics.
   * @param {string} id state id
   * @returns {Observable<any>}
   *
   * @author Stephan Petzchen
   */
  getStateStatistics(id: number): Observable<any> {
    return this.apiService.get(`stats/states/${id}`);
  }

  /**
   * Retrieve brand statistics.
   * @param {string} id list of brand ids
   * @returns {Observable<any>}
   *
   * @author Stephan Petzchen
   */
  getBrandStatistics(id: string): Observable<any> {
    return this.apiService.get(`stats/brands/${id}`);
  }

}
