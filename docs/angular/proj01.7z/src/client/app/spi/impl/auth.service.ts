// tslint:disable:no-bitwise
// tslint:disable:no-inferrable-types
// tslint:disable:no-trailing-whitespace
import {EventEmitter, Inject, Injectable} from '@angular/core';
import {Router} from '@angular/router';
import {IAuthService} from '../auth.service.spi';
import {IUrlService} from '../url-service.spi';

@Injectable()
export class AuthService implements IAuthService {

  storageKeyToken: string = 'auth:token';
  storageKeyIAt: string = 'auth:iat';
  storageKeyExpAt: string = 'auth:exp';
  storageKeyScope: string = 'auth:scope';
  AuthEvent: EventEmitter<boolean> = new EventEmitter();
  jwtUtil: JwtHelper = new JwtHelper();

  constructor(private router: Router, @Inject('IUrlService') private urlService: IUrlService) { }

  /**
   * Setting the token data
   * @param {string} token
   * @param {string} expAt
   * @param {string} scope
   * @param {string} iat
   */
  setToken(token: string, expAt: string, scope: string, iat: string) {

    // console.log('#####setToken: ');
    // console.log(token);
    // console.log('#####');
    localStorage.setItem(this.storageKeyToken, token);
    localStorage.setItem(this.storageKeyIAt, iat);
    localStorage.setItem(this.storageKeyExpAt, expAt);
    localStorage.setItem(this.storageKeyScope, scope);
    this.AuthEvent.emit(true);
  }

  /**
   *
   */
  getToken() {
    return localStorage.getItem(this.storageKeyToken);
  }

  /**
   *
   * @returns {boolean}
   */
  isLoggedIn(): boolean {
    console.log('#####isLoggedIn: ');
    if (this.getToken() != null) {
      console.log('authenticated!: ' + this.getToken());
    }
    // if (this.isExpired()) {
    //   this.clearTokenSession();
    //   this.AuthEvent.emit(false);
    //   return false;
    // }
    return this.getToken() != null;
  }

  /**
   *
   */
  logout(): void {
    this.clearTokenSession();
    this.AuthEvent.emit(false);
    this.router.navigate(['/login']);
  }

  preauth(): void {
    // this.setToken(this.urlService.getParameter('midasAccess', true), '', 'midas', '');
    this.setToken(this.urlService.getParameter('midasAccess', false), '', 'midas', '');
  }

  private isExpired(): boolean {
    const expiresAt = localStorage.getItem(this.storageKeyExpAt);
    return new Date().getTime() >= (expiresAt == null ? 0 : Number(expiresAt));
  }

  private clearTokenSession() {
    localStorage.removeItem(this.storageKeyToken);
    localStorage.removeItem(this.storageKeyIAt);
    localStorage.removeItem(this.storageKeyExpAt);
    localStorage.removeItem(this.storageKeyScope);
  }
}

/**
 * Helper class to decode and find JWT expiration.
 */
class JwtHelper {

  public urlBase64Decode(str: string): string {
    let output = str.replace(/-/g, '+').replace(/_/g, '/');
    switch (output.length % 4) {
      case 0: { break; }
      case 2: { output += '=='; break; }
      case 3: { output += '='; break; }
      default: {
        throw new Error('Illegal base64url string!');
      }
    }
    return this.b64DecodeUnicode(output);
  }

  // credits for decoder goes to https://github.com/atk
  private b64decode(str: string): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    let output: string = '';

    str = String(str).replace(/=+$/, '');

    if (str.length % 4 === 1) {
      throw new Error('atob failed: The string to be decoded is not correctly encoded.');
    }

    for (
      // initialize result and counters
      let bc: number = 0, bs: any, buffer: any, idx: number = 0;
      // get next character
      buffer = str.charAt(idx++);
      // character found in table? initialize bit storage and add its ascii value;
      ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer,
        // and if not first of each 4 characters,
        // convert the first 8 bits to one ascii character
      bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0
    ) {
      // try to find character in table (0-63, not found => -1)
      buffer = chars.indexOf(buffer);
    }
    return output;
  }

  // https://developer.mozilla.org/en/docs/Web/API/WindowBase64/Base64_encoding_and_decoding#The_Unicode_Problem
  private b64DecodeUnicode(str: any) {
    return decodeURIComponent(Array.prototype.map.call(this.b64decode(str), (c: any) => {
      return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
  }

  public decodeToken(token: string): any {
    const parts = token.split('.');

    if (parts.length !== 3) {
      throw new Error('JWT must have 3 parts');
    }

    const decoded = this.urlBase64Decode(parts[1]);
    if (!decoded) {
      throw new Error('Cannot decode the token');
    }

    return JSON.parse(decoded);
  }

  public getTokenExpirationDate(token: string): Date {
    let decoded: any;
    decoded = this.decodeToken(token);

    if (!decoded.hasOwnProperty('exp')) {
      return null;
    }

    const date = new Date(0); // The 0 here is the key, which sets the date to the epoch
    date.setUTCSeconds(decoded.exp);

    return date;
  }

  public isTokenExpired(token: string, offsetSeconds?: number): boolean {
    const date = this.getTokenExpirationDate(token);
    offsetSeconds = offsetSeconds || 0;

    if (date == null) {
      return false;
    }

    // Token expired?
    return !(date.valueOf() > (new Date().valueOf() + (offsetSeconds * 1000)));
  }
}
