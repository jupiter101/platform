// tslint:disable:interface-over-type-literal
import {EventAggregationType} from '../../map/model/event.model';
import {DialogType, IDialogEventParameter} from '../dialog.service.spi';
import {ICity} from '../../map/model/city.model';
import {IVenue} from '../../map/model/venue.model';
import {EventDialogComponent} from '../../map/event-dialog/event-dialog.component';
import {IBrandFilter} from '../../map/model/brand-filter.model';

export type EventsParameterType = {ref: ICity | IVenue, brandFilter: IBrandFilter};

/**
 * EventDialog event parameter.
 * @author Stephan Petzchen
 */
export class EventsDialogEventParameter implements IDialogEventParameter<EventDialogComponent> {
  dialogType: DialogType<EventDialogComponent>;
  viewType: EventAggregationType;
  parameter: EventsParameterType;
  dialogWidth: string;

  /**
   * Custom EventsDialogEventParameter constructor.
   * @param {EventAggregationType} viewType
   * @param {EventsParameterType} params
   */
  constructor(viewType: EventAggregationType, params: EventsParameterType) {
    this.viewType = viewType;
    this.parameter = params;
    this.dialogWidth = '650px';
  }
}
