// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IUrlService} from '../url-service.spi';
import {Injectable} from '@angular/core';

@Injectable()
export class UrlService implements IUrlService {

  get(): string {
    return window.location.href;
  }

  getParameter(param: string, isBase64: boolean): string {
    const url = window.location.href;
    const name = param.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
      results = regex.exec(url);
    if (!results) { return null; }
    if (!results[2]) { return ''; }

    if (isBase64) {
      const raw = decodeURIComponent(results[2].replace(/\+/g, ' '));
      // console.log('########getParameter:');
      // console.log(param);
      // console.log(raw);
      // console.log(atob(raw));
      // console.log('########');
      return atob(raw);
    }

    return decodeURIComponent(results[2].replace(/\+/g, ' '));
  }

}
