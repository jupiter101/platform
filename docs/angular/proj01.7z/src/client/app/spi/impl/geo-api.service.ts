// tslint:disable:no-trailing-whitespace
import {Inject, Injectable} from '@angular/core';
import {GeoDataFilterType, GeoDataRequestType, IGeoApiService, IGeoDataRequestParameter} from '../geo-api.service.spi';
import {Observable} from 'rxjs/Observable';
import {IApiService} from '../api-service.spi';

@Injectable()
export class GeoApiService implements IGeoApiService {
  constructor(@Inject('IApiService')private apiService: IApiService) {}
  get(type: GeoDataRequestType = GeoDataRequestType.CITIES,
      filter: GeoDataFilterType = GeoDataFilterType.NONE,
      params?: IGeoDataRequestParameter): Observable<any> {
    switch (type) {
      case GeoDataRequestType.CITIES:
        switch (filter) {
          case GeoDataFilterType.STATE:
            return this.getCitiesByState(params.state);
          case GeoDataFilterType.BRAND:
            return this.getCitiesByBrand(params.brands);
          case GeoDataFilterType.ALL:
            return this.getCitiesByStateAndBrand(params.state, params.brands);
          default:
            return this.getCities();
        }
      case GeoDataRequestType.VENUES:
        switch (filter) {
          case GeoDataFilterType.STATE:
            return this.getVenuesByState(params.state);
          case GeoDataFilterType.BRAND:
            return this.getVenuesByBrand(params.brands);
          case GeoDataFilterType.ALL:
            return this.getVenuesByStateAndBrand(params.state, params.brands);
          default:
            return this.getVenues();
        }
    }
  }

  private getCities(): Observable<any> {
    return this.apiService.get('geo/cities');
  }

  private getCitiesByState(state: number): Observable<any> {
    return this.apiService.get(`geo/cities/states/${state}`);
  }

  private getCitiesByBrand(brands: string): Observable<any> {
    return this.apiService.get(`geo/cities/brands/${brands}`);
  }

  private getCitiesByStateAndBrand(state: number, brands: string): Observable<any> {
    return this.apiService.get(`geo/cities/states/${state}/brands/${brands}`);
  }

  private getVenues(): Observable<any> {
    return this.apiService.get('geo/venues');
  }

  private getVenuesByState(state: number): Observable<any> {
    return this.apiService.get(`geo/venues/states/${state}`);
  }

  private getVenuesByBrand(brands: string): Observable<any> {
    return this.apiService.get(`geo/venues/brands/${brands}`);
  }

  private getVenuesByStateAndBrand(state: number, brands: string): Observable<any> {
    return this.apiService.get(`geo/venues/states/${state}/brands/${brands}`);
  }

}
