
import {IStateFilter, IStateFilterItem} from '../map/model/state-filter.model';
import {EventEmitter} from '@angular/core';

/**
 * Service interface for administering the state filtering.
 *
 * @author Stephan Petzchen
 */
export interface IStateFilterService {
  stateFilter: IStateFilter;
  StateFilterChangeEvent: EventEmitter<IStateFilterItem>;
  getBBox(state: number, format?: MapBBoxFormat);
  getCenter(state: number);
  getZoom(state: number);
}

/**
 * Bounded Box format types.
 * @author Stephan Petzchen
 */
export enum MapBBoxFormat {
  NWSE,
  SWNE
}

/**
 * Map direction indicator.
 * @author Stephan Petzchen
 */
export enum MapDirection {
  NORTH,
  WEST,
  SOUTH,
  EAST
}

/**
 * Custom type for the states bounded box map.
 * @author Stephan Petzchen
 */
export type StateBBoxMap = Map<number, {bbox: Map<MapDirection, number>, center: {lat: number, long: number}, zoom: number}>;


