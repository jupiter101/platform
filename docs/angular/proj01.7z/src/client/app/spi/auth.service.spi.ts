// tslint:disable:no-trailing-whitespace
import {EventEmitter} from '@angular/core';

export interface IAuthService {
  AuthEvent: EventEmitter<boolean>;
  setToken(token: string, expAt: string, scope: string, iat: string);
  getToken(): string;
  isLoggedIn(): boolean;
  logout(): void;
  preauth(): void;
}
