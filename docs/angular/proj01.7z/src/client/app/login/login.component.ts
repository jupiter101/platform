// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnInit} from '@angular/core';
import {NgForm} from '@angular/forms';
import {Router} from '@angular/router';
import {IAuthService} from '../spi/auth.service.spi';
import {IApiService} from '../spi/api-service.spi';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(@Inject('IApiService') private api: IApiService,
              @Inject('IAuthService') private auth: IAuthService,
              private router: Router) {
  }

  ngOnInit() {
    if (this.auth.isLoggedIn()) {
      this.router.navigate(['/map']);
    }
  }

  onSubmit(form: NgForm) {
    const values = Object.assign({}, form.value);

    const payload = {
      username: values.username,
      password: values.password
    };

    this.api.post('authenticate', payload)
      .subscribe( data => {
        this.auth.setToken(data.token, data.expAt, data.scope, data.iat);
        this.router.navigate(['/map']);
      });
  }
}
