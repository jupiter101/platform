// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

/**
 * Tide date format pattern and translation keys.
 * From: eu.eurogate.tide.base.basic.i18n.date.TIDEDateFormat
 *
 * @author stephan.petzchen@extern.eurogate.eu
 */
// export namespace TIDEDateFormat {
//   export const DOW_Y_M_D = 'dow_y_m_d';
//   export const SDOW_Y_M_D = 'sdow_y_m_d';
//   export const SDOW_H_M_S = 'sdow_h_m_s';
//   export const SDOW_H_M = 'sdow_h_m';
//   export const SDOW_H = 'sdow_h';
//   export const SDOW = 'sdow';
//   export const Y_M_D_H_M_S = 'y_m_d_h_m_s';
//   export const Y_M_D_H_M = 'y_m_d_h_m';
//   export const Y_M_D_HM = 'y_m_d_hm';
//   export const Y_M_D_H = 'y_m_d_h';
//   export const Y_M_D = 'y_m_d';
//   export const YMD_H_M = 'ymd_h_m';
//   export const YMDHM = 'ymdhm';
//   export const YMD_HM = 'ymd_hm';
//   export const YMDHMS = 'ymdhms';
//   export const YMD_HMS = 'ymd_hms';
//   export const YMD_H = 'ymd_h';
//   export const YMD = 'ymd';
//   export const SYMD_H_M = 'symd_h_m';
//   export const SYMD_HM = 'symd_hm';
//   export const SYMD_H = 'symd_h';
//   export const SYMD = 'symd';
//   export const SY_M_D_H_M = 'sy_m_d_h_m';
//   export const SY_M_D = 'sy_m_d';
//   export const M_D_H_M_S = 'm_d_h_m_s';
//   export const M_D_H_M = 'm_d_h_m';
//   export const M_D_H = 'm_d_h';
//   export const M_D = 'm_d';
//   export const D_H_M_S = 'd_h_m_s';
//   export const D_H_M = 'd_h_m';
//   export const D_H = 'd_h';
//   export const H_M_S = 'h_m_s';
//   export const HMS = 'hms';
//   export const H_M = 'h_m';
//   export const HM = 'hm';
//   export const M_S = 'm_s';
//   export const YEAR = 'year';
//   export const MONTH = 'month';
//   export const DAY = 'day';
//   export const HOUR = 'hour';
//   export const MINUTE = 'minute';
//   export const SECOND = 'second';
//   export const PAST_CURRENT_M_D = 'past_current_m_d';
//   export const PAST_CURRENT_M_D2 = 'past_current_m_d.2';
//   export const PAST_CURRENT_MD = 'past_current_md';
//   export const PAST_CURRENT_MONTH = 'past_current_month';
//   export const PAST_CURRENT_DAY = 'past_current_day';
//   export const PAST_M_D = 'past_m_d';
//   export const PAST_M_D2 = 'past_m_d.2';
//   export const PAST_MD = 'past_md';
//   export const PAST_MONTH = 'past_month';
//   export const PAST_DAY = 'past_day';
//   export const CURRENT_M_D = 'current_m_d';
//   export const CURRENT_M_D2 = 'current_m_d.2';
//   export const CURRENT_MD = 'current_md';
//   export const CURRENT_MONTH = 'current_month';
//   export const CURRENT_DAY = 'current_day';
//   export const FUTURE_M_D = 'future_m_d';
//   export const FUTURE_M_D2 = 'future_m_d.2';
//   export const FUTURE_MD = 'future_md';
//   export const FUTURE_MONTH = 'future_month';
//   export const FUTURE_DAY = 'future_day';
//   export const FUTURE_CURRENT_M_D = 'future_current_m_d';
//   export const FUTURE_CURRENT_M_D2 = 'future_current_m_d.2';
//   export const FUTURE_CURRENT_MD = 'future_current_md';
//   export const FUTURE_CURRENT_MONTH = 'future_current_month';
//   export const FUTURE_CURRENT_DAY = 'future_current_day';
//   export const Y_M = 'y_m';
//   export const YM = 'ym';
//   export const SY_M = 'sy_m';
//   export const SYM = 'sym';
// }

export const enum TIDEDateFormat {
  DOW_Y_M_D = 'dow_y_m_d',
  SDOW_Y_M_D = 'sdow_y_m_d',
  SDOW_H_M_S = 'sdow_h_m_s',
  SDOW_H_M = 'sdow_h_m',
  SDOW_H = 'sdow_h',
  SDOW = 'sdow',
  Y_M_D_H_M_S = 'y_m_d_h_m_s',
  Y_M_D_H_M = 'y_m_d_h_m',
  Y_M_D_HM = 'y_m_d_hm',
  Y_M_D_H = 'y_m_d_h',
  Y_M_D = 'y_m_d',
  YMD_H_M = 'ymd_h_m',
  YMDHM = 'ymdhm',
  YMD_HM = 'ymd_hm',
  YMDHMS = 'ymdhms',
  YMD_HMS = 'ymd_hms',
  YMD_H = 'ymd_h',
  YMD = 'ymd',
  SYMD_H_M = 'symd_h_m',
  SYMD_HM = 'symd_hm',
  SYMD_H = 'symd_h',
  SYMD = 'symd',
  SY_M_D_H_M = 'sy_m_d_h_m',
  SY_M_D = 'sy_m_d',
  M_D_H_M_S = 'm_d_h_m_s',
  M_D_H_M = 'm_d_h_m',
  M_D_H = 'm_d_h',
  M_D = 'm_d',
  D_H_M_S = 'd_h_m_s',
  D_H_M = 'd_h_m',
  D_H = 'd_h',
  H_M_S = 'h_m_s',
  HMS = 'hms',
  H_M = 'h_m',
  HM = 'hm',
  M_S = 'm_s',
  YEAR = 'year',
  MONTH = 'month',
  DAY = 'day',
  HOUR = 'hour',
  MINUTE = 'minute',
  SECOND = 'second',
  PAST_CURRENT_M_D = 'past_current_m_d',
  PAST_CURRENT_M_D2 = 'past_current_m_d.2',
  PAST_CURRENT_MD = 'past_current_md',
  PAST_CURRENT_MONTH = 'past_current_month',
  PAST_CURRENT_DAY = 'past_current_day',
  PAST_M_D = 'past_m_d',
  PAST_M_D2 = 'past_m_d.2',
  PAST_MD = 'past_md',
  PAST_MONTH = 'past_month',
  PAST_DAY = 'past_day',
  CURRENT_M_D = 'current_m_d',
  CURRENT_M_D2 = 'current_m_d.2',
  CURRENT_MD = 'current_md',
  CURRENT_MONTH = 'current_month',
  CURRENT_DAY = 'current_day',
  FUTURE_M_D = 'future_m_d',
  FUTURE_M_D2 = 'future_m_d.2',
  FUTURE_MD = 'future_md',
  FUTURE_MONTH = 'future_month',
  FUTURE_DAY = 'future_day',
  FUTURE_CURRENT_M_D = 'future_current_m_d',
  FUTURE_CURRENT_M_D2 = 'future_current_m_d.2',
  FUTURE_CURRENT_MD = 'future_current_md',
  FUTURE_CURRENT_MONTH = 'future_current_month',
  FUTURE_CURRENT_DAY = 'future_current_day',
  Y_M = 'y_m',
  YM = 'ym',
  SY_M = 'sy_m',
  SYM = 'sym'
}

export class TIDEDateFormatPattern {
  static formatMap: Map<string, Map<string, string>> = new Map();

  static initialize() {
    const enMap: Map<string, string> = new Map();
    const deMap: Map<string, string> = new Map();

    deMap.set(TIDEDateFormat.DOW_Y_M_D, 'EEEE dd.MM.yyyy');
    deMap.set(TIDEDateFormat.SDOW_Y_M_D, 'EEE dd.MM.yyyy');
    deMap.set(TIDEDateFormat.SDOW_H_M_S, 'EEE HH:mm:ss');
    deMap.set(TIDEDateFormat.SDOW_H_M, 'EEE HH:mm');
    deMap.set(TIDEDateFormat.SDOW_H, 'EEE HH');
    deMap.set(TIDEDateFormat.SDOW, 'EEE');
    deMap.set(TIDEDateFormat.Y_M_D_H_M_S, 'dd.MM.yyyy HH:mm:ss');
    deMap.set(TIDEDateFormat.Y_M_D_H_M, 'dd.MM.yyyy HH:mm');
    deMap.set(TIDEDateFormat.Y_M_D_HM, 'dd.MM.yyyy HHmm');
    deMap.set(TIDEDateFormat.Y_M_D_H, 'dd.MM.yyyy HH');
    deMap.set(TIDEDateFormat.YMD_H, 'ddMMyyyy HH');
    deMap.set(TIDEDateFormat.YMD_H_M, 'ddMMyyyy HH:mm');
    deMap.set(TIDEDateFormat.YMD_HM, 'ddMMyyyy HHmm');
    deMap.set(TIDEDateFormat.YMDHM, 'ddMMyyyyHHmm');
    deMap.set(TIDEDateFormat.SYMD_H, 'ddMMyy HH');
    deMap.set(TIDEDateFormat.SYMD_H_M, 'ddMMyy HH:mm');
    deMap.set(TIDEDateFormat.SYMD_HM, 'ddMMyy HHmm');
    deMap.set(TIDEDateFormat.Y_M_D, 'dd.MM.yyyy');
    deMap.set(TIDEDateFormat.YMD, 'ddMMyyyy');
    deMap.set(TIDEDateFormat.SYMD, 'ddMMyy');
    deMap.set(TIDEDateFormat.SY_M_D_H_M, 'dd.MM.yy HH:mm');
    deMap.set(TIDEDateFormat.SY_M_D, 'dd.MM.yy');
    deMap.set(TIDEDateFormat.M_D_H_M_S, 'dd.MM. HH:mm:ss');
    deMap.set(TIDEDateFormat.M_D_H_M, 'dd.MM. HH:mm');
    deMap.set(TIDEDateFormat.M_D_H, 'dd.MM. HH');
    deMap.set(TIDEDateFormat.M_D, 'dd.MM.');
    deMap.set(TIDEDateFormat.D_H_M_S, 'dd HH:mm:ss');
    deMap.set(TIDEDateFormat.D_H_M, 'dd HH:mm');
    deMap.set(TIDEDateFormat.D_H, 'dd HH');
    deMap.set(TIDEDateFormat.H_M_S, 'HH:mm:ss');
    deMap.set(TIDEDateFormat.HMS, 'HHmmss');
    deMap.set(TIDEDateFormat.H_M, 'HH:mm');
    deMap.set(TIDEDateFormat.HM, 'HHmm');
    deMap.set(TIDEDateFormat.M_S, 'mm:ss');
    deMap.set(TIDEDateFormat.YEAR, 'yyyy');
    deMap.set(TIDEDateFormat.MONTH, 'MM');
    deMap.set(TIDEDateFormat.DAY, 'dd');
    deMap.set(TIDEDateFormat.HOUR, 'HH');
    deMap.set(TIDEDateFormat.MINUTE, 'mm');
    deMap.set(TIDEDateFormat.SECOND, 'ss');
    deMap.set(TIDEDateFormat.PAST_M_D, 'dd.MM.|past');
    deMap.set(TIDEDateFormat.PAST_M_D2, 'dd.MM|past');
    deMap.set(TIDEDateFormat.PAST_MD, 'ddMM|past');
    deMap.set(TIDEDateFormat.PAST_MONTH, 'MM|past');
    deMap.set(TIDEDateFormat.PAST_DAY, 'dd|past');
    deMap.set(TIDEDateFormat.PAST_CURRENT_M_D, 'dd.MM.|pastcurrent');
    deMap.set(TIDEDateFormat.PAST_CURRENT_M_D2, 'dd.MM|pastcurrent');
    deMap.set(TIDEDateFormat.PAST_CURRENT_MD, 'ddMM|pastcurrent');
    deMap.set(TIDEDateFormat.PAST_CURRENT_MONTH, 'MM|pastcurrent');
    deMap.set(TIDEDateFormat.PAST_CURRENT_DAY, 'dd|pastcurrent');
    deMap.set(TIDEDateFormat.CURRENT_M_D, 'dd.MM.|current');
    deMap.set(TIDEDateFormat.CURRENT_M_D2, 'dd.MM|current');
    deMap.set(TIDEDateFormat.CURRENT_MD, 'ddMM|current');
    deMap.set(TIDEDateFormat.CURRENT_MONTH, 'MM|current');
    deMap.set(TIDEDateFormat.CURRENT_DAY, 'dd|current');
    deMap.set(TIDEDateFormat.FUTURE_M_D, 'dd.MM.|future');
    deMap.set(TIDEDateFormat.FUTURE_M_D2, 'dd.MM|future');
    deMap.set(TIDEDateFormat.FUTURE_MD, 'ddMM|future');
    deMap.set(TIDEDateFormat.FUTURE_MONTH, 'MM|future');
    deMap.set(TIDEDateFormat.FUTURE_DAY, 'dd|future');
    deMap.set(TIDEDateFormat.FUTURE_CURRENT_M_D, 'dd.MM.|futurecurrent');
    deMap.set(TIDEDateFormat.FUTURE_CURRENT_M_D2, 'dd.MM|futurecurrent');
    deMap.set(TIDEDateFormat.FUTURE_CURRENT_MD, 'ddMM|futurecurrent');
    deMap.set(TIDEDateFormat.FUTURE_CURRENT_MONTH, 'MM|futurecurrent');
    deMap.set(TIDEDateFormat.FUTURE_CURRENT_DAY, 'dd|futurecurrent');
    deMap.set(TIDEDateFormat.Y_M, 'MM.yyyy');
    deMap.set(TIDEDateFormat.YM, 'MMyyyy');
    deMap.set(TIDEDateFormat.SY_M, 'MM.yy');
    deMap.set(TIDEDateFormat.SYM, 'MMyy');
    enMap.set(TIDEDateFormat.DOW_Y_M_D, 'EEEE dd/MM/yyyy');
    enMap.set(TIDEDateFormat.SDOW_Y_M_D, 'EEE dd/MM/yyyy');
    enMap.set(TIDEDateFormat.SDOW_H_M_S, 'EEE HH:mm:ss');
    enMap.set(TIDEDateFormat.SDOW_H_M, 'EEE HH:mm');
    enMap.set(TIDEDateFormat.SDOW_H, 'EEE HH');
    enMap.set(TIDEDateFormat.SDOW, 'EEE');
    enMap.set(TIDEDateFormat.Y_M_D_H_M_S, 'dd/MM/yyyy HH:mm:ss');
    enMap.set(TIDEDateFormat.Y_M_D_H_M, 'dd/MM/yyyy HH:mm');
    enMap.set(TIDEDateFormat.Y_M_D_HM, 'dd/MM/yyyy HHmm');
    enMap.set(TIDEDateFormat.Y_M_D_H, 'dd/MM/yyyy HH');
    enMap.set(TIDEDateFormat.YMD_H, 'ddMMyyyy HH');
    enMap.set(TIDEDateFormat.YMD_H_M, 'ddMMyyyy HH:mm');
    enMap.set(TIDEDateFormat.YMD_HM, 'ddMMyyyy HHmm');
    enMap.set(TIDEDateFormat.YMDHM, 'ddMMyyyyHHmm');
    enMap.set(TIDEDateFormat.SYMD_H, 'ddMMyy HH');
    enMap.set(TIDEDateFormat.SYMD_H_M, 'ddMMyy HH:mm');
    enMap.set(TIDEDateFormat.SYMD_HM, 'ddMMyy HHmm');
    enMap.set(TIDEDateFormat.Y_M_D, 'dd/MM/yyyy');
    enMap.set(TIDEDateFormat.YMD, 'ddMMyyyy');
    enMap.set(TIDEDateFormat.SYMD, 'ddMMyy');
    enMap.set(TIDEDateFormat.SY_M_D_H_M, 'dd/MM/yy HH:mm');
    enMap.set(TIDEDateFormat.SY_M_D, 'dd/MM/yy');
    enMap.set(TIDEDateFormat.M_D_H_M_S, 'dd/MM HH:mm:ss');
    enMap.set(TIDEDateFormat.M_D_H_M, 'dd/MM HH:mm');
    enMap.set(TIDEDateFormat.M_D_H, 'dd/MM HH');
    enMap.set(TIDEDateFormat.M_D, 'dd/MM');
    enMap.set(TIDEDateFormat.D_H_M_S, 'dd HH:mm:ss');
    enMap.set(TIDEDateFormat.D_H_M, 'dd HH:mm');
    enMap.set(TIDEDateFormat.D_H, 'dd HH');
    enMap.set(TIDEDateFormat.H_M_S, 'HH:mm:ss');
    enMap.set(TIDEDateFormat.HMS, 'HHmmss');
    enMap.set(TIDEDateFormat.H_M, 'HH:mm');
    enMap.set(TIDEDateFormat.HM, 'HHmm');
    enMap.set(TIDEDateFormat.M_S, 'mm:ss');
    enMap.set(TIDEDateFormat.YEAR, 'yyyy');
    enMap.set(TIDEDateFormat.MONTH, 'MM');
    enMap.set(TIDEDateFormat.DAY, 'dd');
    enMap.set(TIDEDateFormat.HOUR, 'HH');
    enMap.set(TIDEDateFormat.MINUTE, 'mm');
    enMap.set(TIDEDateFormat.SECOND, 'ss');
    enMap.set(TIDEDateFormat.PAST_M_D, 'dd/MM|past');
    enMap.set(TIDEDateFormat.PAST_M_D2, 'dd/MM/|past');
    enMap.set(TIDEDateFormat.PAST_MD, 'ddMM|past');
    enMap.set(TIDEDateFormat.PAST_MONTH, 'MM|past');
    enMap.set(TIDEDateFormat.PAST_DAY, 'dd|past');
    enMap.set(TIDEDateFormat.PAST_CURRENT_M_D, 'dd/MM|pastcurrent');
    enMap.set(TIDEDateFormat.PAST_CURRENT_M_D2, 'dd/MM/|pastcurrent');
    enMap.set(TIDEDateFormat.PAST_CURRENT_MD, 'ddMM|pastcurrent');
    enMap.set(TIDEDateFormat.PAST_CURRENT_MONTH, 'MM|pastcurrent');
    enMap.set(TIDEDateFormat.PAST_CURRENT_DAY, 'dd|pastcurrent');
    enMap.set(TIDEDateFormat.CURRENT_M_D, 'dd/MM|current');
    enMap.set(TIDEDateFormat.CURRENT_M_D2, 'dd/MM|current');
    enMap.set(TIDEDateFormat.CURRENT_MD, 'ddMM|current');
    enMap.set(TIDEDateFormat.CURRENT_MONTH, 'MM|current');
    enMap.set(TIDEDateFormat.CURRENT_DAY, 'dd|current');
    enMap.set(TIDEDateFormat.FUTURE_M_D, 'dd/MM|future');
    enMap.set(TIDEDateFormat.FUTURE_M_D2, 'dd/MM|future');
    enMap.set(TIDEDateFormat.FUTURE_MD, 'ddMM|future');
    enMap.set(TIDEDateFormat.FUTURE_MONTH, 'MM|future');
    enMap.set(TIDEDateFormat.FUTURE_DAY, 'dd|future');
    enMap.set(TIDEDateFormat.FUTURE_CURRENT_M_D, 'dd/MM|futurecurrent');
    enMap.set(TIDEDateFormat.FUTURE_CURRENT_M_D2, 'dd/MM|futurecurrent');
    enMap.set(TIDEDateFormat.FUTURE_CURRENT_MD, 'ddMM|futurecurrent');
    enMap.set(TIDEDateFormat.FUTURE_CURRENT_MONTH, 'MM|futurecurrent');
    enMap.set(TIDEDateFormat.FUTURE_CURRENT_DAY, 'dd|futurecurrent');
    enMap.set(TIDEDateFormat.Y_M, 'MM/yyyy');
    enMap.set(TIDEDateFormat.SY_M, 'MM/yy');
    enMap.set(TIDEDateFormat.YM, 'MMyyyy');
    enMap.set(TIDEDateFormat.SYM, 'MMyy');
    TIDEDateFormatPattern.formatMap.set('de_de', deMap);
    TIDEDateFormatPattern.formatMap.set('en_gb', enMap);
  }

  /**
   * Provides the SimpleDateFormat Pattern +  extension (|*) based on the locale.
   * @param {string} locale
   * @returns {(fmtkey: TIDEDateFormat) => V}
   *
   * @author stephan.petzchen@extern.eurogate.eu
   *
   * ### Example
   *
   * ```
   * const enFormat = TIDEDateFormat.build('en_gb')
   * console.log(enFormat(TIDEDateFormat.FUTURE_MONTH));
   * ```
   */
  static from(locale: string = 'en_gb') { return (fmtkey: TIDEDateFormat) => TIDEDateFormatPattern.formatMap.get(locale).get(fmtkey); }
}

TIDEDateFormatPattern.initialize();
