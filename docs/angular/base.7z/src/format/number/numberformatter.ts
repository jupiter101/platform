// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IFormat} from '../';

enum NumberFormatStyle {
  Decimal,
  Percent,
  Currency,
}

/**
 * IFormat implementation for numbers.
 */
export class NumberFormatter implements IFormat {
  constructor(private locale: string, private opt: {} = {}) {}
  format(n: number, pattern: string): string {
    return String(n);
  }

  static format(num: number, locale: string, style: NumberFormatStyle, opts: {
    minimumIntegerDigits?: number,
    minimumFractionDigits?: number,
    maximumFractionDigits?: number,
    currency?: string|null,
    currencyAsSymbol?: boolean
  } = {}): string {
    const {minimumIntegerDigits, minimumFractionDigits, maximumFractionDigits, currency,
      currencyAsSymbol = false} = opts;
    const options: Intl.NumberFormatOptions = {
      minimumIntegerDigits,
      minimumFractionDigits,
      maximumFractionDigits,
      style: NumberFormatStyle[style].toLowerCase()
    };

    if (style === NumberFormatStyle.Currency) {
      options.currency = typeof currency === 'string' ? currency : undefined;
      options.currencyDisplay = currencyAsSymbol ? 'symbol' : 'code';
    }
    return new Intl.NumberFormat(locale, options).format(num);
  }
}
