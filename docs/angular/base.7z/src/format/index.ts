// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types


import {TIDEDateFormat, TIDEDateFormatPattern} from './date/tidedateformat';
import {DateTimeFormatter} from './date/dateformatter';
import {NumberFormatter} from './number/numberformatter';
import {setPropertyMetadata} from '../meta/tidemeta';

export {TIDEDateFormat, TIDEDateFormatPattern} from './date/tidedateformat';
export {DateTimeFormatter} from './date/dateformatter';
export {NumberFormatter} from './number/numberformatter';

/**
 * @format annotation
 * @param {string} pattern the target format pattern
 * @param {string} hints the parser hints.
 */
export function format (pattern: string, ...hints: string[]) {
  return (target: any, propertyName: string) => {
    setPropertyMetadata(target, { k: propertyName, v: { k: 'format', v: [pattern, ...hints] } });
  };
}

/**
 * General interface to parse a string according a given format.
 */
export interface IFormatParser {
  parse(value: string, format: string, ...formathints: string[] = []): this | Date | number | string;
}

/**
 * General interface for implementing a formatter for date, numbers and strings.
 */
export interface IFormat extends IFormatParser {
  format(value: Date | number | string, format: string): string;
}


