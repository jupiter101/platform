// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

// Experimental: map function for Map
// 1. Convert it to an Array of [key,value] pairs.
// 2. map() the Array.
// 3. Convert the result back to a Map.
export const map = <K, V>(m: Map<K, V>, fn: (key: K, value: V) => [K, V]) => new Map( [...m].map(fn));

