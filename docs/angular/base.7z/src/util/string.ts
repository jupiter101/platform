// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export function removeSuffix(value: string, suffix: string) {
  if (value.endsWith(suffix)) return value.substring(0, value.length - suffix.length);
  return value;
}
