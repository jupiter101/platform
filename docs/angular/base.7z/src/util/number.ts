// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export function toInt(text: string): number {
  const result: number = parseInt(text);
  if (isNaN(result)) {
    throw new Error('Invalid integer literal when parsing ' + text);
  }
  return result;
}

function toNum(value: string): number {
  return isNumeric(value) ? +value : NaN;
}

export function isNumeric(value: any): boolean {
  return !isNaN(value - parseFloat(value));
}
