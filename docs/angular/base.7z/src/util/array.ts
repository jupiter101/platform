// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 *
 * @param {T[][]} a
 * @returns {T[]}
 */
export function flatten<T>(a: T[][]) {
  return (<T[]>[]).concat(...a);
  [].map()
}
