// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Observable} from 'rxjs/Observable';

/**
 * Determine if the argument is an Observable
 */
export function isObservable(obj: any | Observable<any>): obj is Observable<any> {
  return !!obj && typeof obj.subscribe === 'function';
}
