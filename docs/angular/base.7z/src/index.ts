// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import { NgModule } from '@angular/core';
// import {setPropertyMetadata, getSourceMetadata, Meta} from './meta/tidemeta';

export * from './format/index';
export {setPropertyMetadata, getSourceMetadata, Meta} from './meta/tidemeta';

@NgModule({})
export class TideBaseModule {}
