// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import {TIDEDateFormat, TIDEDateFormatPattern} from '../src/format/dateformat';
import {DateFormatter} from '../src/format/dateformatter';
import {IFormat} from '../src/format/format.interface';
import * as TS from '../src/lang';

const setDateEnvironment = (today: Date, offset: number = 3, localeFmt: string = 'de_de',
                            localeFormatter: string = 'de', targetfmt: TIDEDateFormat = TIDEDateFormat.Y_M_D) => {
  return {
    past: TS.Dates.offsetDays(today.getFullYear(), today.getMonth(), today.getDate(), TS.Dates.DateOffsetDirection.PAST, offset),
    today: today,
    future: TS.Dates.offsetDays(today.getFullYear(), today.getMonth(), today.getDate(), TS.Dates.DateOffsetDirection.FUTURE, offset),
    formatPattern: TIDEDateFormatPattern.from(localeFmt),
    formatter: new DateFormatter(localeFormatter, TIDEDateFormatPattern.from(localeFmt)(targetfmt))
  };
};

describe(`DateParser DE (isolated unit tests)`, () => {

  const {formatPattern: pattern, formatter: dtfmt, past: pastDate, today, future: futureDate} = setDateEnvironment(new Date(), 3);

  it(`[dd|pastcurrent] => current date is: ${dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D_H_M_S))}`, () => {

    // 1. for past source date (DAY) i.e. 17 => 17.11.2017
    let fmtPast = dtfmt.parse(String(pastDate.getDate()), pattern(TIDEDateFormat.PAST_CURRENT_DAY), pattern(TIDEDateFormat.PAST_CURRENT_DAY)).format();
    expect(fmtPast).toBe(dtfmt.format(pastDate, pattern(TIDEDateFormat.Y_M_D)));

    // 2. for current source date (DAY) i.e. 20 => 20.11.2017 (current date)
    let fmtToday = dtfmt.parse(String(today.getDate()), pattern(TIDEDateFormat.PAST_CURRENT_DAY), pattern(TIDEDateFormat.PAST_CURRENT_DAY)).format();
    expect(fmtToday).toBe(dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D)));

    // 3. for future source date (DAY) i.e. 23 => 23.10.2017 (past month)
    let fmtFuture = dtfmt.parse(String(futureDate.getDate()), pattern(TIDEDateFormat.PAST_CURRENT_DAY), pattern(TIDEDateFormat.PAST_CURRENT_DAY)).format();
    expect(fmtFuture).toBe(dtfmt.format(TS.Dates.offsetMonth(futureDate.getFullYear(), futureDate.getMonth(), futureDate.getDate(), TS.Dates.DateOffsetDirection.PAST, 1),
      pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`[dd|past] => current date is: ${dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D_H_M_S))}`, () => {
    // 1. for past source date (DAY) i.e. 17 => 17.11.2017
    let fmtPast = dtfmt.parse(String(pastDate.getDate()), pattern(TIDEDateFormat.PAST_DAY)).format();
    expect(fmtPast).toBe(dtfmt.format(pastDate, pattern(TIDEDateFormat.Y_M_D)));

    // 2. for current source date (DAY) i.e. 20 => 20.10.2017 (past month)
    let fmtToday = dtfmt.parse(String(today.getDate()), pattern(TIDEDateFormat.PAST_DAY)).format();
    expect(fmtToday).toBe(dtfmt.format(TS.Dates.offsetMonth(today.getFullYear(), today.getMonth(), today.getDate(), TS.Dates.DateOffsetDirection.PAST, 1),
      pattern(TIDEDateFormat.Y_M_D)));

    // 3. for future source date (DAY) i.e. 23 => 23.10.2017 (past month)
    let fmtFuture = dtfmt.parse(String(futureDate.getDate()), pattern(TIDEDateFormat.PAST_DAY)).format();
    expect(fmtFuture).toBe(dtfmt.format(TS.Dates.offsetMonth(futureDate.getFullYear(), futureDate.getMonth(), futureDate.getDate(), TS.Dates.DateOffsetDirection.PAST, 1),
      pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`[dd|futurecurrent] => current date is: ${dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D_H_M_S))}`, () => {
    // 1. for past source date (DAY) i.e. 17 => 17.12.2017 (future month)
    let fmtPast = dtfmt.parse(String(pastDate.getDate()), pattern(TIDEDateFormat.FUTURE_CURRENT_DAY)).format();
    expect(fmtPast).toBe(dtfmt.format(TS.Dates.offsetMonth(pastDate.getFullYear(), pastDate.getMonth(), pastDate.getDate(), TS.Dates.DateOffsetDirection.FUTURE, 1),
      pattern(TIDEDateFormat.Y_M_D)));

    // 2. for current source date (DAY) i.e. 20 => 20.11.2017 (current day)
    let fmtToday = dtfmt.parse(String(today.getDate()), pattern(TIDEDateFormat.FUTURE_CURRENT_DAY)).format();
    expect(fmtToday).toBe(dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D)));

    // 3. for future source date (DAY) i.e. 23 => 23.11.2017 (future day)
    let fmtFuture = dtfmt.parse(String(futureDate.getDate()), pattern(TIDEDateFormat.FUTURE_CURRENT_DAY)).format();
    expect(fmtFuture).toBe(dtfmt.format(futureDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`[dd|future] => current date is: ${dtfmt.format(today, pattern(TIDEDateFormat.Y_M_D_H_M_S))}`, () => {
    // const {formatPattern: pattern, formatter: dtfmt, past: pastDate, today, future: futureDate} = setDateEnvironment(new Date(2017, 10, 6), 3);

    // 1. for past source date (DAY) i.e. 17 => 17.12.2017 (future month)
    let fmtPast = dtfmt.parse(String(pastDate.getDate()), pattern(TIDEDateFormat.FUTURE_DAY)).format();
    expect(fmtPast).toBe(dtfmt.format(TS.Dates.offsetMonth(pastDate.getFullYear(), pastDate.getMonth(), pastDate.getDate(), TS.Dates.DateOffsetDirection.FUTURE, 1),
      pattern(TIDEDateFormat.Y_M_D)));

    // 2. for current source date (DAY) i.e. 20 => 20.12.2017 (future month)
    let fmtToday = dtfmt.parse(String(today.getDate()), pattern(TIDEDateFormat.FUTURE_DAY)).format();
    expect(fmtToday).toBe(dtfmt.format(TS.Dates.offsetMonth(today.getFullYear(), today.getMonth(), today.getDate(), TS.Dates.DateOffsetDirection.FUTURE, 1),
      pattern(TIDEDateFormat.Y_M_D)));

    // 3. for future source date (DAY) i.e. 23 => 23.11.2017 (future day)
    let fmtFuture = dtfmt.parse(String(futureDate.getDate()), pattern(TIDEDateFormat.FUTURE_DAY)).format();
    expect(fmtFuture).toBe(dtfmt.format(futureDate, pattern(TIDEDateFormat.Y_M_D)));

    // TIDEDateFormat.Y_M_D_H_M, TIDEDateFormat.CURRENT_MD, TIDEDateFormat.CURRENT_M_D, TIDEDateFormat.CURRENT_M_D2, TIDEDateFormat.Y_M_D, TIDEDateFormat.Y_M_D_H, TIDEDateFormat.Y_M_D_HM, TIDEDateFormat.YMD, TIDEDateFormat.YMD_H, TIDEDateFormat.YMD_HM, TIDEDateFormat.SYMD, TIDEDateFormat.SYMD_H, TIDEDateFormat.SYMD_HM
  });

  it(`112 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {

    // TIDEDateFormat.CURRENT_MD:       ddMM|current
    // TIDEDateFormat.CURRENT_M_D:      dd.MM.|futurecurrent
    // TIDEDateFormat.CURRENT_M_D2:     dd.MM|futurecurrent
    // TIDEDateFormat.Y_M_D:            dd/MM/yyyy
    // TIDEDateFormat.Y_M_D_H:          dd.MM.yyyy HH
    // TIDEDateFormat.Y_M_D_HM:         dd.MM.yyyy HHmm
    // TIDEDateFormat.YMD:              ddMMyyyy
    // TIDEDateFormat.YMD_H:            ddMMyyyy HH
    // TIDEDateFormat.YMD_HM:           ddMMyy HHmm
    // TIDEDateFormat.SYMD:             ddMMyy
    // TIDEDateFormat.SYMD_H:           ddMMyy HH
    // TIDEDateFormat.SYMD_HM:          ddMMyy HHmm


    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('112', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n112 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.2 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.2', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11.2 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11/2 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11/2', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11/2 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.02 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.02', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11.02 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`1102 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('1102', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n1102 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.2.17 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.2.17', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11.2.17 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.2.2017 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.2.2017', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11.2.2017 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.2.7 => 11.2.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 1, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.2.7', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n11.2.7 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`1111 => 11.11.${new Date().getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(2017, 10, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('1111', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n1111 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

  it(`11.11.1968 => 11.11.${new Date(1968, 10, 11, 1, 1, 1, 0).getFullYear()} format: ${pattern(TIDEDateFormat.Y_M_D)}`, () => {
    const targetDate: Date = new Date(1968, 10, 11, 1, 1, 1, 0);
    let fmtToday = dtfmt.parse('11.11.1968', pattern(TIDEDateFormat.CURRENT_MD),
      pattern(TIDEDateFormat.CURRENT_M_D), pattern(TIDEDateFormat.CURRENT_M_D2), pattern(TIDEDateFormat.Y_M_D),
      pattern(TIDEDateFormat.Y_M_D_H), pattern(TIDEDateFormat.Y_M_D_HM), pattern(TIDEDateFormat.YMD),
      pattern(TIDEDateFormat.YMD_H), pattern(TIDEDateFormat.YMD_HM),
      pattern(TIDEDateFormat.SYMD), pattern(TIDEDateFormat.SYMD_H), pattern(TIDEDateFormat.SYMD_HM)).format();
    console.log(`\n111168 => ${fmtToday}`);
    expect(fmtToday).toBe(dtfmt.format(targetDate, pattern(TIDEDateFormat.Y_M_D)));
  });

});
