# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

<a name="0.0.14"></a>
## [0.0.14](https://eghamgit/Eurogate/tide-framework-web/compare/v0.0.13...v0.0.14) (2017-11-07)




**Note:** Version bump only for package @tide/base

<a name="0.0.13"></a>
## [0.0.13](https://eghamgit/Eurogate/tide-framework-web/compare/v0.0.12...v0.0.13) (2017-11-07)




**Note:** Version bump only for package @tide/base

<a name="0.0.2"></a>
## [0.0.2](https://eghamgit/Eurogate/tide-framework-web/compare/v0.0.1...v0.0.2) (2017-11-07)




**Note:** Version bump only for package @tide/base

<a name="0.0.1"></a>
## 0.0.1 (2017-11-02)

### Bug Fixes

### Features
* **Base:** Initial commit
