// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for date object.
 *
 * TODO: remove code smell.
 * TODO: apply coding convention.
 */
export namespace Dates {
  /**
   * Date offset enum.
   *
   * TODO: rename to DateOffset and get rid of redundant 'direction' name.
   * TODO: remove FUTURECURRENT and PASTCURRENT. Will be covered by offset parameter in offset methods.
   */
  export const enum DateOffsetDirection {
    FUTURE = 1,
    FUTURECURRENT = 2,
    CURRENT = 0,
    PAST = -1,
    PASTCURRENT = -2,
  }

  /**
   * Type to manage ambiguous year problem for years < 4 digits.
   *
   * @see initDefaultCentury method.
   */
  export type DefaultCentury = { start: Date, year: number, twodigityear: number};

  const MILLISECONDS_IN_MINUTE = 60000;
  const MILLISECONDS_IN_HOUR = MILLISECONDS_IN_MINUTE * 60;
  const MILLISECONDS_IN_DAY = MILLISECONDS_IN_HOUR * 24;

  /**
   * Copying a date.
   * @param {Date} date
   * @returns {Date}
   */
  export const clone = (date: Date): Date => {
    const dt: Date = new Date();
    dt.setTime(date.getTime());
    return dt;
  };

  /**
   * Removes time component resp. set to 00:00:00.000
   * @param {Date} date
   * @returns {Date}
   */
  export const zeroTime = (date: Date): void => {
    date.setHours(0, 0, 0, 0);
  };

  /**
   * Compares two dates.
   * @param {Date} left
   * @param {Date} right
   * @returns {number} -1 = left is before, 1 = right is before, 0 = equal
   */
  export const compare =  (left: Date, right: Date): number => {
    const diff = left.getTime() - right.getTime();
    if (diff < 0) {
      return -1;
    } else if (diff > 0) {
      return 1;
      // Return 0 if diff is 0; return NaN if diff is NaN
    } else {
      return diff;
    }
  };


  /**
   * Test for valid day of month.
   * @param {number} year
   * @param {number} month
   * @param {number} day
   * @returns {boolean}
   */
  export const isValidDayOfMonth = (year: number, month: number, day: number): boolean => new Date(year, month, day).getDate() === day;

  /**
   * Test for the current date. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  export const isToday = (d: Date): boolean => {
    const current: Date = new Date();
    const left: Date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const right: Date = new Date(current.getFullYear(), current.getMonth(), current.getDate());
    return compare(left, right) === 0;
  };

  /**
   * Test for the past date. Time component is ignored.
   * @param {Date} d
   * @returns {boolean}
   */
  export const isPast = (d: Date): boolean => {
    const current: Date = new Date();
    const left: Date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const right: Date = new Date(current.getFullYear(), current.getMonth(), current.getDate());
    return compare(left, right) === -1;
  };

  /**
   * Test for the past date. Time component is ignored.
   * @param {Date} d
   * @returns {boolean}
   */
  export const isFuture = (d: Date): boolean => {
    const current: Date = new Date();
    const left: Date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const right: Date = new Date(current.getFullYear(), current.getMonth(), current.getDate());
    return compare(left, right) === 1;
  };

  /**
   * Test for the current Month. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  export const isCurrentMonth = (d: Date) => {
    const curr: Date = new Date();
    return curr.getFullYear() === d.getFullYear() &&
      curr.getMonth() === d.getMonth();
  };

  /**
   * Test for the current Year. Time component is ignored.
   * @param {Date} date
   * @returns {number}
   */
  export const isCurrentYear = (d: Date) => {
    const curr: Date = new Date();
    return curr.getFullYear() === d.getFullYear();
  };

  /**
   * Test for leap year.
   * @param {number} year
   */
  export const isLeapYear = (year: number) => ((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0);

  /**
   * Calculates the last leap year.
   * @param {number} year
   * @returns {number}
   */
  export const lastLeapYear = (year: number) => {
    let last = year - 1;
    while (!isLeapYear(last)) { last -= 1; }
    return last;
  };

  /**
   * Calculates the last leap year.
   * @param {number} year
   * @returns {number}
   */
  export const nextLeapYear = (year: number) => {
    let next = year + 1;
    while (!isLeapYear(next)) { next += 1; }
    return next;
  };

  /**
   * Completes date for: date, date+month with current or future values.
   *
   * @param {number} days
   * @param {number} month
   * @returns {Date}
   */
  export const completeToCurrent = (days?: number, month?: number): Date => {
    const curr: Date = new Date();
    let d = days ? days > 0 ?  days : curr.getDate() : curr.getDate();
    let m = month ? month >= 0 ?  month : curr.getMonth() : curr.getMonth();
    let y = curr.getFullYear();
    let offset: number = isToday(new Date(y, m, d)) ? 0 : 1;

    if (!days || days === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetDays(y, m, d, DateOffsetDirection.CURRENT, offset);
    } else if (!month || month === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetMonth(y, m, d, DateOffsetDirection.CURRENT, offset);
    }
    // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
    return offsetYear(y, m, d, DateOffsetDirection.CURRENT, offset);
  };


  /**
   * Completes date for: date, date+month with past values.
   *
   * @param {number} days
   * @param {number} month
   * @returns {Date}
   */
  export const completeToPast = (days?: number, month?: number): Date => {
    const curr: Date = new Date();
    let d = days ? days > 0 ?  days : curr.getDate() : curr.getDate();
    let m = month ? month >= 0 ?  month : curr.getMonth() : curr.getMonth();
    let y = curr.getFullYear();
    let offset: number = isPast(new Date(y, m, d)) ? 0 : 1;
    if (!days || days === -1) {
      return offsetDays(y, m, d, DateOffsetDirection.PAST, offset);
    } else if (!month || month === -1) {
      return offsetMonth(y, m, d, DateOffsetDirection.PAST, offset);
    }
    return offsetYear(y, m, d, DateOffsetDirection.PAST, offset);
  };

  /**
   * Completes date for: date, date+month with current or past values.
   *
   * @param {number} days
   * @param {number} month
   * @returns {Date}
   */
  export const completeToPastCurrent = (days?: number, month?: number): Date => {
    const curr: Date = new Date();
    let d = days ? days > 0 ?  days : curr.getDate() : curr.getDate();
    let m = month ? month >= 0 ?  month : curr.getMonth() : curr.getMonth();
    let y = curr.getFullYear();
    let offset: number = isPast(new Date(y, m, d)) ? 0 : 1;
    offset = isToday(new Date(y, m, d)) ? 0 : offset;
    if (!days || days === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetDays(y, m, d, DateOffsetDirection.PAST, offset);
    } else if (!month || month === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetMonth(y, m, d, DateOffsetDirection.PAST, offset);
    }
    // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
    return offsetYear(y, m, d, DateOffsetDirection.PAST, offset);
  };


  /**
   * Completes date for: date, date+month with future values.
   *
   * @param {number} days
   * @param {number} month
   * @returns {Date}
   */
  export const completeToFuture = (days?: number, month?: number): Date => {
    const curr: Date = new Date();
    let d = days ? days > 0 ?  days : curr.getDate() : curr.getDate();
    let m = month ? month >= 0 ?  month : curr.getMonth() : curr.getMonth();
    let y = curr.getFullYear();
    let offset: number = isFuture(new Date(y, m, d)) ? 0 : 1;
    // console.log(` completeToFuture: year: ${y} month: ${m} day: ${d} year offset: ${offset}`);
    if (!days || days === -1) {
      return offsetDays(y, m, d, DateOffsetDirection.FUTURE, offset);
    } else if (!month || month === -1) {
      return offsetMonth(y, m, d, DateOffsetDirection.FUTURE, offset);
    }
    return offsetYear(y, m, d, DateOffsetDirection.FUTURE, offset);
  };
  /**
   * Completes date for: date, date+month with current or future values.
   *
   * @param {number} days
   * @param {number} month
   * @returns {Date}
   */
  export const completeToFutureCurrent = (days?: number, month?: number): Date => {
    const curr: Date = new Date();
    let d = days ? days > 0 ?  days : curr.getDate() : curr.getDate();
    let m = month ? month >= 0 ?  month : curr.getMonth() : curr.getMonth();
    let y = curr.getFullYear();
    let offset: number = isFuture(new Date(y, m, d)) ? 0 : 1;
    offset = isToday(new Date(y, m, d)) ? 0 : offset;
    if (!days || days === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetDays(y, m, d, DateOffsetDirection.FUTURE, offset);
    } else if (!month || month === -1) {
      // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
      return offsetMonth(y, m, d, DateOffsetDirection.FUTURE, offset);
    }
    // if (isToday(new Date(y, m, d))) { return new Date(y, m, d); }
    return offsetYear(y, m, d, DateOffsetDirection.FUTURE, offset);
  };


  /**
   * Adds a complete day ( in ms).
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset
   * @returns {Dates.DateNumbers}
   */
  export const addDays = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetDays(year, month, day, DateOffsetDirection.FUTURE, Math.abs(offset));
  };

  /**
   * Reduces a complete day ( in ms).
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset
   * @returns {Dates.DateNumbers}
   */
  export const substractDays = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetDays(year, month, day, DateOffsetDirection.PAST, Math.abs(offset));
  };

  /**
   * Adds amount of month.
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset Amount of month to add. Default is 1
   * @returns {Date}
   */
  export const addMonth = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetMonth(year, month, day, DateOffsetDirection.FUTURE, offset);
  };

  /**
   * Substracts amount of month.
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset Amount of month to substract. Default is 1
   * @returns {Date}
   */
  export const substractMonth = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetMonth(year, month, day, DateOffsetDirection.PAST, offset);
  };

  /**
   * Adds amount of month.
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset Amount of years to add. Default is 1
   * @returns {Date}
   */
  export const addYear = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetYear(year, month, day, DateOffsetDirection.FUTURE, offset);
  };

  /**
   * Substracts amount of years.
   * @param {number} day
   * @param {number} month
   * @param {number} year
   * @param {number} offset Amount of years to substract. Default is 1
   * @returns {Date}
   */
  export const substractYears = (day: number, month: number, year: number, offset: number = 1): Date => {
    return offsetYear(year, month, day, DateOffsetDirection.PAST, offset);
  };

  /**
   * Offsets a date based on the unit of days.
   * @param {number} year
   * @param {number} month
   * @param {number} day
   * @param {Dates.DateOffsetDirection} direction
   * @param {number} offset
   * @returns {Date}
   */
  export const offsetDays = (year: number, month: number, day: number, direction: DateOffsetDirection = DateOffsetDirection.FUTURE, offset: number = 1): Date => {
    const _offset: number = (direction * Math.abs(offset));
    const _date = new Date();
    _date.setTime(new Date(year, month, day).getTime() + (MILLISECONDS_IN_DAY * _offset));
    return _date;
  };

  /**
   * Offsets a date based on the unit of month.
   * @param {number} year
   * @param {number} month
   * @param {number} days
   * @param {Dates.DateOffsetDirection} direction
   * @param {number} offset
   * @returns {Date}
   */
  export const offsetMonth = (year: number, month: number, days: number, direction: DateOffsetDirection = DateOffsetDirection.FUTURE, offset: number = 1): Date => {
    let _offset: number = (direction * Math.abs(offset));
    let _date = new Date(year, month + _offset, days);
    while (_date.getDate() !== days) {
      _offset += (direction * 1);
      _date = new Date(year, month + _offset, days);
    }
    return _date;
  };

  /**
   * Offsets a date based on the unit of years.
   * @param {number} year
   * @param {number} month
   * @param {number} days
   * @param {Dates.DateOffsetDirection} direction
   * @param {number} offset
   * @returns {Date}
   */
  export const offsetYear = (year: number, month: number, days: number, direction: DateOffsetDirection = DateOffsetDirection.FUTURE, offset: number = 1): Date => {
    let _offset: number = (direction * Math.abs(offset));
    // console.log(` offsetYear: year: ${year} month: ${month} day: ${days} year offset: ${_offset}`);
    let _date: Date = new Date(year + _offset, month, days);
    // console.log('####DateOffsetDirection: ' + direction);
    // console.log('####_offset: ' + _offset);
    while (_date.getDate() !== days && _date.getMonth() !== month) {
      _offset += (direction * 1);
      _date = new Date(year + _offset, month, days);
    }
    // console.log(` offsetYear RET: year: ${_date.getFullYear()} month: ${_date.getMonth()} day: ${_date.getDate()} year offset: ${_offset}`);
    return _date;
  };



  /**
   * Initialize the fields we use to disambiguate ambiguous years.
   *
   */
  export const initDefaultCentury = (): DefaultCentury => {
    let date: Date = new Date();
    date.setFullYear(date.getFullYear() - 80);
    // Define one-century window into which to disambiguate dates using two-digit years.
    return { start: date, year: date.getFullYear(), twodigityear: (date.getFullYear() % 100)};
  };

}
