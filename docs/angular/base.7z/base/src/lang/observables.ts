// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
/**
 * Helper for Observables.
 */
import {Observable} from 'rxjs/Observable';
export namespace Observables {
  export const isObservable = (obj: any | Observable<any>): obj is Observable<any> => !!obj && typeof obj.subscribe === 'function';
}
