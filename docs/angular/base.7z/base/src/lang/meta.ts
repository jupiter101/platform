// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for setting and retrieving object metadata.
 * @experimental
 *
 * TODO: remove code smell.
 * TODO: optimize for TIDE use cases.
 */
export namespace Meta {

  const METADATA_KEY = '__@tide/base/meta__';

  export type TIDEMetadata = Map<string, Map<string, any>>;

  export interface TIDEMetadataEntry {
    k: string;
    v: TIDEPropertyMetadataEntry;
  }

  export interface TIDEPropertyMetadataEntry {
    k: string;
    v: any;
  }

  function compose(...functions: any[]) {
    return function(arg: any) {
      if (functions.length === 0) {
        return arg;
      }
      return functions
        .slice(0, -1)
        .reduceRight(
          (composed, fn) => fn(composed),
          functions[functions.length - 1](arg)
        );
    };
  }

  function getSourceForInstance(instance: Object): any {
    return Object.getPrototypeOf(instance);
  }

  function getMetadata(sourceProto: any): TIDEMetadata {
    return sourceProto.constructor[METADATA_KEY];
  }

  /**
   * Setting property metadata.
   * @param sourceProto
   * @param {TIDEMetadataEntry} entry
   */
  export function setPropertyMetadata(
    sourceProto: any,
    entry: TIDEMetadataEntry
  ) {
    if (!entry || !sourceProto || !sourceProto.constructor) {
      return;
    }
    const ctor = sourceProto.constructor;
    const meta: TIDEMetadata = ctor.hasOwnProperty(METADATA_KEY)
      ? (ctor as any)[METADATA_KEY]
      : Object.defineProperty(ctor, METADATA_KEY, { value: new Map() })[
        METADATA_KEY
        ];
    meta.has(entry.k)
      ? (meta.get(entry.k) || new Map()).set(entry.v.k, entry.v.v)
      : meta.set(entry.k, new Map().set(entry.v.k, entry.v.v));
  }

  /**
   * Retrieving instance metadata.
   * @type {(arg: any) => any}
   */
  export const getSourceMetadata = compose(getMetadata, getSourceForInstance);


  /**
   * Metadata annotation.
   * @param {string} key
   * @param args
   * @returns {(target: any, propertyName: string) => any}
   * @constructor
   */
  export function Meta(key: string, ...args: any[]) {
    return (target: any, propertyName: string) => {
      setPropertyMetadata(target, { k: propertyName, v: { k: key, v: args } });
    };
  }
}

