// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
/**
 * Helper for Set objects.
 *
 * TODO: remove code smell.
 */
export namespace Sets {

}
