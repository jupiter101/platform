// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for Map objects.
 *
 * TODO: remove code smell.
 */
export namespace Maps {
  /**
   * Creates a Map from an Iterable object.
   * @param {Iterable<[K , V]>} value
   * @returns {Map}
   */
  export const fromIterable = <K, V>(value: Iterable<[K, V]>): Map => new Map([...value]);
}
