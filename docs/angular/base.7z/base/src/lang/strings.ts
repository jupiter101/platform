// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for string objects.
 *
 * TODO: remove code smell.
 */
export namespace Strings {
  /**
   * Converts string to real array.
   * Strings are is array-like but no real arrays.
   * @param {string} value
   *
   * TODO: optimize by using destructuring instead of Array.from.
   */
  export const toArray = (value: string) => Array.from(value);
  export const removeSuffix = (value: string, suffix: string) => value.endsWith(suffix) ? value.substring(0, value.length - suffix.length) : value;
}

