// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for numbers.
 */
export namespace Numbers {
  export const isNaN = (value: any): boolean => Object.is(NaN, value);
  export const isNum = (value: any): boolean => !isNaN(value - parseFloat(value));
  export const toNum = (value: string): number => isNum(value) ? +value : NaN;
}



