// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import { NgModule } from '@angular/core';


@NgModule({})
export class TideBaseModule {}
