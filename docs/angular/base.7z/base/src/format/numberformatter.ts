// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IFormat} from './format.interface';
import * as TS from '../lang';

enum NumberFormatStyle {
  Decimal,
  Percent,
  Currency,
}

/**
 * IFormat implementation for numbers.
 */
export class NumberFormatter implements IFormat {
  private _value: number;
  constructor(private locale: string, private style: NumberFormatStyle, private opt: {
    minimumIntegerDigits?: number,
    minimumFractionDigits?: number,
    maximumFractionDigits?: number,
    currency?: string|null,
    currencyAsSymbol?: boolean
  } = {}) {}

  format(value?: number): string {
    if (TS.Numbers.isNaN(value)) return 'NaN';
    const {minimumIntegerDigits, minimumFractionDigits, maximumFractionDigits, currency,
      currencyAsSymbol = false} = opts;
    const options: Intl.NumberFormatOptions = {
      minimumIntegerDigits,
      minimumFractionDigits,
      maximumFractionDigits,
      style: NumberFormatStyle[this.style].toLowerCase()
    };

    if (this.style === NumberFormatStyle.Currency) {
      options.currency = typeof currency === 'string' ? currency : undefined;
      options.currencyDisplay = currencyAsSymbol ? 'symbol' : 'code';
    }
    return new Intl.NumberFormat(locale, options).format(value);
  }

  parse(value: string, ...parsehints: string[]): this {
    this._value = TS.Numbers.toNum(value);
  }
}
