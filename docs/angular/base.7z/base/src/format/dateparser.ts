// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import * as TS from '../lang';


type KernelFunction = (date: string) => KernelFunctionResult;
type KernelFunctionResult = {'symbol': string, 'result': number};
type ParserSymbolDescriptor = {'symbol': string, 'pos': number, 'len': number};
export type ParserResult = { 'date': Date, 'format': string, value: string, isvalid: boolean, 'hint': string, 'details': {[symbol: string]: KernelFunctionResult}};

const PARSER_TOKEN_MATCHER = /E{3,4}|d{1,2}|[./-]|M{1,4}|y{1,4}|([HhmsTt])\1?|[LloSZWN]|'[^']*'|'[^']*'/g;
const COMPLETION_TOKEN_MATCHER = /\|(pastcurrent|futurecurrent|past|current|future)/g;
const PARSER_CACHE = new Map<string, KernelFunction[]>();

// 'd': String.raw`(0?[1-9]|[12][0-9]|3[01])[\/\-\. ]{0,1}`,
// 'M': String.raw`(0?[1-9]|1[012])[\/\-. ]{0,1}`,
export class PatternCompiler {
  private static PATTERN_TOKENS = /E{3,4}|d{1,2}|[./-]|M{1,4}|y{1,4}|([HhmsTt])\1?|[LloSZWN]|'[^']*'|'[^']*'/g;
  private static BASE_SYMBOL_REGEX_MAP: {[format: string]: string} = {
    'E': String.raw`([\u00BF-\u1FFF\u2C00-\uD7FF\w]{1,4})[ ]{1,3}`,
    'd': String.raw`(\d{1,2})[./-]{0,1}`,
    'M': String.raw`(\d{1,2})[./-]{0,1}`,
    'y': String.raw`(\d{0,4})[./-]{0,1}`,
    ':': String.raw`[:]{0,1}`,
    'H': String.raw`(0?[0-9]|1[0-9]|2[0-4])`,
    'm': String.raw`(0?[0-9]|[10-59]`,
    's': String.raw`(0?[0-9]|[10-59]`
  };
  private static assemble = (sym: string[], map: {[format: string]: string}) => {
    const raw0 = String.raw`/^`, rawN = String.raw`/g`, agg = String.raw`${raw0}`;
    let ret = sym.reduce((a, e) => (a + String.raw`${map[e]}`), agg);
    return (ret + String.raw`${rawN}`);
  }

  static compile(pattern: string): Function {
    let parts: string[] = [];
    pattern.replace(PatternCompiler.PATTERN_TOKENS, (...rest: any[]) => {
      parts.push(rest[0][0]);
      return '';
    });
    parts = parts.filter((e) => !/[\/\-. ]/.test(e));
    let ret = PatternCompiler.assemble(parts, PatternCompiler.BASE_SYMBOL_REGEX_MAP);
    console.log(ret);
    // console.log(PatternCompiler.assemble(parts, PatternCompiler.BASE_SYMBOL_REGEX_MAP));
    return new Function(`return ${ret}`);
  }
}

const enum DateCompletionHint {
  CURRENT,
  PAST,
  FUTURE,
  PASTCURRENT,
  FUTURECURRENT,
  DEFAULT = CURRENT
}

function toCompletionHintEnum(hint: string) {
  if (hint === 'past') {
    return DateCompletionHint.PAST;
  } else if (hint === 'future') {
    return DateCompletionHint.FUTURE;
  } else if (hint === 'pastcurrent') {
    return DateCompletionHint.PASTCURRENT;
  } else if (hint === 'futurecurrent') {
    return DateCompletionHint.FUTURECURRENT;
  }
  return DateCompletionHint.DEFAULT;
}

function toNum(value: string): number {
  return isNumeric(value) ? +value : NaN;
}

function isNumeric(value: any): boolean {
  return !isNaN(value - parseFloat(value));
}

export const getKernelFunction = (descr: ParserSymbolDescriptor): KernelFunction => {
  const PARSER_KERNEL: {[format: string]: KernelFunction} = {
    // Keys are quoted so they do not get renamed.
    'yyyy': parse_y(descr),
    'yy': parse_y(descr),
    'y': parse_y(descr),
    'MM': parse_M(descr),
    'M': parse_M(descr),
    'dd': parse_d(descr),
    'd': parse_d(descr),
    'HH': parse_H(descr),
    'H': parse_H(descr),
    'mm': parse_m(descr),
    'm': parse_m(descr),
    'ss': parse_s(descr),
    's': parse_s(descr)
  };
  return PARSER_KERNEL[descr.symbol];
};

/**
 * Day parser function.
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_d(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = TS.Numbers.toNum(extract);
    num = (num > 0 && num < 32) ? num : NaN;
    return {'symbol': descr.symbol, 'result': num};
  };
}

/**
 * Month parser function.
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_M(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = toNum(extract) - 1;
    num = (num >= 0 && num < 12) ? num : NaN;
    return {'symbol': descr.symbol, 'result': num};
  };
}

/**
 * Year parser function.
 * If there are 3 or more YEAR pattern characters, this indicates
 * that the year value is to be treated literally, without any
 * two-digit year adjustments (e.g., from "01" to 2001).  Otherwise
 * we made adjustments to place the 2-digit year in the proper
 * century, for parsed strings from "00" to "99".  Any other string
 * is treated literally:  "2250", "-1", "1", "002".
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_y(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = toNum(extract);
    if (TS.Numbers.isNaN(num)) { return {'symbol': descr.symbol, 'result': num}; }

    let century: TS.Dates.DefaultCentury = TS.Dates.initDefaultCentury();
    console.log(century);
    if (String(num).length < 3) {
      // console.log('descr.len < 3:' + descr.len);

      // Assume for example that the century.start is 6/18/1903.
      // This means that two-digit years will be forced into the range
      // 6/18/1903 to 6/17/2003.  As a result, years 00, 01, and 02
      // correspond to 2000, 2001, and 2002.  Years 04, 05, etc. correspond
      // to 1904, 1905, etc.  If the year is 03, then it is 2003 if the
      // other fields specify a date before 6/18, or 1903 if they specify a
      // date afterwards.  As a result, 03 is an ambiguous year.  All other
      // two-digit years are unambiguous.
      num += Math.trunc((century.year / 100)) * 100 + ( num < century.twodigityear ? 100 : 0);
    }
    console.log(`parse_y: extract => ${extract} num => ${num}`);
    num = (num >= 0 && num < 10000) ? num : NaN;
    return {'symbol': descr.symbol, 'result': num};
  };
}

/**
 * Hour parser function.
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_H(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = toNum(extract);
    num = (num >= 0 && num < 24) ? num : 0;
    return {'symbol': descr.symbol, 'result': num};
  };
}

/**
 * Minutes parser function.
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_m(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = toNum(extract);
    num = (num >= 0 && num < 60) ? num : 0;
    return {'symbol': descr.symbol, 'result': num};
  };
}

/**
 * Seconds parser function.
 * @param {ParserSymbolDescriptor} descr
 * @returns {KernelFunction}
 */
function parse_s(descr: ParserSymbolDescriptor): KernelFunction {
  return (date: string): KernelFunctionResult => {
    const extract = date.substr(descr.pos, descr.len);
    let num = toNum(extract);
    num = (num >= 0 && num < 60) ? num : 0;
    return {'symbol': descr.symbol, 'result': num};
  };
}


const compileResult = (format: string, value: string, hint: string, parts: KernelFunction[]): ParserResult => {
  let year: number = -1, month: number = -1, day: number = -1,
    date: Date, completionHint: DateCompletionHint, valid: boolean = true;
  const ret: {[symbol: string]: KernelFunctionResult} = {
    'd': {'symbol': 'd', 'result': day},
    'M': {'symbol': 'M', 'result': month},
    'y': {'symbol': 'y', 'result': year},
    'H': {'symbol': 'H', 'result': 0},
    'm': {'symbol': 'm', 'result': 0},
    's': {'symbol': 's', 'result': 0}
  };

  console.log(`compileResult: val: ${value} format: ${format}`);

  // length + max 2 separator
  if (value.length > format.length) {
    return { date: null, format: format, value: value, isvalid: false, hint: hint, details: null };
  }

  let result = parts.reduce((result, f) => {
    const tpr = f(value);
    valid = isNaN(tpr.result) ? false : valid;
    ret[tpr.symbol[0]] = tpr;
    return ret;
  }, ret);

  completionHint = toCompletionHintEnum(hint);
  year = result['y'].result === -1 ? new Date().getFullYear() : result['y'].result;
  month = result['M'].result === -1 ? new Date().getMonth() : result['M'].result - 1;
  day = result['d'].result === -1 ? new Date().getDate() : result['d'].result;
  valid = valid && TS.Dates.isValidDayOfMonth(year, month, day);

  // if (!TS.Dates.isValidDayOfMonth(year, month, day)) { valid = false; }
  if (valid && result['y'].result === -1) {
    switch (completionHint) {
      case DateCompletionHint.FUTURECURRENT:

        date = TS.Dates.completeToFutureCurrent(result['d'].result, result['M'].result);
        break;
      case DateCompletionHint.FUTURE:
        date = TS.Dates.completeToFuture(result['d'].result, result['M'].result);
        break;
      case DateCompletionHint.PASTCURRENT:
        date = TS.Dates.completeToPastCurrent(result['d'].result, result['M'].result);
        break;
      case DateCompletionHint.PAST:
        date = TS.Dates.completeToPast(result['d'].result, result['M'].result);
        break;
      default:
        date = TS.Dates.completeToCurrent(result['d'].result, result['M'].result);
        break;
    }
    date.setHours(result['H'].result, result['m'].result, result['s'].result);
  } else if (valid) {
    date = new Date();
    date.setFullYear(result['y'].result, result['M'].result, result['d'].result);
    date.setHours(result['H'].result, result['m'].result, result['s'].result);
  }
  return { date: date, format: format, value: value, isvalid: valid, hint: hint, details: result };
};

function parseWithHint(date: string = '', format: string = ''): ParserResult {

  // if (date.length !== format.length) {
  //   return [];
  // }
  // console.log(`parseWithHint: date: ${date} format: ${format} type:  ${typeof format === 'string'}`);
  let parts: KernelFunction[] = PARSER_CACHE.get(format);
  // console.log(`FORMAT: ${format}`);
  let completionHint: string = 'current';
  if (!parts) {
    parts = [];
    format = format.replace(COMPLETION_TOKEN_MATCHER, (match, hint) => {
      completionHint = hint;
      return '';
    });

    format.replace(PARSER_TOKEN_MATCHER, (...rest: any[]) => {
      console.log(rest);
      const ret = getKernelFunction({symbol: rest[0], pos: rest[rest.length - 2], len: rest[0].length});
      if (ret) {
        parts.push(ret);
      }
      return '';
    });
    PARSER_CACHE.set(format, parts);
  }

  return compileResult(format, date, completionHint, parts);
}

export class DateParser {
  static parse(value: string, parsehints: string[]): Date {
    // console.log('##### DateParser::parse...START...');

    for (const hint of parsehints) {
      console.log(`val: ${value} hint: ${hint}`);
      let res: ParserResult = parseWithHint(value, hint);
      // console.log(res);
      if (res.isvalid) {
        // console.log('##### DateParser::parse...END.');
        return res.date;
      }

    }
    // console.log('##### DateParser::parse...END.');
    return null;

  }
}
