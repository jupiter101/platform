@tide/validation
=======

©TIDE standard validation components.


see: [javax.validation.constraints](https://docs.oracle.com/javaee/7/api/javax/validation/constraints/package-frame.html)
