export default {
  entry: './dist/base/@tide/base.es5.js',
  dest: './dist/base/bundles/base.umd.js',
  format: 'umd',
  exports: 'named',
  moduleName: 'tide.base',
  globals: {
    '@angular/core': 'ng.core',
    '@angular/forms': 'ng.forms',
    'rxjs/Observable': 'Rx',
    'rxjs/Subscription': 'Rx',
    'rxjs/operator/filter': 'Rx.Observable.prototype',
    'rxjs/operator/ignoreElements': 'Rx.Observable.prototype',
    'rxjs/observable/merge': 'Rx.Observable'
  }
}
