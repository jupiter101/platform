// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {TIDEDateFormat, TIDEDateFormatPattern} from '../src/format/date/tidedateformat';
import {IntlDateFormatter} from '../src/format/date/intldateformatter';
import {IFormat} from '../src/format';

describe(`Dateformat DE (isolated unit tests)`, () => {
  let currentDate: Date = new Date(2017, 10, 8, 11, 30, 0, 0);
  let pattern = TIDEDateFormatPattern.from('de_de');
  let dtfmt: IFormat = new IntlDateFormatter('de');

  it(`TIDEDateFormat.DOW_Y_M_D `, () => {
    // console.log(pattern(TIDEDateFormat.DOW_Y_M_D));
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.DOW_Y_M_D));
    expect(fmt).toBe('Mittwoch 08.11.2017');
  });

  it(`TIDEDateFormat.SDOW_Y_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_Y_M_D));
    console.log('\n' + fmt);
    expect(fmt).toBe('Mi 08.11.2017');
  });

  it(`TIDEDateFormat.SDOW_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H_M_S));
    expect(fmt).toBe('Mi 11:30:00');
  });

  it(`TIDEDateFormat.SDOW_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H_M));
    expect(fmt).toBe('Mi 11:30');
  });

  it(`TIDEDateFormat.SDOW_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H));
    expect(fmt).toBe('Mi 11');
  });

  it(`TIDEDateFormat.SDOW `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW));
    expect(fmt).toBe('Mi');
  });

  it(`TIDEDateFormat.Y_M_D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H_M_S));
    expect(fmt).toBe('08.11.2017 11:30:00');
  });

  // ###
  it(`TIDEDateFormat.Y_M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H_M));
    expect(fmt).toBe('08.11.2017 11:30');
  });

  it(`TIDEDateFormat.Y_M_D_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_HM));
    console.log('\n' + fmt);
    expect(fmt).toBe('08.11.2017 1130');
  });

  it(`TIDEDateFormat.Y_M_D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H));
    expect(fmt).toBe('08.11.2017 11');
  });

  it(`TIDEDateFormat.YMD_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_H));
    expect(fmt).toBe('08112017 11');
  });

  it(`TIDEDateFormat.YMD_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_H_M));
    expect(fmt).toBe('08112017 11:30');
  });

  it(`TIDEDateFormat.YMD_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_HM));
    expect(fmt).toBe('08112017 1130');
  });

  it(`TIDEDateFormat.YMDHM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMDHM));
    expect(fmt).toBe('081120171130');
  });

  it(`TIDEDateFormat.SYMD_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_H));
    expect(fmt).toBe('081117 11');
  });

  it(`TIDEDateFormat.SYMD_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_H_M));
    expect(fmt).toBe('081117 11:30');
  });

  it(`TIDEDateFormat.SYMD_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_HM));
    expect(fmt).toBe('081117 1130');
  });

  it(`TIDEDateFormat.Y_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D));
    expect(fmt).toBe('08.11.2017');
  });

  it(`TIDEDateFormat.YMD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD));
    expect(fmt).toBe('08112017');
  });

  it(`TIDEDateFormat.SYMD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD));
    expect(fmt).toBe('081117');
  });

  it(`TIDEDateFormat.SY_M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M_D_H_M));
    expect(fmt).toBe('08.11.17 11:30');
  });

  it(`TIDEDateFormat.SY_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M_D));
    expect(fmt).toBe('08.11.17');
  });

  it(`TIDEDateFormat.M_D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H_M_S));
    expect(fmt).toBe('08.11. 11:30:00');
  });

  it(`TIDEDateFormat.M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H_M));
    expect(fmt).toBe('08.11. 11:30');
  });

  it(`TIDEDateFormat.M_D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H));
    expect(fmt).toBe('08.11. 11');
  });

  it(`TIDEDateFormat.M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H_M_S));
    expect(fmt).toBe('08 11:30:00');
  });

  it(`TIDEDateFormat.D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H_M));
    expect(fmt).toBe('08 11:30');
  });

  it(`TIDEDateFormat.D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H));
    expect(fmt).toBe('08 11');
  });

  it(`TIDEDateFormat.H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.H_M_S));
    expect(fmt).toBe('11:30:00');
  });

  it(`TIDEDateFormat.HMS `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HMS));
    expect(fmt).toBe('113000');
  });

  it(`TIDEDateFormat.H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.H_M));
    expect(fmt).toBe('11:30');
  });

  it(`TIDEDateFormat.HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HM));
    expect(fmt).toBe('1130');
  });

  it(`TIDEDateFormat.M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_S));
    expect(fmt).toBe('30:00');
  });

  it(`TIDEDateFormat.YEAR `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YEAR));
    expect(fmt).toBe('2017');
  });

  it(`TIDEDateFormat.MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.HOUR `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HOUR));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.MINUTE `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.MINUTE));
    expect(fmt).toBe('30');
  });

  it(`TIDEDateFormat.SECOND `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SECOND));
    expect(fmt).toBe('00');
  });

  it(`TIDEDateFormat.PAST_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.PAST_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_M_D2));
    expect(fmt).toBe('08.11');
  });

  it(`TIDEDateFormat.PAST_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.PAST_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.PAST_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.PAST_CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.PAST_CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_M_D2));
    expect(fmt).toBe('08.11');
  });

  it(`TIDEDateFormat.PAST_CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.PAST_CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.PAST_CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_M_D2));
    expect(fmt).toBe('08.11');
  });

  it(`TIDEDateFormat.CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.FUTURE_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.FUTURE_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_M_D2));
    expect(fmt).toBe('08.11');
  });

  it(`TIDEDateFormat.FUTURE_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.FUTURE_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.FUTURE_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_M_D));
    expect(fmt).toBe('08.11.');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_M_D2));
    expect(fmt).toBe('08.11');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.Y_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M));
    expect(fmt).toBe('11.2017');
  });

  it(`TIDEDateFormat.YM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YM));
    expect(fmt).toBe('112017');
  });

  it(`TIDEDateFormat.SY_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M));
    expect(fmt).toBe('11.17');
  });

  it(`TIDEDateFormat.SYM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYM));
    expect(fmt).toBe('1117');
  });
});


describe(`Dateformat EN-GB (isolated unit tests)`, () => {
  let currentDate: Date = new Date(2017, 10, 8, 11, 30, 0, 0);
  let pattern = TIDEDateFormatPattern.from('en_gb');
  let dtfmt = new IntlDateFormatter('en');
  let dateformat = dtfmt.format;

  it(`TIDEDateFormat.DOW_Y_M_D `, () => {
    // console.log(pattern(TIDEDateFormat.DOW_Y_M_D));
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.DOW_Y_M_D));
    expect(fmt).toBe('Wednesday 08/11/2017');
  });

  it(`TIDEDateFormat.SDOW_Y_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_Y_M_D));
    expect(fmt).toBe('Wed 08/11/2017');
  });

  it(`TIDEDateFormat.SDOW_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H_M_S));
    expect(fmt).toBe('Wed 11:30:00');
  });

  it(`de:TIDEDateFormat.SDOW_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H_M));
    expect(fmt).toBe('Wed 11:30');
  });

  it(`de:TIDEDateFormat.SDOW_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW_H));
    expect(fmt).toBe('Wed 11');
  });

  it(`de:TIDEDateFormat.SDOW `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SDOW));
    expect(fmt).toBe('Wed');
  });

  it(`de:TIDEDateFormat.Y_M_D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H_M_S));
    expect(fmt).toBe('08/11/2017 11:30:00');
  });

  // ###
  it(`TIDEDateFormat.Y_M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H_M));
    expect(fmt).toBe('08/11/2017 11:30');
  });

  it(`TIDEDateFormat.Y_M_D_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_HM));
    expect(fmt).toBe('08/11/2017 1130');
  });

  it(`TIDEDateFormat.Y_M_D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D_H));
    expect(fmt).toBe('08/11/2017 11');
  });

  it(`TIDEDateFormat.YMD_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_H));
    expect(fmt).toBe('08112017 11');
  });

  it(`TIDEDateFormat.YMD_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_H_M));
    expect(fmt).toBe('08112017 11:30');
  });

  it(`TIDEDateFormat.YMD_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD_HM));
    expect(fmt).toBe('08112017 1130');
  });

  it(`TIDEDateFormat.YMDHM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMDHM));
    expect(fmt).toBe('081120171130');
  });

  it(`TIDEDateFormat.SYMD_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_H));
    expect(fmt).toBe('081117 11');
  });

  it(`TIDEDateFormat.SYMD_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_H_M));
    expect(fmt).toBe('081117 11:30');
  });

  it(`TIDEDateFormat.SYMD_HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD_HM));
    expect(fmt).toBe('081117 1130');
  });

  it(`TIDEDateFormat.Y_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M_D));
    expect(fmt).toBe('08/11/2017');
  });

  it(`TIDEDateFormat.YMD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YMD));
    expect(fmt).toBe('08112017');
  });

  it(`TIDEDateFormat.SYMD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYMD));
    expect(fmt).toBe('081117');
  });

  it(`TIDEDateFormat.SY_M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M_D_H_M));
    expect(fmt).toBe('08/11/17 11:30');
  });

  it(`TIDEDateFormat.SY_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M_D));
    expect(fmt).toBe('08/11/17');
  });

  it(`TIDEDateFormat.M_D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H_M_S));
    expect(fmt).toBe('08/11 11:30:00');
  });

  it(`TIDEDateFormat.M_D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H_M));
    expect(fmt).toBe('08/11 11:30');
  });

  it(`TIDEDateFormat.M_D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D_H));
    expect(fmt).toBe('08/11 11');
  });

  it(`TIDEDateFormat.M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.D_H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H_M_S));
    expect(fmt).toBe('08 11:30:00');
  });

  it(`TIDEDateFormat.D_H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H_M));
    expect(fmt).toBe('08 11:30');
  });

  it(`TIDEDateFormat.D_H `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.D_H));
    expect(fmt).toBe('08 11');
  });

  it(`TIDEDateFormat.H_M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.H_M_S));
    expect(fmt).toBe('11:30:00');
  });

  it(`TIDEDateFormat.HMS `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HMS));
    expect(fmt).toBe('113000');
  });

  it(`TIDEDateFormat.H_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.H_M));
    expect(fmt).toBe('11:30');
  });

  it(`TIDEDateFormat.HM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HM));
    expect(fmt).toBe('1130');
  });

  it(`TIDEDateFormat.M_S `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.M_S));
    expect(fmt).toBe('30:00');
  });

  it(`TIDEDateFormat.YEAR `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YEAR));
    expect(fmt).toBe('2017');
  });

  it(`TIDEDateFormat.MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.DAY));
    console.log('\n' + fmt);
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.HOUR `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.HOUR));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.MINUTE `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.MINUTE));
    expect(fmt).toBe('30');
  });

  it(`TIDEDateFormat.SECOND `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SECOND));
    expect(fmt).toBe('00');
  });

  it(`TIDEDateFormat.PAST_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.PAST_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_M_D2));
    expect(fmt).toBe('08/11/');
  });

  it(`TIDEDateFormat.PAST_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.PAST_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.PAST_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.PAST_CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.PAST_CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_M_D2));
    expect(fmt).toBe('08/11/');
  });

  it(`TIDEDateFormat.PAST_CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.PAST_CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.PAST_CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.PAST_CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_M_D2));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.FUTURE_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.FUTURE_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_M_D2));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.FUTURE_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.FUTURE_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_MONTH));
    console.log('\n' + fmt);
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.FUTURE_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_M_D `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_M_D));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_M_D2 `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_M_D2));
    expect(fmt).toBe('08/11');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_MD `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_MD));
    expect(fmt).toBe('0811');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_MONTH `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_MONTH));
    expect(fmt).toBe('11');
  });

  it(`TIDEDateFormat.FUTURE_CURRENT_DAY `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.FUTURE_CURRENT_DAY));
    expect(fmt).toBe('08');
  });

  it(`TIDEDateFormat.Y_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.Y_M));
    expect(fmt).toBe('11/2017');
  });

  it(`TIDEDateFormat.YM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.YM));
    expect(fmt).toBe('112017');
  });

  it(`TIDEDateFormat.SY_M `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SY_M));
    expect(fmt).toBe('11/17');
  });

  it(`TIDEDateFormat.SYM `, () => {
    let fmt = dtfmt.format(currentDate, pattern(TIDEDateFormat.SYM));
    expect(fmt).toBe('1117');
  });
});
