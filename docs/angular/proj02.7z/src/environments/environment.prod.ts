export const environment = {
  production: true,
  baseApiUrl: 'https://yg6g6k98hj.execute-api.eu-west-1.amazonaws.com/apitest/v1',
  region: 'eu-west-1',
  identityPoolId: 'eu-west-1:4d0a006c-a882-44f7-af0d-417e3de3f92f',
  userPoolId: 'eu-west-1_8sAUHPm0m',
  clientId: '46fe4fhh09rpu1c0egf4pp47kr',
  tokenIssuerLoginUrl: `cognito-idp.${this.region}.amazonaws.com/${this.userPoolId}`,
  cognito_idp_endpoint: null,
  cognito_identity_endpoint: null,
  sts_endpoint: null
};
