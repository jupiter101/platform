// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  baseApiUrl: 'https://yg6g6k98hj.execute-api.eu-west-1.amazonaws.com/apitest/v1',
  region: 'eu-west-1',
  identityPoolId: 'eu-west-1:4d0a006c-a882-44f7-af0d-417e3de3f92f',
  userPoolId: 'eu-west-1_8sAUHPm0m',
  clientId: '46fe4fhh09rpu1c0egf4pp47kr',
  tokenIssuerLoginUrl: `cognito-idp.${this.region}.amazonaws.com/${this.userPoolId}`,
  cognito_idp_endpoint: null,
  cognito_identity_endpoint: null,
  sts_endpoint: null

  //  stephan
  //  Test1234!
  // new: Test1238!
};
