import { Component, ElementRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { IBrand } from '../../model/brand.model';
declare let jQuery: any;

@Component({
  selector: 'cn-edit-supplier-data',
  templateUrl: './edit-supplier-data.component.html',
  styleUrls: ['./edit-supplier-data.component.css']
})
export class EditSupplierDataComponent {
  @Input() selectedBrand: IBrand;
  @Output() onSaveBrand = new EventEmitter<IBrand>();
  @ViewChild('editSupplierDataModal') modal: ElementRef;

  openModal() {
    jQuery(this.modal.nativeElement).modal('show');
  }

  closeModal() {
    jQuery(this.modal.nativeElement).modal('hide');
  }

  onCancel() {
    this.closeModal();
  }

  onDeleteInputs() {
    this.selectedBrand.user = '';
    this.selectedBrand.password = '';
    this.selectedBrand.wait_days = 0;
  }

  onSubmit() {
    this.onSaveBrand.emit(this.selectedBrand);
    this.closeModal();
  }
}
