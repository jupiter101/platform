// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {IAuthService, IAuthServiceEventParameter} from '../../service/auth.service.spi';
import {Router} from '@angular/router';
import {User} from '../../model/user.model';
import {NewPasswordComponent} from '../new-password/new-password.component';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'cn-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  @ViewChild(NewPasswordComponent) newPasswordComponent: NewPasswordComponent;
  errMessage = '';
  userModel: User;
  private subscriptions: any[] = [];

  constructor(@Inject('IAuthService') private authService: IAuthService,
              private router: Router,
              private translate: TranslateService) { }

  ngOnInit() {
    this.userModel = new User();
    this.subscriptions[0] = this.authService.AuthenticationSuccessEvent
      .subscribe(data  => this.onAuthenticationSuccess(data));
    this.subscriptions[1] = this.authService.AuthenticationFailedEvent
      .subscribe(data  => this.onAuthenticationFailed(data));
    this.subscriptions[2] = this.authService.AuthenticationNewPasswordRequiredEvent
      .subscribe(data  => this.onAuthenticationNewPasswordRequired(data));
  }

  /**
   * Cleanup routine.
   * @author Stephan Petzchen
   */
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  /**
   * Event handler for forgot password routine needs a validation code.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationInputValidationCode(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationInputValidationCode...');
    this.errMessage = 'Validation code required';
  }

  /**
   * Event handler for forgot password routine
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationForgotPassword(p: IAuthServiceEventParameter) {
    if (p.message) { // error
      this.errMessage = p.message;
      console.log('onAuthenticationForgotPassword: ' + p.message);
    } else { // success
      console.log('onAuthenticationForgotPassword: ');
    }

  }

  /**
   * Event handler for AuthenticationConfirmNewPassword event when
   * user needs to confirm new password.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationConfirmNewPassword(p: IAuthServiceEventParameter) {
    if (p.message) { // error
      this.errMessage = p.message;
      console.log('onAuthenticationConfirmNewPassword: ' + p.message);
    } else { // success
      console.log('onAuthenticationConfirmNewPassword: ');
    }
  }

  /**
   * Event handler for AuthenticationLoggedOut event when user signed out.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationLoggedOut(p: IAuthServiceEventParameter) {
    this.errMessage = p.message;
    console.log('User is authenticated: ' + p.data);
    this.router.navigate(['/home/newPassword']);
  }

  /**
   * Event handler for AuthenticationIsAuthenticated event fired
   * when isAuthenticated has been called.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationIsAuthenticated(p: IAuthServiceEventParameter) {
    this.errMessage = p.message;
    console.log('User is authenticated: ' + p.data);
    this.router.navigate(['/home/newPassword']);
  }

  /**
   * Event handler for AuthenticationNewPasswordRequired event fired when
   * new password is required after first log in.
   * @param {IAuthServiceEventParameter} p
   *
   * @author Stephan Petzchen
   */
  onAuthenticationNewPasswordRequired(p: IAuthServiceEventParameter) {
    this.errMessage = p.message;
    console.log('Authentication new password required: ' + p.message);
    this.newPasswordComponent.openModal();
  }

  /**
   * Event handler for AuthenticationNewPasswordRequired event fired
   * when authentication failed.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationFailed(p: IAuthServiceEventParameter) {
    this.translate.get('LOGIN.COGNITO.AUTHFAILED', {value: 'world'}).subscribe((res: string) => {
      console.log(res);
      this.errMessage = res;
    });

    console.log('Authentication failed: ' + p.message);
    if (p.message === 'User is not confirmed.') {
      // TODO verify confirmation flow
      console.log('redirecting');
    }
  }

  /**
   * Event handler for AuthenticationNewPasswordRequired event fired
   * when authentication succeeded.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationSuccess(p: IAuthServiceEventParameter) {
    console.log('routing to /supplier');
    this.router.navigate(['/supplier']);
  }

  login() {
    console.log('Logging in User: ' + this.userModel.email + ' ' + this.userModel.password);
    this.authService.authenticate(this.userModel.email, this.userModel.password);
  }
}
