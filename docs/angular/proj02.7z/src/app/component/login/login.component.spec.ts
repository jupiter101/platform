// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import {CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {ApiService} from '../../service/impl/api.service';
import {AuthService} from '../../service/impl/auth.service';
import {CognitoService} from '../../service/impl/cognito.service';
import {FormsModule} from '@angular/forms';
import {RouterTestingModule} from '@angular/router/testing';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {HttpClient, HttpClientModule} from '@angular/common/http';

function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let element: any;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      declarations: [ LoginComponent ],
      imports: [
        RouterTestingModule,
        FormsModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useFactory: HttpLoaderFactory,
            deps: [HttpClient]
          }
        })
      ],
      providers: [
        { provide: 'IApiService', useClass: ApiService },
        { provide: 'IAuthService', useClass: AuthService },
        { provide: 'ICognitoService', useClass: CognitoService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should send credentials on submit', () => {
    const loginUser = 'stephan';
    const loginPass = 'Test1237!';
    element.querySelector('#email').value = loginUser;
    element.querySelector('#email').dispatchEvent(new Event('input'));
    element.querySelector('#password').value = loginPass;
    element.querySelector('#password').dispatchEvent(new Event('input'));
    fixture.detectChanges();


    element.querySelector('button[type="submit"]').click();
  });
});
