// tslint:disable:no-trailing-whitespace
// tslint:disable:no-input-rename
import {Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {IAuthService, IAuthServiceEventParameter} from '../../service/auth.service.spi';
import {TranslateService} from '@ngx-translate/core';
declare let jQuery: any;

@Component({
  selector: 'cn-new-password',
  templateUrl: './new-password.component.html',
  styleUrls: ['./new-password.component.css']
})
export class NewPasswordComponent implements OnInit, OnDestroy {
  @ViewChild('newPasswordModal') modal: ElementRef;
  username = '';
  temporaryPassword = '';
  newPassword = '';
  newPasswordRepeat = '';
  passwordsDoNotMatch = false;
  passwordsSuccessfullyChanged = false;
  private subscriptions: any[] = [];

  constructor(@Inject('IAuthService')private authService: IAuthService) { }

  ngOnInit() {
    this.subscriptions[0] = this.authService.AuthenticationNewPasswordChallengeEvent
      .subscribe(data  => this.onAuthenticationNewPasswordChallenge(data));
  }

  /**
   * Cleanup routine.
   * @author Stephan Petzchen
   */
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  openModal() {
    jQuery(this.modal.nativeElement).modal('show');
  }

  onButtonClick() {
    if (this.newPassword !== this.newPasswordRepeat) {
      this.passwordsDoNotMatch = true;
      this.passwordsSuccessfullyChanged = false;
    } else {
      this.passwordsDoNotMatch = false;
      this.authService.newPasswordChallenge(this.username, this.temporaryPassword, this.newPassword);
    }
  }

  onAuthenticationNewPasswordChallenge(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationNewPasswordChallenge: ' + p.data);
    this.passwordsSuccessfullyChanged = !p.message;
  }
}
