// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {IAuthService, IAuthServiceEventParameter} from '../../service/auth.service.spi';

@Component({
  selector: 'cn-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy {
  private _isAuthenticated: boolean;
  private subscriptions: any[] = [];
  constructor(@Inject('IAuthService') public authService: IAuthService,
              private router: Router) {}

  ngOnInit() {
    console.log('NavbarComponent::ngOnInit');
    this.subscriptions[0] = this.authService.AuthenticationSuccessEvent
      .subscribe(data  => this.onAuthenticationSuccess(data));
    this.subscriptions[1] = this.authService.AuthenticationFailedEvent
      .subscribe(data  => this.onAuthenticationFailed(data));
    this.subscriptions[3] = this.authService.AuthenticationIsAuthenticatedEvent
      .subscribe(data  => this.onAuthenticationIsAuthenticated(data));
    this.subscriptions[4] = this.authService.AuthenticationLoggedOutEvent
      .subscribe(data  => this.onAuthenticationLoggedOut(data));

    this.authService.isAuthenticated().subscribe(
      data => {
        this._isAuthenticated = data;
      },
      err => {
        this._isAuthenticated = false;
        console.log('[!] error: ' + err);
      });
  }

  /**
   * Cleanup routine.
   * @author Stephan Petzchen
   */
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  /**
   * Event handler for AuthenticationLoggedOut event when user signed out.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationLoggedOut(p: IAuthServiceEventParameter) {
    this._isAuthenticated = false;
  }

  /**
   * Event handler for AuthenticationIsAuthenticated event fired
   * when isAuthenticated has been called.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationIsAuthenticated(p: IAuthServiceEventParameter) {
    this._isAuthenticated = p.data;
  }

  /**
   * Event handler for AuthenticationNewPasswordRequired event fired
   * when authentication failed.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationFailed(p: IAuthServiceEventParameter) {
    console.log('NavbarComponent::onAuthenticationFailed');
    this._isAuthenticated = false;
  }

  /**
   * Event handler for AuthenticationNewPasswordRequired event fired
   * when authentication succeeded.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationSuccess(p: IAuthServiceEventParameter) {
    console.log('NavbarComponent::onAuthenticationSuccess');
    this._isAuthenticated = true;
  }

  showLogoutButton(): boolean {
    // console.log('NavbarComponent::showLogoutButton: ' + this._isAuthenticated);
    return this._isAuthenticated;
  }

  logout() {
    console.log('NavbarComponent::logout');
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}
