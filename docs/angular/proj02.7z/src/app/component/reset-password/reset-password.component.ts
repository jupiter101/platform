// tslint:disable:no-trailing-whitespace
// tslint:disable:no-input-rename
import {Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {IAuthService, IAuthServiceEventParameter} from '../../service/auth.service.spi';
import {TranslateService} from '@ngx-translate/core';

@Component({
  selector: 'cn-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  @ViewChild('closeModal') closeModal: ElementRef;
  hasErrors = false;
  hasInfos = false;
  preflightStep = false;
  passwordSuccessfullyReset = false;
  errorMessage = '';
  infoMessage = '';

  email = '';
  newPassword = '';
  newPasswordRepeat = '';
  confirmationCode = '';
  private subscriptions: any[] = [];

  constructor(@Inject('IAuthService')private authService: IAuthService,
              private translate: TranslateService) { }

  /**
   * Register relevant forgot password flow events.
   * @author Stephan Petzchen
   */
  ngOnInit() {
    this.subscriptions[0] = this.authService.AuthenticationForgotPasswordEvent
      .subscribe(data  => this.onAuthenticationForgotPassword(data));
    this.subscriptions[1] = this.authService.AuthenticationConfirmNewPasswordEvent
      .subscribe(data  => this.onAuthenticationConfirmNewPassword(data));
    this.subscriptions[2] = this.authService.AuthenticationInputValidationCodeEvent
      .subscribe(data  => this.onAuthenticationInputValidationCode(data));
    this.subscriptions[3] = this.authService.AuthenticationResendConfirmationCodeEvent
      .subscribe(data  => this.onAuthenticationResendConfirmationCode(data));
    this.preflightStep = true;
  }

  /**
   * Cleanup routine.
   * @author Stephan Petzchen
   */
  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  /**
   * Handles Step 1 input.
   * @author Stephan Petzchen
   */
  onNext() {
    this.hasInfos = false;
    this.hasErrors = false;
    this.authService.forgotPassword(this.email);
  }

  /**
   * Handles Step 2 input.
   * @author Stephan Petzchen
   */
  onFinish() {
    this.hasInfos = false;
    if (this.newPassword !== this.newPasswordRepeat) {
      this.hasErrors = true;
      this.translate.get('RESETPASSWORD.PASSWORDMISSMATCH', {value: 'world'}).subscribe((res: string) => {
        console.log(res);
        this.errorMessage = res;
      });
    } else {
      this.hasErrors = false;
      this.authService.confirmNewPassword(this.email, this.confirmationCode, this.newPassword);
    }
  }

  /**
   * Handles resend confirmation code request.
   * @author Stephan Petzchen
   * @experimental
   */
  onResend(event: Event) {
    this.hasErrors = false;
    this.hasInfos = false;
    console.log('resend confirmation code');
    this.authService.resendConfirmationCode(this.email);
    event.stopPropagation();
    return false;
  }

  /**
   * Event handler for the AuthenticationForgotPasswordEvent.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationForgotPassword(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationForgotPassword: ' + p.message);
    if (p.message != null) { // error
      this.hasErrors = true;

      if (p.message === 'Username/client id combination not found.') {
        this.translate.get('RESETPASSWORD.COGNITO.NOTFOUND', {value: 'world'}).subscribe((res: string) => {
          console.log(res);
          this.errorMessage = res;
        });
      } else if (p.message === 'Attempt limit exceeded, please try after some time.') {
        this.translate.get('RESETPASSWORD.COGNITO.ATTEMPTLIMIT', {value: 'world'}).subscribe((res: string) => {
          console.log(res);
          this.errorMessage = res;
        });
      } else {
        this.translate.get('RESETPASSWORD.COGNITO.AUTHFAILED', {value: 'world'}).subscribe((res: string) => {
          console.log(res);
          this.errorMessage = res;
        });
      }
    }
  }

  /**
   * Event handler for the AuthenticationInputValidationCodeEvent.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationInputValidationCode(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationInputValidationCode: ' + p.message);
    this.preflightStep = false;
  }

  /**
   * Event handler for the AuthenticationConfirmNewPasswordEvent.
   * @param {IAuthServiceEventParameter} p
   * @author Stephan Petzchen
   */
  onAuthenticationConfirmNewPassword(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationConfirmNewPassword: ' + p.message);
    if (p.message == null && p.data == null) { // success
      this.passwordSuccessfullyReset = true;

      setTimeout(() => {
        this.closeModal.nativeElement.click();
        this.hasErrors = false;
        this.passwordSuccessfullyReset = false;
        this.preflightStep = true;
      }, 1000);
    } else { // error
      this.hasErrors = true;
      this.errorMessage = p.message;
    }
  }

  /**
   * Event handler for the AuthenticationResendConfirmationCodeEvent.
   * @param {IAuthServiceEventParameter} p
   * @experimental
   */
  onAuthenticationResendConfirmationCode(p: IAuthServiceEventParameter) {
    console.log('onAuthenticationResendConfirmationCode: ' + p.message);
    if (p.message != null) { // error
      this.hasInfos = false;
      this.hasErrors = true;
      this.errorMessage = p.message;

    } else { // success
      this.hasInfos = true;
      this.translate.get('RESETPASSWORD.COGNITO.RESEND', {value: 'world'}).subscribe((res: string) => {
        console.log(res);
        this.infoMessage = res;
      });
      setTimeout(() => {
        this.hasInfos = false;
        this.infoMessage = '';
      }, 3000);
    }
  }
}
