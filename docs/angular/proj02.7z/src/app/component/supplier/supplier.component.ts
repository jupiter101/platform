import {Component, ElementRef, Inject, OnInit, ViewChild} from '@angular/core';
import {IBrand} from '../../model/brand.model';
import {ISupplierDataApiService} from '../../service/supplier-data.api.service.spi';
import { EditSupplierDataComponent } from '../edit-supplier-data/edit-supplier-data.component';

@Component({
  selector: 'cn-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {
  brandNames: string[];
  selectedBrandName = '';
  brands: IBrand[];
  selectedBrand: IBrand = {id: '', user: '', password: '', wait_days: 0};
  @ViewChild(EditSupplierDataComponent) editSupplierDataComponent: EditSupplierDataComponent;

  constructor(@Inject('ISupplierDataApiService') private supplierDataApi: ISupplierDataApiService) { }

  ngOnInit() {
    this.updateBrandsAndBrandNames();
  }

  updateBrandsAndBrandNames() {
    this.supplierDataApi.getBrands().subscribe(list => {
      this.brands = list.body;
      this.brandNames = this.brands.map(brand => brand.id);
    });
  }

  onButtonClick() {
    this.selectedBrand = Object.assign({}, this.brands.find(b => b.id === this.selectedBrandName)); // clone object
    this.editSupplierDataComponent.openModal();
  }

  onUpdateBrand(updatedBrand: IBrand) {
    this.supplierDataApi.updateBrandData(updatedBrand);
    this.updateBrandsAndBrandNames();
  }
}
