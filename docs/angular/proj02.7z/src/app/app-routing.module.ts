import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './component/login/login.component';
import {SupplierComponent} from './component/supplier/supplier.component';
import {AuthGuard} from './auth.guard';

const routes: Routes = [
  {path: '', redirectTo: '/supplier', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
  {path: 'supplier', component: SupplierComponent, canActivate: [AuthGuard]},
  {path: '**', redirectTo: '/supplier'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
