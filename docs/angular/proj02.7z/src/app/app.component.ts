// tslint:disable:no-trailing-whitespace
import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {IAuthService, IAuthServiceEventParameter} from './service/auth.service.spi';
import {ICognitoService} from './service/cognito.service.spi';
import {IAwsService} from './service/aws.service.spi';
import {Observable} from 'rxjs/Observable';
import {TranslateService} from '@ngx-translate/core';

/**
 * Consider already authenticated users.
 * @author Stephan Petzchen
 */
@Component({
  selector: 'cn-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'cn';

  constructor(@Inject('IAuthService') private authService: IAuthService, private translate: TranslateService) {
    const userAgentLang = translate.getBrowserLang();
    translate.addLangs(['de', 'en', 'fr']);
    translate.setDefaultLang('de');
    translate.use(userAgentLang.match(/de|en|fr/) ? userAgentLang : 'de');
  }

  /**
   * Initialize component with subscribers.
   * @author Stephan Petzchen
   */
  ngOnInit() {
    console.log('AppComponent::ngOnInit');
    console.log('AppComponent: Checking if the user is already authenticated');
    this.authService.isAuthenticated().subscribe(
      data => {
        if (data) {
          console.log('AppComponent::onAuthenticationIsAuthenticated -> Authenticated');
          this.authService.getIdToken().subscribe(
            token => {
              console.log(token);
            },
            tokenErr => {
              console.log('[!] getIdToken() error: ' + tokenErr);
            });
        } else {
          console.log('AppComponent::onAuthenticationIsAuthenticated -> Not authenticated');
        }
      },
      err => {
        console.log('[!] error: ' + err);
      });
  }
}
