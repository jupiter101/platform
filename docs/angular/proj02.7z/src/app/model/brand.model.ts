// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
export interface IBrand {
  id: string;
  user: string;
  password: string;
  wait_days: number;
}
