// tslint:disable:no-trailing-whitespace
import {Inject, Injectable, OnDestroy, OnInit} from '@angular/core';
import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {IAuthService, IAuthServiceEventParameter} from './service/auth.service.spi';

/**
 * Routes to login component when not authenticated (switched to Observable<boolean>).
 * @author Stephan Petzchen
 */
@Injectable()
export class AuthGuard implements CanActivate {
  constructor(@Inject('IAuthService') private authService: IAuthService,
              private router: Router) {}

  canActivate(next: ActivatedRouteSnapshot,
              state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    const isAuthenticated: Observable<boolean> = this.authService.isAuthenticated();
    isAuthenticated.subscribe(
      data => {
        if (!data) {
          this.router.navigate(['/login']);
        }
      },
      err => {
        console.log('[!] AuthGuard::error: ' + err);
        this.router.navigate(['/login']);
      }
    );
    return isAuthenticated;
  }
}
