// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {async, inject, TestBed} from '@angular/core/testing';
import {ApiService} from './api.service';
import {HttpClientModule} from '@angular/common/http';
import {AuthService} from './auth.service';
import {CognitoService} from './cognito.service';
import {RouterTestingModule} from '@angular/router/testing';
import {SupplierDataApiService} from './supplier-data.api.service';


describe('SupplierDataApiService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'IApiService', useClass: ApiService },
        { provide: 'IAuthService', useClass: AuthService },
        { provide: 'ICognitoService', useClass: CognitoService },
        { provide: 'ISupplierDataApiService', useClass: SupplierDataApiService }
      ],
      imports: [
        RouterTestingModule,
        HttpClientModule
      ]
    });
  });

  it('should construct', async(inject(['ISupplierDataApiService'], (service) => {
    expect(service).toBeDefined();
  })));
});
