// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {EventEmitter, Inject, Injectable} from '@angular/core';
import {IAuthService, IAuthServiceEventParameter} from '../auth.service.spi';
import {ICognitoCallback, ICognitoService, ILoggedInCallback} from '../cognito.service.spi';
import {AuthenticationDetails, CognitoUser} from 'amazon-cognito-identity-js';
import * as AWS from 'aws-sdk/global';
import {environment} from '../../../environments/environment';
import * as STS from 'aws-sdk/clients/sts';
import {Observable} from 'rxjs/Observable';

/**
 * Implementation of the IAuthService interface.
 * @author Stephan Petzchen
 */
@Injectable()
export class AuthService implements IAuthService {
  AuthenticationNewPasswordRequiredEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationNewPasswordChallengeEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationFailedEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationSuccessEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationIsAuthenticatedEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationLoggedOutEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationConfirmNewPasswordEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationForgotPasswordEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationInputValidationCodeEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();
  AuthenticationResendConfirmationCodeEvent: EventEmitter<IAuthServiceEventParameter> = new EventEmitter();

  constructor(@Inject('ICognitoService') private cognitoService: ICognitoService) { }

  /**
   * Performs the authentication process.
   * @param {string} username
   * @param {string} password
   * @param {ICognitoCallback} callback
   */
  authenticate(username: string, password: string) {
    console.log(`AuthService::authenticate(${username}, ${password})`);

    const authenticationData = {
      Username: username,
      Password: password,
    };
    const authenticationDetails = new AuthenticationDetails(authenticationData);
    const userData = {
      Username: username,
      Pool: this.cognitoService.getUserPool()
    };
    const cognitoUser = new CognitoUser(userData);
    console.log('AuthService: AWS config is ' + AWS.config);
    const self = this;
    cognitoUser.authenticateUser(authenticationDetails, {
      newPasswordRequired: function (userAttributes, requiredAttributes) {
        self.AuthenticationNewPasswordRequiredEvent.emit({message: 'User needs to set password.', data: null});
      },
      onSuccess: function (result) {
        const creds = self.cognitoService.buildCognitoCreds(result.getIdToken().getJwtToken());
        AWS.config.credentials = creds;

        // So, when CognitoIdentity authenticates a user, it doesn't actually hand us the IdentityID,
        // used by many of our other handlers. This is handled by some sly underhanded calls to AWS Cognito
        // API's by the SDK itself, automatically when the first AWS SDK request is made that requires our
        // security credentials. The identity is then injected directly into the credentials object.
        // If the first SDK call we make wants to use our IdentityID, we have a
        // chicken and egg problem on our hands. We resolve this problem by "priming" the AWS SDK by calling a
        // very innocuous API call that forces this behavior.
        const clientParams: any = {};
        if (environment.sts_endpoint) {
          clientParams.endpoint = environment.sts_endpoint;
        }
        const sts = new STS(clientParams);
        sts.getCallerIdentity(function (err, data) {
          self.AuthenticationSuccessEvent.emit({message: 'User authenticated.', data: result});
        });
      },
      onFailure: function (err) {
        self.AuthenticationFailedEvent.emit({message: err.message, data: null});
      },
    });
  }

  /**
   * Test for authenticated status.
   * @returns {boolean}
   */
  isAuthenticated2(): void {
    console.log('AuthService::isAuthenticated()');
    const cognitoUser = this.cognitoService.getCurrentUser();
    const self = this;
    if (cognitoUser != null) {
      cognitoUser.getSession(function (err, session) {
        if (err) {
          console.log('UserLoginService: Couldn\'t get the session: ' + err, err.stack);
          // callback.isLoggedIn(err, false);
          self.AuthenticationIsAuthenticatedEvent.emit({message: err, data: false});
        } else {
          console.log('UserLoginService: Session is ' + session.isValid());
          // callback.isLoggedIn(err, session.isValid());
          self.AuthenticationIsAuthenticatedEvent.emit({message: err, data: session.isValid()});
        }
      });
    } else {
      console.log('UserLoginService: can\'t retrieve the current user');
      // callback.isLoggedIn('Can\'t retrieve the CurrentUser', false);
      this.AuthenticationIsAuthenticatedEvent.emit({message: 'Can\'t retrieve the CurrentUser', data: false});
    }
  }

  /**
   * Test for authenticated status.
   * @returns {boolean}
   */
  isAuthenticated(): Observable<boolean> {
    return this.cognitoService.isAuthenticated();
  }

  /**
   * Logout user.
   */
  logout(): void {
    this.cognitoService.getCurrentUser().signOut();
    this.AuthenticationLoggedOutEvent.emit({message: null, data: true});
  }

  /**
   * Handles forgoten password requests. Step 1: Sends confirmation code to the user.
   * @param {string} username
   */
  forgotPassword(username: string) {
    const userData = {
      Username: username,
      Pool: this.cognitoService.getUserPool()
    };

    const cognitoUser = new CognitoUser(userData);
    const self = this;
    cognitoUser.forgotPassword({
      onSuccess: function () {
        self.AuthenticationForgotPasswordEvent.emit({message: null, data: null});
      },
      onFailure: function (err) {
        self.AuthenticationForgotPasswordEvent.emit({message: err.message, data: null});
      },
      inputVerificationCode() {
        self.AuthenticationInputValidationCodeEvent.emit({message: null, data: null});
      }
    });
  }

  /**
   * Handles forgoten password requests. Step 2: submits confirmation code with new password.
   * @param {string} email
   * @param {string} verificationCode
   * @param {string} password
   */
  confirmNewPassword(email: string, verificationCode: string, password: string) {
    const userData = {
      Username: email,
      Pool: this.cognitoService.getUserPool()
    };

    const cognitoUser = new CognitoUser(userData);
    const self = this;
    cognitoUser.confirmPassword(verificationCode, password, {
      onSuccess: function () {
        self.AuthenticationConfirmNewPasswordEvent.emit({message: null, data: null});
      },
      onFailure: function (err) {
        self.AuthenticationConfirmNewPasswordEvent.emit({message: err.message, data: null});
      }
    });
  }

  /**
   * Handles resend confirmation code request.
   * @param {string} username
   * @experimental
   */
  resendConfirmationCode(username: string) {
    const userData = {
      Username: username,
      Pool: this.cognitoService.getUserPool()
    };

    const cognitoUser = new CognitoUser(userData);
    const self = this;
    cognitoUser.resendConfirmationCode(function (err, result){
      if (err) {
        self.AuthenticationResendConfirmationCodeEvent.emit({message: err.message, data: null});
      } else {
        self.AuthenticationResendConfirmationCodeEvent.emit({message: null, data: result});
      }
    });
  }

  /**
   * Handles new password challenge.
   * @param {string} username
   * @param {string} temporaryPassword
   * @param {string} password
   */
  newPasswordChallenge(username: string, temporaryPassword: string, password: string): void {
    console.log(username);

    const authenticationData = {
      Username: username,
      Password: temporaryPassword,
    };
    const authenticationDetails = new AuthenticationDetails(authenticationData);
    const userData = {
      Username: username,
      Pool: this.cognitoService.getUserPool()
    };
    const myself = this;

    console.log('UserLoginService: Params set...Authenticating the user');
    const cognitoUser = new CognitoUser(userData);
    console.log('UserLoginService: config is ' + AWS.config);
    cognitoUser.authenticateUser(authenticationDetails, {
      newPasswordRequired: function (userAttributes, requiredAttributes) {
        // User was signed up by an admin and must provide new
        // password and required attributes, if any, to complete
        // authentication.

        userAttributes.name = username;
        requiredAttributes['name'] = username;
        const requiredAttributes2 = {name: username};
        console.log(userAttributes);
        console.log(requiredAttributes);
        console.log(requiredAttributes2);
        // the api doesn't accept this field back
        delete userAttributes.email_verified;

        cognitoUser.completeNewPasswordChallenge(password, requiredAttributes2, {
          onSuccess: function (result) {
            // callback.cognitoCallback(null, userAttributes);
            myself.AuthenticationNewPasswordChallengeEvent.emit({message: null, data: userAttributes});
          },
          onFailure: function (err) {
            myself.AuthenticationNewPasswordChallengeEvent.emit({message: err, data: null});
            // callback.cognitoCallback(err, null);
          }
        });
      },
      onSuccess: function (result) {
        // callback.cognitoCallback(null, result);
        this.AuthenticationNewPasswordChallengeEvent.emit({message: null, data: result});
      },
      onFailure: function (err) {
        // callback.cognitoCallback(err, null);
        this.AuthenticationNewPasswordChallengeEvent.emit({message: err, data: null});
      }
    });
  }

  /**
   * Retrieves access token.
   * @returns {Observable<string>}
   */
  getAccessToken(): Observable<string> { return this.cognitoService.getAccessToken(); }

  /**
   * Retrieves id token.
   * @returns {Observable<string>}
   */
  getIdToken(): Observable<string> { return this.cognitoService.getIdToken(); }

  /**
   * Retrieves refresh token.
   * @returns {Observable<string>}
   */
  getRefreshToken(): Observable<string> { return this.cognitoService.getRefreshToken(); }
}
