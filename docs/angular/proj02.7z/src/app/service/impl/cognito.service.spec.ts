// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {async, inject, TestBed} from '@angular/core/testing';
import {HttpClientModule} from '@angular/common/http';
import {CognitoService} from './cognito.service';
import {RouterTestingModule} from '@angular/router/testing';


describe('CognitoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: 'ICognitoService', useClass: CognitoService }
      ]
    });
  });

  it('should construct', async(inject(['ICognitoService'], (service) => {
    expect(service).toBeDefined();
  })));
});
