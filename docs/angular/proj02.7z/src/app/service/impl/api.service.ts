// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:no-trailing-whitespace
import { Inject, Injectable } from '@angular/core';
// import { Http, Request, RequestOptions, RequestMethod, Response, Headers} from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import { IApiService } from '../api.service.spi';
import { IAuthService } from '../auth.service.spi';

enum RequestMethod {
  Get = 0,
  Post = 1,
  Put = 2,
  Delete = 3,
  Options = 4,
  Head = 5,
  Patch = 6,
}

/**
 * Implementation of the IApiService service interface.
 *
 * @author Stephan Petzchen
 */
@Injectable()
export class ApiService implements IApiService {
  private apiUrl: string = environment.baseApiUrl;
  constructor(@Inject('IAuthService') private auth: IAuthService, private http: HttpClient) { }

  /**
   * Http get service method.
   * @param {string} url
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  get(url: string) {
    return this.request(url, RequestMethod.Get);
  }

  /**
   * Http post service method.
   * @param {string} url
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  post(url: string, body: Object ) {
    return this.request(url, RequestMethod.Post, body);
  }

  /**
   * Http put service method.
   * @param {string} url
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  put(url: string, body: Object) {
    return this.request(url, RequestMethod.Put);
  }

  /**
   * Http delete service method.
   * @param {string} url
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  delete(url: string) {
    return this.request(url, RequestMethod.Delete);
  }


  /**
   * Centralized request helper for api calls.
   * @param {string} url
   * @param {RequestMethod} method
   * @param {Object} body
   * @returns {Observable<any | {errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  private request(url: string, method: RequestMethod, body?: Object) {
    const normalized_url = `${ this.apiUrl }/${url}`;

    let idToken = '';
    this.auth.getIdToken().catch(err => idToken = '').subscribe( data => {
      idToken = data;
    });

    console.log('#####REQUEST...Authorization...');
    console.log(idToken);
    console.log('#####REQUEST...End.');

    let headers: HttpHeaders = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json')
      .append('Authorization', idToken);


    const requestOptions = {
      headers: headers,
      withCredentials: false
    };

    console.log(requestOptions);


    switch (method) {
      case RequestMethod.Get: {
      //   get<T>(url: string, options?: {
      //     headers?: HttpHeaders;
      //   observe?: 'body';
      //   params?: HttpParams;
      //   reportProgress?: boolean;
      //   responseType?: 'json';
      //   withCredentials?: boolean;
      // }): Observable<T>;
        return this.http.get<any>(normalized_url, requestOptions);
      }
      case RequestMethod.Post: {
      //   post(url: string, body: any | null, options?: {
      //     headers?: HttpHeaders;
      //   observe?: 'body';
      //   params?: HttpParams;
      //   reportProgress?: boolean;
      //   responseType?: 'json';
      //   withCredentials?: boolean;
      // }): Observable<Object>;
        console.log('#######POST: ');
        console.log(normalized_url);
        console.log(body);
        const ret: Observable<any> = this.http.post<any>(normalized_url, body, requestOptions);
        console.log('#######POST this.http.post: ');
        ret.subscribe(data => console.log(data));

      }
        break;
      default: {
        return this.http.get<any>(normalized_url, requestOptions) ;
      }
    }

    // const request: Request = new Request(requestOptions);

    // return this.http.request(request)
    //   .map((resp: Response) => resp.json())
    //   .catch((resp: Response) => this.onRequestError(resp));
  }

  /**
   * Centralized error handler.
   * @param {Response} resp
   * @returns {Observable<{errorCode:number, error: string}>}
   *
   * @author Stephan Petzchen
   */
  private onRequestError(err: any) {
    console.log(err);
    return Observable.throw(err);
  }
}
