// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {ISupplierDataApiService} from '../supplier-data.api.service.spi';
import {Inject, Injectable} from '@angular/core';
import {IBrand} from '../../model/brand.model';
import {IApiService} from '../api.service.spi';
import {Observable} from 'rxjs/Observable';

@Injectable()
export class SupplierDataApiService implements ISupplierDataApiService {
  constructor(@Inject('IApiService')private apiService: IApiService) {}

  getBrands(): Observable<any> {
    return this.apiService.get('supplier');
  }

  getBrandData(brand: string): Observable<any> {
    return this.apiService.get(`supplier/${brand}`);
  }

  insertBrandData(brand: IBrand) {
    this.apiService.post('supplier', brand);
  }

  updateBrandData(brand: IBrand) {
    this.apiService.post('supplier', brand);
  }

  deleteBrandData(brand: IBrand) {

  }


}
