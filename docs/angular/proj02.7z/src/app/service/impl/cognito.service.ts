// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Injectable} from '@angular/core';
import * as AWS from 'aws-sdk/global';
import {CognitoIdentityCredentials} from 'aws-sdk';
import * as awsservice from 'aws-sdk/lib/service';
import * as CognitoIdentity from 'aws-sdk/clients/cognitoidentity';
import {
  AuthenticationDetails,
  CognitoIdentityServiceProvider,
  CognitoUser,
  CognitoUserAttribute,
  CognitoUserPool
} from 'amazon-cognito-identity-js';

import {ICallback, ICognitoService} from '../cognito.service.spi';
import {environment} from '../../../environments/environment';
import {Observable} from 'rxjs/Observable';
import {Observer} from 'rxjs/Observer';



/**
 * Implementation of the ICognitoService interface.
 * @author Stephan Petzchen
 */
@Injectable()
export class CognitoService implements ICognitoService {
  public static POOL_DATA: any = {
    UserPoolId: environment.userPoolId,
    ClientId: environment.clientId
  };
  private cognitoCredentials: CognitoIdentityCredentials;


  /**
   * Get the relevant aws region information.
   * @returns {string}
   */
  getRegion(): string {
    return environment.region;
  }

  /**
   * Get the relevant aws identity pool id.
   * @returns {string}
   */
  getIdentityPoolId(): string {
    return environment.identityPoolId;
  }

  /**
   * Get the relevant aws user pool id.
   * @returns {string}
   */
  getUserPoolId(): string {
    return environment.userPoolId;
  }

  /**
   * Get the relevant aws client id.
   * @returns {string}
   */
  getClientId(): string {
    return environment.clientId;
  }

  /**
   * Get the pool data.
   * @returns {any}
   */
  getPoolData(): any {
    return CognitoService.POOL_DATA;
  }

  /**
   * Get the AWS Cognito credentials.
   * @returns {CognitoIdentityCredentials}
   */
  getCognitoIdentityCredentials(): CognitoIdentityCredentials {
    return this.cognitoCredentials;
  }

  /**
   * Set the AWS Cognito credentials.
   * @param {CognitoIdentityCredentials} creds
   */
  setCognitoIdentityCredentials(creds: AWS.CognitoIdentityCredentials) {
    this.cognitoCredentials = creds;
  }

  /**
   * Get the user pool.
   * @returns {"amazon-cognito-identity-js".CognitoUserPool}
   */
  getUserPool(): CognitoUserPool {
    if (environment.cognito_idp_endpoint) {
      CognitoService.POOL_DATA.endpoint = environment.cognito_idp_endpoint;
    }
    return new CognitoUserPool(this.getPoolData());
  }

  /**
   * Get current user.
   * @returns {"amazon-cognito-identity-js".CognitoUser}
   */
  getCurrentUser(): CognitoUser {
    return this.getUserPool().getCurrentUser();
  }

  /**
   * This method takes in a raw jwtToken and uses the global AWS config options to build a
   * CognitoIdentityCredentials object and store it for us. It also returns the object to the caller
   * to avoid unnecessary calls to setCognitoCreds.
   * @param {string} idTokenJwt
   * @returns {CognitoIdentityCredentials}
   */
  buildCognitoCreds(idTokenJwt: string) {
    let url = 'cognito-idp.' + this.getRegion().toLowerCase() + '.amazonaws.com/' + this.getUserPoolId();
    // let url = environment.tokenIssuerLoginUrl;

    if (environment.cognito_idp_endpoint) {
      url = environment.cognito_idp_endpoint + '/' + this.getUserPoolId();
    }
    const logins: CognitoIdentity.LoginsMap = {};
    logins[url] = idTokenJwt;
    const params = {
      IdentityPoolId: this.getIdentityPoolId(), /* required */
      Logins: logins
    };

    const serviceConfigs: awsservice.ServiceConfigurationOptions = {};
    if (environment.cognito_identity_endpoint) {
      serviceConfigs.endpoint = environment.cognito_identity_endpoint;
    }
    const creds = new AWS.CognitoIdentityCredentials(params, serviceConfigs);
    console.log('setCognitoIdentityCredentials.... ');
    console.log(creds);
    this.setCognitoIdentityCredentials(creds);
    return creds;
  }

  /**
   * Get identity id.
   * @returns {string}
   */
  getCognitoIdentity(): string {
    return this.getCognitoIdentityCredentials().identityId;
  }

  /**
   * Retrieves access token.
   * @returns {Observable<string>}
   */
  getAccessToken(): Observable<string> {
    return Observable.create((observer: Observer<string>) => {
      if (!this.getCurrentUser()) { return observer.next(null); }
      this.getCurrentUser()
        .getSession((err, session) => {
          if (err) { return Observable.throw('[!] error: ' + err); }
          if (session.isValid()) { return observer.next(session.getAccessToken().getJwtToken()); }
      });
    });
  }

  /**
   * Retrieves id token.
   * @returns {Observable<string>}
   */
  getIdToken(): Observable<string> {
    return Observable.create((observer: Observer<string>) => {
      if (!this.getCurrentUser()) { return observer.next(null); }
      this.getCurrentUser()
        .getSession((err, session) => {
          if (err) { return Observable.throw('[!] error: ' + err); }
          if (session.isValid()) { return observer.next(session.getIdToken().getJwtToken()); }
        });
    });
  }

  /**
   * Retrieves refresh token.
   * @returns {Observable<string>}
   */
  getRefreshToken(): Observable<string> {
    return Observable.create((observer: Observer<string>) => {
      if (!this.getCurrentUser()) { return observer.next(null); }
      this.getCurrentUser()
        .getSession((err, session) => {
          if (err) { return Observable.throw('[!] error: ' + err); }
          if (session.isValid()) { return observer.next(session.getRefreshToken().getJwtToken()); }
        });
    });
  }

  /**
   * Tests for authenticated user.
   * @returns {Observable<boolean>}
   */
  isAuthenticated(): Observable<boolean> {
    return Observable.create((observer: Observer<boolean>) => {
      if (!this.getCurrentUser()) { return observer.next(false); }
      this.getCurrentUser()
        .getSession((err, session) => {
          if (err) { return Observable.throw('[!] error: ' + err); } else {return observer.next(session.isValid()); }
        });
    });
  }

  /**
   * Refresh the session.
   */
  refresh(): void {
    this.getCurrentUser().getSession(function (err, session) {
      if (err) {
        console.log('CognitoService: Can\'t set the credentials:' + err);
      } else {
        if (session.isValid()) {
          console.log('CognitoService: refreshed successfully');
        } else {
          console.log('CognitoService: refreshed but session is still not valid');
        }
      }
    });
  }
}
