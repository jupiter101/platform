// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Inject, Injectable} from '@angular/core';
import * as AWS from 'aws-sdk/global';
import {ICallback, ICognitoService} from '../cognito.service.spi';
import {environment} from '../../../environments/environment';
import {IAwsService} from '../aws.service.spi';

/**
 *
 * @author Stephan Petzchen
 *
 * @experimental
 */
@Injectable()
export class AwsService implements IAwsService {
  private static _isFirstLogin: boolean = false;
  private static _isRunningInit: boolean = false;

  static getCognitoParametersForIdConsolidation(idTokenJwt: string): {} {
    console.log('AwsService: enter getCognitoParametersForIdConsolidation()');
    const url = 'cognito-idp.' + environment.region.toLowerCase() + '.amazonaws.com/' + environment.userPoolId;
    const logins: Array<string> = [];
    logins[url] = idTokenJwt;
    const params = {
      IdentityPoolId: environment.identityPoolId, /* required */
      Logins: logins
    };

    return params;
  }

  constructor(@Inject('ICognitoService') private cognitoService: ICognitoService) {
    AWS.config.region = environment.region;
  }

  initAwsService(callback: ICallback, isLoggedIn: boolean, idToken: string) {

    if (AwsService._isRunningInit) {
      // Need to make sure I don't get into an infinite loop here, so need to exit if this method is running already
      console.log('AwsService: Aborting running initAwsService()...it\'s running already.');
      // instead of aborting here, it's best to put a timer
      if (callback != null) {
        callback.callback();
        callback.callbackWithParam(null);
      }
      return;
    }

    console.log('AwsService: Running initAwsService()');
    AwsService._isRunningInit = true;

    const self = this;
    // First check if the user is authenticated already
    if (isLoggedIn) {
      self.setupAWS(isLoggedIn, callback, idToken);
    }


  }

  /**
   * Sets up the AWS global params
   *
   * @param isLoggedIn
   * @param callback
   */
  setupAWS(isLoggedIn: boolean, callback: ICallback, idToken: string): void {
    console.log('AwsService: in setupAWS()');
    if (isLoggedIn) {
      console.log('AwsService: User is logged in');
      // Setup mobile analytics
      const options = {
        appId: '32673c035a0b40e99d6e1f327be0cb60',
        appTitle: 'aws-cognito-angular2-quickstart'
      };

      // TODO: The mobile Analytics client needs some work to handle Typescript. Disabling for the time being.
      // var mobileAnalyticsClient = new AMA.Manager(options);
      // mobileAnalyticsClient.submitEvents();

      this.addCognitoCredentials(idToken);

      console.log('AwsService: Retrieving the id token');

    } else {
      console.log('AwsService: User is not logged in');
    }

    if (callback != null) {
      callback.callback();
      callback.callbackWithParam(null);
    }

    AwsService._isRunningInit = false;
  }

  addCognitoCredentials(idTokenJwt: string): void {
    const creds = this.cognitoService.buildCognitoCreds(idTokenJwt);

    AWS.config.credentials = creds;

    creds.get(function (err) {
      if (!err) {
        if (AwsService._isFirstLogin) {
          // save the login info to DDB
          this.ddb.writeLogEntry('login');
          AwsService._isFirstLogin = false;
        }
      }
    });
  }


}
