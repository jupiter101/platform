// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {ICallback} from './cognito.service.spi';

/**
 *
 * @author Stephan Petzchen
 * @experimental
 */
export interface IAwsService {
  initAwsService(callback: ICallback, isLoggedIn: boolean, idToken: string);
}
