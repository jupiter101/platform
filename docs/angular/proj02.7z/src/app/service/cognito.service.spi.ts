// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Injectable} from '@angular/core';
import {CognitoIdentityCredentials} from 'aws-sdk';
import {
  AuthenticationDetails,
  CognitoIdentityServiceProvider,
  CognitoUser,
  CognitoUserAttribute,
  CognitoUserPool
} from 'amazon-cognito-identity-js';
import {Observable} from 'rxjs/Observable';

/**
 *
 */
export interface ICognitoCallback {
  cognitoCallback(message: string, result: any): void;
}

/**
 * Logged in callback interface
 * @author Stephan Petzchen
 * TODO: switch to observable approach (despite the fact aws sdk uses callbacks)
 */
export interface ILoggedInCallback {
  isLoggedIn(message: string, loggedIn: boolean): void;
}

/**
 * Generic callback interface
 * @author Stephan Petzchen
 * TODO: switch to observable approach (despite the fact aws sdk uses callbacks)
 */
export interface ICallback {
  callback(): void;
  callbackWithParam(result: any): void;
}

/**
 * AWS Cognito service interface.
 * @author Stephan Petzchen
 */
export interface ICognitoService {
  getRegion(): string;
  getIdentityPoolId(): string;
  getUserPoolId(): string;
  getClientId(): string;
  getPoolData(): any;
  getCognitoIdentityCredentials(): CognitoIdentityCredentials;
  getUserPool(): CognitoUserPool;
  getCurrentUser(): CognitoUser;
  buildCognitoCreds(idTokenJwt: string);
  getCognitoIdentity(): string;
  getAccessToken(): Observable<string>;
  getIdToken(): Observable<string>;
  getRefreshToken(): Observable<string>;
  isAuthenticated(): Observable<boolean>;
  refresh(): void;

}
