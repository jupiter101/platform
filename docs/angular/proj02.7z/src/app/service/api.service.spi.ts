// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * API service interface for retrieving data from the server.
 *
 *
 * @author Stephan Petzchen
 */
export interface IApiService {
  get(url: string);
  post(url: string, body: Object );
  put(url: string, body: Object);
  delete(url: string);
}
