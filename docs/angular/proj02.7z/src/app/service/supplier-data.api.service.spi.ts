// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {IBrand} from '../model/brand.model';
import {Observable} from 'rxjs/Observable';

/**
 * Supplier data API service interface.
 *
 *
 * @author Stephan Petzchen
 */
export interface ISupplierDataApiService {
  getBrands(): Observable<any>;
  getBrandData(brand: string ): Observable<any>;
  insertBrandData(brand: IBrand);
  updateBrandData(brand: IBrand);
  deleteBrandData(brand: IBrand);
}
