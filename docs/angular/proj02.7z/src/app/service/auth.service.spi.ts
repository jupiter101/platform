// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {EventEmitter} from '@angular/core';
import {ICognitoCallback, ILoggedInCallback} from './cognito.service.spi';
import {Observable} from 'rxjs/Observable';

export interface IAuthServiceEventParameter {
  message: string;
  data: any;
}

export interface IAuthService {
  AuthenticationNewPasswordRequiredEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationNewPasswordChallengeEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationFailedEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationSuccessEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationIsAuthenticatedEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationLoggedOutEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationForgotPasswordEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationConfirmNewPasswordEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationInputValidationCodeEvent: EventEmitter<IAuthServiceEventParameter>;
  AuthenticationResendConfirmationCodeEvent: EventEmitter<IAuthServiceEventParameter>;
  authenticate(username: string, password: string): void;
  isAuthenticated(): Observable<boolean>;
  logout(): void;
  newPasswordChallenge(username: string, temporaryPassword: string, password: string): void;
  forgotPassword(username: string);
  confirmNewPassword(email: string, verificationCode: string, password: string);
  resendConfirmationCode(username: string);
  getAccessToken(): Observable<string>;
  getIdToken(): Observable<string>;
  getRefreshToken(): Observable<string>;
}
