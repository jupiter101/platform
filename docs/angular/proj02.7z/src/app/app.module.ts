import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './component/navbar/navbar.component';
import { LoginComponent } from './component/login/login.component';
import { NewPasswordComponent } from './component/new-password/new-password.component';
import { SupplierComponent } from './component/supplier/supplier.component';
import { ApiService } from './service/impl/api.service';
import { AuthGuard } from './auth.guard';
import { AuthService } from './service/impl/auth.service';
import { FormsModule } from '@angular/forms';
import { CognitoService } from './service/impl/cognito.service';
import { AwsService } from './service/impl/aws.service';
import { ResetPasswordComponent } from './component/reset-password/reset-password.component';
import {SupplierDataApiService} from './service/impl/supplier-data.api.service';
import {HttpClient, HttpClientModule} from '@angular/common/http';
import { EditSupplierDataComponent } from './component/edit-supplier-data/edit-supplier-data.component';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';

// AoT requires an exported function for factories
export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}

@NgModule({
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    NewPasswordComponent,
    SupplierComponent,
    ResetPasswordComponent,
    EditSupplierDataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  providers: [
    { provide: 'IApiService', useClass: ApiService },
    { provide: 'IAuthService', useClass: AuthService },
    { provide: 'ISupplierDataApiService', useClass: SupplierDataApiService },
    { provide: 'ICognitoService', useClass: CognitoService },
    { provide: 'IAwsService', useClass: AwsService },
    AuthGuard
  ],  bootstrap: [AppComponent]
})
export class AppModule { }
