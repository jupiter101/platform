import { TestBed, async, inject } from '@angular/core/testing';

import { AuthGuard } from './auth.guard';
import {AuthService} from './service/impl/auth.service';
import {RouterTestingModule} from '@angular/router/testing';
import {CognitoService} from './service/impl/cognito.service';

describe('AuthGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AuthGuard,
        { provide: 'IAuthService', useClass: AuthService },
        { provide: 'ICognitoService', useClass: CognitoService }
        ]
    });
  });

  it('should ...', inject([AuthGuard], (guard: AuthGuard) => {
    expect(guard).toBeTruthy();
  }));
});
