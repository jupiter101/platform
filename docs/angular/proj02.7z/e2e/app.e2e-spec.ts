import { AppPage } from './app.po';

describe('carnavigation App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display empty title', () => {
    page.navigateTo();

    expect(page.getParagraphText()).toEqual('');
  });
});
