// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import * as Annotations from './annotations/index';
import * as TS from './lang';

const obj = {
  [Symbol('my_key')]: 1,
  enum: 2,
  nonEnum: 3
};
Object.defineProperty(obj, 'nonEnum', { enumerable: false });

class TestDomainBase {

  @Annotations.NotNull()
  @Annotations.Min(0)
  @Annotations.Max(10)
  private propertyBase1: number;

  @Annotations.NotNull()
  @Annotations.Length(0, 10)
  private propertyBase2: number;

  @Annotations.NotNull()
  @Annotations.Digits(3, 4)
  private static propertyBase3: number;
}

class TestDomain extends TestDomainBase {
  @Annotations.NotBlank()
  property1: string;
  @Annotations.NotNull()
  property2: number;
  test (): void {}
}

Object.defineProperty(TestDomain, 'nonEnum', { enumerable: false });

{
  const ar: number[] = [1, 2, 3];
  const jane = { first: 'Jane', last: 'Doe' };

  for (const [key, value] of TS.Objects.entries(TestDomain)) {
    console.log(`${key}: ${value}`);
  }

  console.log(TS.Objects.keys(TestDomain));
}




