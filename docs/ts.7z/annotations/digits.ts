// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';
import DigitsValidator = TS.Validators.DigitsValidator;
/**
 * Digits annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Digits(3, 5)
 *  myprop: []
 * }
 * ```
 * TODO Locale specific group and decimal separator injection
 */
export const Digits = (fraction: number, integer: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'digits', v: DigitsValidator(integer, fraction) },
    });
  };
};
