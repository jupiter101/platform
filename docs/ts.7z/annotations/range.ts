// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Range annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Range(0, 10)
 *  myprop: number
 * }
 * ```
 *
 */
export const Range = (min: number, max: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'range', v: TS.Validators.RangeValidator(min, max) },
    });
  };
};
