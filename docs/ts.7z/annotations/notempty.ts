// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * NotEmpty annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @NotEmpty
 *  myprop: Array
 * }
 * ```
 *
 */
export const NotEmpty = (): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'tide-notempty', v: TS.Validators.NotEmptyValidator },
    });
  };
};
