// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Empty annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Empty
 *  myprop: string
 * }
 * ```
 *
 */
export const Empty = (): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'empty', v: TS.Validators.EmptyValidator },
    });
  };
};
