// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * NotBlank annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @NotBlank
 *  myprop: string
 * }
 * ```
 *
 */
export const NotBlank = (): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'notblank', v: TS.Validators.NotBlankValidator },
    });
  };
};
