// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Length annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Length(10, 255)
 *  myprop: string
 * }
 * ```
 *
 */
export const Length = (min: number, max: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'length', v: TS.Validators.LengthValidator(min, max) },
    });
  };
};
