// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import * as TS from './lang';

class TestDomainBase {

  private propertyBase1: number = 10;
  private propertyBase2: number = 20;
  private static propertyBase3: number = 30;
  test(): void {}
}

class TestDomain extends TestDomainBase {

  private propertyBase4: number = 10;
  private propertyBase5: number = 20;
  private static propertyBase6: number = 30;
  test2(): void {}
}

{
  TS.Meta.defineMetadata('metaKey1', 'metadata1', TestDomainBase, 'propertyBase1');
  TS.Meta.defineMetadata('metaKey1', 'metadata1', TestDomainBase, 'propertyBase2');
  TS.Meta.defineMetadata('metaKey2', 'metadata1', TestDomainBase, 'propertyBase1');
  TS.Meta.defineMetadata('metaKey2', 'metadata1', TestDomainBase, 'propertyBase2');

  console.log(`hasMetadata: ${TS.Meta.hasMetadata('metaKey1', TestDomainBase, 'propertyBase1')}`);
  console.log(`getMetadata: ${TS.Meta.getMetadata('metaKey1', TestDomainBase, 'propertyBase1')}`);

  console.log(`getMetadataKeys(propertyBase1): ${TS.Meta.getMetadataKeys(TestDomainBase, 'propertyBase1')}`);



  console.log('########');
  console.log(TS.Objects.keys(TestDomainBase));
  console.log('----');
  console.log(TS.Objects.keys(new TestDomainBase()));

  console.log('########');

  console.log('########');
  console.log(TS.Objects.keys(TestDomain));
  console.log('----');
  console.log(TS.Objects.keys(new TestDomain()));

  console.log('########');

  console.log(`deleteMetadata: ${TS.Meta.deleteMetadata('metaKey1', TestDomainBase, 'propertyBase1')}`);
  console.log(`hasMetadata: ${TS.Meta.hasMetadata('metaKey1', TestDomainBase, 'propertyBase1')}`);

  for (const k in TestDomain){
    console.log(k);
  }

}
