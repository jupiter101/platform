// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import * as TS from './lang';
import {Observable} from 'rxjs/Rx';
// import Numbers = TS.Numbers;

{
  console.log('toNum(120): ' + TS.Numbers.toNum('120'));
  console.log('isNaN(NaN): ' + TS.Numbers.isNaN(NaN));
  console.log('isNum(A120): ' + TS.Numbers.isNum('A120'));
  console.log('isNum(120): ' + TS.Numbers.isNum('120'));
  console.log('toArray(120): ' + TS.Strings.toArray('I am one who loved not wisely but too well'));
  console.log('removeSuffix(\'bababbla\', \'bla\'): ' + TS.Strings.removeSuffix('bababbla', 'bla'));

  console.log('isArray([\'a\', , \'c\']): ' + TS.Arrays.isArray(['a', , 'c']));
  console.log('create(10, (x, i) => i * 2)): ' + TS.Arrays.create(10, (x, i) => i * 2));
  console.log('removeHoles([\'a\', , \'c\']): ' + TS.Arrays.removeHoles(['a', , 'c']));
  console.log('removeHoles([1, NaN, 2, undefined]): ' + TS.Arrays.removeHoles([1, NaN, 2, undefined], (v) => (!isNaN(v - parseFloat(v))) && true ));
  console.log('flatten([[1, 2], [3, 4], [5, 6]]): ' + TS.Arrays.flatten([[1, 2], [3, 4], [5, 6]]));


  // console.log(...map);
  // let map = [[ 1, 'one' ], [ 2, 'two' ], [ 3, 'three' ]];
  // console.log(new Map([...map]));
  // console.log('map(120): ' + TS.Maps.map(new Map([[ 1, 'one' ], [ 2, 'two' ], [ 3, 'three' ]]), ([k, v]) => [k * 2, '_' + v]));
  // console.log('fromIterable(120): ' + TS.Maps.fromIterable<number, string>([[0, 'a'], [1, 'b']]));

  console.log('isPromise(new Promise(console.log)): ' + TS.Promises.isPromise(new Promise(console.log)));

  console.log('isObservable(Observable.from(\'Hello World\'): ' + TS.Observables.isObservable(Observable.from('Hello World')));


  // ##########
  // Dates
  // ##########
  const refDate01 = new Date(2017, 11, 12);
  const refDate02 = new Date();

  // clone
  const clonedDate: Date = TS.Dates.clone(refDate01);
  console.log(` ref: year: ${refDate01.getFullYear()} month: ${refDate01.getMonth()} day: ${refDate01.getDate()}`);
  console.log(` cloned: year: ${clonedDate.getFullYear()} month: ${clonedDate.getMonth()} day: ${clonedDate.getDate()}`);

  // zeroTime
  const zeroTimeDate = new Date();
  const zeroTimeDateNew = TS.Dates.clone(zeroTimeDate);
  TS.Dates.zeroTime(zeroTimeDateNew);
  console.log(`zeroTime(): ref: ${zeroTimeDate} zeroTime: ${zeroTimeDateNew}`);

  // compare
  const compDate01 = new Date(2017, 11, 11);
  const compDate02 = new Date(2017, 11, 13);
  const compDate03 = new Date(2017, 11, 12);

  console.log('toNum(\"2017, 11, 12\", \"2017, 11, 11\"): ' + TS.Dates.compare(refDate01, compDate01));
  console.log('toNum(\"2017, 11, 12\", \"2017, 11, 13\"): ' + TS.Dates.compare(refDate01, compDate02));
  console.log('toNum(\"2017, 11, 12\", \"2017, 11, 12\"): ' + TS.Dates.compare(refDate01, compDate03));

  // isValidDayOfMonth
  const isValidDayOfMonth1: number[] = [2017, 1, 29];
  const isValidDayOfMonth2: number[] = [2020, 1, 29];
  const isValidDayOfMonth3: number[] = [2016, 1, 29];

  const isValidDayOfMonth4: number[] = [2017, 0, 31];
  const isValidDayOfMonth5: number[] = [2017, 0, 30];
  const isValidDayOfMonth6: number[] = [2020, 10, 31];
  const isValidDayOfMonth7: number[] = [2016, 10, 30];

  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth1} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth1[0], isValidDayOfMonth1[1], isValidDayOfMonth1[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth2} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth2[0], isValidDayOfMonth2[1], isValidDayOfMonth2[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth3} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth3[0], isValidDayOfMonth3[1], isValidDayOfMonth3[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth4} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth4[0], isValidDayOfMonth4[1], isValidDayOfMonth4[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth5} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth5[0], isValidDayOfMonth5[1], isValidDayOfMonth5[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth6} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth6[0], isValidDayOfMonth6[1], isValidDayOfMonth6[2])}`);
  console.log(`isValidDayOfMonth(): ref: ${isValidDayOfMonth7} isValidDayOfMonth: ${TS.Dates.isValidDayOfMonth(isValidDayOfMonth7[0], isValidDayOfMonth7[1], isValidDayOfMonth7[2])}`);

  // isToday, isCurrentMonth, isCurrentYear
  const isTodayDate = new Date();
  const isTodayDate2 = new Date(2017, 10, 13);
  const isTodayDate3 = new Date(2017, 9, 11);
  const isTodayDate4 = new Date(2016, 9, 11);
  console.log(`isToday(): ref: ${isTodayDate.toISOString()} isToday: ${TS.Dates.isToday(isTodayDate)} isCurrentMonth: ${TS.Dates.isCurrentMonth(isTodayDate)} isCurrentYear: ${TS.Dates.isCurrentYear(isTodayDate)}`);
  console.log(`isToday(): ref: ${isTodayDate2.toISOString()} isToday: ${TS.Dates.isToday(isTodayDate2)} isCurrentMonth: ${TS.Dates.isCurrentMonth(isTodayDate2)} isCurrentYear: ${TS.Dates.isCurrentYear(isTodayDate2)}`);
  console.log(`isToday(): ref: ${isTodayDate3.toISOString()} isToday: ${TS.Dates.isToday(isTodayDate3)} isCurrentMonth: ${TS.Dates.isCurrentMonth(isTodayDate3)} isCurrentYear: ${TS.Dates.isCurrentYear(isTodayDate3)}`);
  console.log(`isToday(): ref: ${isTodayDate4.toISOString()} isToday: ${TS.Dates.isToday(isTodayDate4)} isCurrentMonth: ${TS.Dates.isCurrentMonth(isTodayDate4)} isCurrentYear: ${TS.Dates.isCurrentYear(isTodayDate4)}`);

  // isLeapYear, lastLeapYear, nextLeapYear
  let yearLeapYear: number = 2020;
  while (yearLeapYear > 2011) {
    console.log(`isLeapYear(): ref: ${yearLeapYear} isLeapYear: ${TS.Dates.isLeapYear(yearLeapYear)} nextLeapYear: ${TS.Dates.nextLeapYear(yearLeapYear)} lastLeapYear: ${TS.Dates.lastLeapYear(yearLeapYear)}`);
    yearLeapYear -= 1;
  }

  const currMonth = new Date().getMonth();
  const amount = -12;
  const date = new Date(2017, currMonth + amount, 11); // 31.10.17  - 1 Month => 30.9.17
  // date.setMonth(8);
  console.log(date.toISOString());

  // offsetPreviousYear
  let offsetPreviousYearDate = TS.Dates.offsetYear(2017, 1, 29, TS.Dates.DateOffsetDirection.PAST);
  console.log(`offsetPreviousYear: ref: ${offsetPreviousYearDate.toDateString()}`);
  console.log(`offsetPreviousYear: year: ${offsetPreviousYearDate.getFullYear()} month: ${offsetPreviousYearDate.getMonth()} day: ${offsetPreviousYearDate.getDate()}`);

  // offsetNextYear
  let offsetNextYearDate = TS.Dates.offsetYear(2017, 1, 29, TS.Dates.DateOffsetDirection.FUTURE);
  console.log(`offsetNextYear: ref: ${offsetNextYearDate.toDateString()}`);
  console.log(`offsetNextYear: year: ${offsetNextYearDate.getFullYear()} month: ${offsetNextYearDate.getMonth()} day: ${offsetNextYearDate.getDate()}`);


  // offsetPreviousMonth
  let offsetPreviousMonthDate = TS.Dates.offsetMonth(2017, 2, 29, TS.Dates.DateOffsetDirection.PAST);
  console.log(`offsetPreviousMonth: ref: ${offsetPreviousMonthDate.toDateString()}`);
  console.log(`offsetPreviousMonth: year: ${offsetPreviousMonthDate.getFullYear()} month: ${offsetPreviousMonthDate.getMonth()} day: ${offsetPreviousMonthDate.getDate()}`);

  // offsetNextMonth
  let offsetNextMonthDate = TS.Dates.offsetMonth(2017, 1, 31, TS.Dates.DateOffsetDirection.FUTURE);
  console.log(`offsetNextMonth: ref: ${offsetNextMonthDate.toDateString()}`);
  console.log(`offsetNextMonth: year: ${offsetNextMonthDate.getFullYear()} month: ${offsetNextMonthDate.getMonth()} day: ${offsetNextMonthDate.getDate()}`);

  // offsetCurrentMonth
  let offsetCMonthDate = TS.Dates.offsetMonth(2017, 2, 31, TS.Dates.DateOffsetDirection.CURRENT);
  console.log(`offsetCurrentMonth: ref: ${offsetCMonthDate.toDateString()}`);
  console.log(`offsetCurrentMonth: year: ${offsetCMonthDate.getFullYear()} month: ${offsetCMonthDate.getMonth()} day: ${offsetCMonthDate.getDate()}`);

  // initDefaultCentury parseAmbiguousDatesAsAfter
  console.log(`####### initDefaultCentury.`);
  console.log(TS.Dates.initDefaultCentury());
  console.log(`####### initDefaultCentury.`);

  let defCentury: TS.Dates.DefaultCentury = TS.Dates.initDefaultCentury();
  let orgVal: number = 1;
  let value: number = orgVal;
  let tmp = Math.trunc((defCentury.year / 100)) * 100; // + ( value < defCentury.twodigityear ? 100 : 0);
  value += Math.trunc((defCentury.year / 100)) * 100 + ( value < defCentury.twodigityear ? 100 : 0);
  console.log(`(defCentury.year / 100): ${Math.trunc((defCentury.year / 100))}`);
  console.log(`(defCentury.year / 100)*100: ${Math.trunc((defCentury.year / 100)) * 100}`);

  console.log(`( value < defCentury.twodigityear ? 100 : 0): ${( orgVal < defCentury.twodigityear ? 100 : 0)}`);
  console.log(`value org: ${orgVal} final: ${value} tmp: ${tmp}`);


}

