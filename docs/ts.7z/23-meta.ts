// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import * as TS from './lang';

import list = TS.Arrays.list;
import zip = TS.Iterables.zip;
import range = TS.Iterables.range;

function* infiniteSequence() {
  let i = 0;
  while (i < 100) {
    yield i++;
  }
}

function* _range ( start: number , stop: number = 1 , step: number = 1 ) {
  console.log(`${start}:${stop}:${step}`);
  if ( step < 0 ) {
    console.log(`${start}:${stop}:${step}`);
    for ( ; start > stop ; start += step ) yield start ;
  }
  else {
    while (start < stop) {
      yield start ;
      start += step;
    }
  }
}

{
  let t1 = TS.Meta.stopWatch(TS.Meta.add,     10000000);  // => 0.698 seconds
  let t2 = TS.Meta.stopWatch(TS.Meta.addN(5), 10000000);  // => 0.152 seconds

  console.log(`t1: ${t1} t2: ${t2}`);

  console.log([1, '', 'foo', 0, null].filter(Boolean));
  console.log([1, '', 'foo', 0, null].filter(Boolean && String));
  console.log([1, NaN, 2, 0, 1].filter(TS.Numbers.isNum));

  console.log(list( zip( range(1, 5) , range(10, 15) ) ));
  console.log([...zip( range(1, 5) , range(10, 15) ) ]);

  console.log(range(10, 100).next());

  let s = 'ABCDEFGHIJ';
  console.log([...s]);

  let m = new Map().set(0, 'test1').set(1, 'test2');
  console.log([...m]);
  // for (let n of _range(1, 50, 1)) console.log(n);

}
