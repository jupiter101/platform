// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Support} from './support';
import {Buffers} from './buffers';

export namespace Randoms {
  declare const crypto: Crypto;
  declare const msCrypto: Crypto;

  /**
   * Fills a buffer with a defined number of random values.
   * @param {number} size
   * @returns {Buffers.Buffer}
   */
  export function generateRandomBytes(size: number): Buffers.Buffer {
    if (Support.Iterables.Uint8Arrays) {
      if (Support.Cryptos.Standard) return crypto.getRandomValues(new Uint8Array(size)) as Uint8Array;
      if (Support.Cryptos.Microsoft) return msCrypto.getRandomValues(new Uint8Array(size)) as Uint8Array;
      return fillRandomBytes(new Uint8Array(size), size);
    }
    return fillRandomBytes(new Array(size), size);
  }

  /**
   * Fills random bytes into a buffer like structure.
   * @param {Buffers.Buffer} buffer
   * @param {number} size
   * @returns {Buffers.Buffer}
   */
  function fillRandomBytes(buffer: Buffers.Buffer, size: number): Buffers.Buffer {
    for (let i = 0; i < size; ++i) buffer[i] = Math.random() * 0xff | 0;
    return buffer;
  }
}
