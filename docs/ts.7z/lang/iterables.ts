// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import {Iterators} from './iterators';

/**
 * Helper for Iterable types
 * Hint: set compiler option "downlevelIteration": true for ES5 target and below
 * @see https://blog.mariusschulz.com/2017/06/30/typescript-2-3-downlevel-iteration-for-es3-es5
 * @see https://github.com/Microsoft/TypeScript/issues/6842
 *
 * @experimental WIP
 */
export namespace Iterables {
  import Iterator = Iterators.Iterator;

  export namespace base {
    export const list = ( iterable: any ) => Array.from( iterable );
  }

  /**
   * The Iterable interface includes the property '@@iterator'
   * @see http://www.ecma-international.org/ecma-262/6.0/#sec-iterable-interface
   */
  export interface Iterable<T> {
    '@@iterator'(): Iterator<T>;
  }

  /**
   * Iterable iterator interface includes the property '@@iterator'
   */
  export interface IterableIterator<T> extends Iterator<T> {
    '@@iterator'(): IterableIterator<T>;
  }



  /**
   * Returns the iterator for the input iterable.
   *
   * @param {Iterable} iterable - The input iterable.
   * @returns {Iterator} IterableIterator<any>
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  const iter = ( iterable: any ) => iterable[Symbol.iterator]( );

  /**
   * Returns the next event of the input iterator.
   *
   * @param {Iterator} iterator - The input iterator.
   * @returns {{done: Boolean, value: Object}}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  const _next = ( iterator: any ) => iterator.next( );

  /**
   * Yields values in a range, separated by a fixed constant called step. If
   * this step is negative, the range has to be given in reverse order, that is,
   * largest value first, smallest value second.
   *
   * @param {Number} start - The starting value.
   * @param {Number} stop - The stopping value.
   * @param {Number} step - The step value.
   * @returns {Iterator}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  function* _range ( start: number , stop: number , step: number ) {
    if ( step < 0 ) {
      for ( ; start > stop ; start += step ) yield start ;
    }
    else {
      for ( ; start < stop ; start += step ) yield start ;
    }
  }

  /**
   * Yields values in a range, separated by a fixed constant called step. If this
   * step is negative, the range has to be given in reverse order, that is,
   * largest value first, smallest value second. Both the starting value and the
   * step value are optional. By default the starting value is <code>0</code>.
   * The default for the step value is <code>1</code>.
   *
   * @param {Number} [start=0] - The starting value.
   * @param {Number} stop - The stopping value.
   * @param {Number} [step=1] - The step value.
   * @returns {Iterator}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  export const range = ( start: number , stop: number = 1 , step: number = 1 ) => _range( start , stop , step ) ;

  /**
   * Applies a given callable to each of the elements of the input iterable.
   *
   * @example
   * // return [ 0 , 1 , 4 , 9 ]
   * list( map( x => x**2 , range( 4 ) ) ) ;
   *
   * @param {Function} callable - The callable to use.
   * @param {Iterable} iterable - The input iterable.
   * @returns {Iterator}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  export function* map ( callable: any , iterable: any ) {
    for ( let item of iterable ) yield callable( item ) ;
  }

  // TS doesn't support iterating IterableIterator with ES5 target, only strings and arrays.
  // Error: Type 'IterableIterator<any>' is not an array type or a string type
  // Solution: transpiling TS to ES6 (Target: ES6) and then ES6 to ES5

  /**
   * Zips iterables together. Yields a tuple containing the first element of each
   * iterable, then a tupe containing the second element of each iterable, etc.
   * Stops when one of the iterables runs out of elements.
   *
   * @example
   * // returns [ [ 'a' , 1 ] , [ 'b' , 2 ] , [ 'c' , 3 ] ]
   * list( _zip( [ 'abcd' , range(3) ] ) ) ;
   *
   * @param {Iterable[]} iterables - The iterables to zip.
   * @returns {Iterator}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   *
   */
  function* _zip (iterables: any ) {
    let iterators = base.list( map( iter , iterables ) ) ;
    if ( iterators.length === 0 ) return ;
    while ( true ) {
      let buffer = [ ] ;
      for ( let result of map( _next , iterators ) ) {
        if ( result.done ) return;
        buffer.push( result.value ) ;
      }
      yield buffer ;
    }
  }

  /**
   * Zips iterables together. Yields a tuple containing the first element of each
   * iterable, then a tupe containing the second element of each iterable, etc.
   * Stops when one of the iterables runs out of elements.
   *
   * @example
   * // returns [ [ 'a' , 1 ] , [ 'b' , 2 ] , [ 'c' , 3 ] ]
   * list( zip( 'abcd' , range(3) ) ) ;
   *
   * @param {...Iterable} iterables - The iterables to zip.
   * @returns {Iterator}
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   *
   */
  export const zip = ( ...iterables: Iterator<any>[] ) => _zip( iterables ) ;


  /**
   * Provides the length for iterable o
   * @param iterable
   * @returns
   */
  export const length = ( iterable: any ): number => {
    return iterable instanceof Set || iterable instanceof Map ? iterable.size : iterable.length ? iterable.length : 0;
  };


}


