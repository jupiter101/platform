// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Types} from './types';
import {Iterables} from './iterables';

export namespace Iterators {
  import Iterable = Iterables.Iterable;

  /**
   * The IteratorResult interface includes the properties 'value' and 'done'.
   * @see http://www.ecma-international.org/ecma-262/6.0/#sec-iteratorresult-interface
   */
  export type IteratorResult<T> = { value: T, done: false } | { value: never, done: true };

  /**
   * An object that implements the Iterator interface must include the properties 'next', 'return' and 'throw'
   * @see http://www.ecma-international.org/ecma-262/6.0/#sec-iterator-interface
   */
  export interface Iterator<T> {
    next(value?: any): IteratorResult<T>;
    throw?(value: any): IteratorResult<T>;
    return?(value?: T): IteratorResult<T>;
  }

  export function GetIterator<T>(obj: Iterable<T>): Iterator<T> {
    const method = Types.getMethod(obj, Types.IteratorSymbol);
    if (!Types.Comparer.isCallable(method)) throw new TypeError(); // from Call
    const iterator = method.call(obj);
    if (!Types.isObject(iterator)) throw new TypeError();
    return iterator;
  }

  // 7.4.4 IteratorValue(iterResult)
  // https://tc39.github.io/ecma262/2016/#sec-iteratorvalue
  export function IteratorValue<T>(iterResult: IteratorResult<T>): T {
    return iterResult.value;
  }

  // 7.4.5 IteratorStep(iterator)
  // https://tc39.github.io/ecma262/#sec-iteratorstep
  export function IteratorStep<T>(iterator: Iterator<T>): IteratorResult<T> | false {
    const result = iterator.next();
    return result.done ? false : result;
  }

  // 7.4.6 IteratorClose(iterator, completion)
  // https://tc39.github.io/ecma262/#sec-iteratorclose
  export function IteratorClose<T>(iterator: Iterator<T>) {
    const f = iterator['return'];
    if (f) f.call(iterator);
  }
}
