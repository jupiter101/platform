// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

/**
 * Helper for any values.
 *
 * TODO remove redundancy in Validation module.
 */
export namespace Values {
  export const isEmpty = (value: any): boolean => value == null || typeof value === 'string' ? value.trim().length === 0 : value.length === 0;
  export const isBlank = (value: any): boolean => value == null || value.length === 0;
  export const isNull = (value: any): boolean => value == null;
}
