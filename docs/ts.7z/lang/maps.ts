// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Support} from './support';
import {Types} from './types';
import {Objects} from './objects';
import {Iterables} from './iterables';
import {Iterators} from './iterators';
import {UUIDS} from './uuids';

/**
 * Helper for Map objects
 */
export namespace Maps {
  import IteratorResult = Iterators.IteratorResult;
  import Iterable = Iterables.Iterable;
  import IterableIterator = Iterables.IterableIterator;

  /**
   * Hashmap interface for objects in dictionary mode (a.k.a. "slow" mode in v8)
   */
  type HashMap<V> = Record<string, V>;

  /**
   * Map interface.
   *
   */
  export interface Map<K, V> extends Iterable<[K, V]> {
    size: number;
    has(key: K): boolean;
    get(key: K): V;
    set(key: K, value?: V): this;
    delete(key: K): boolean;
    clear(): void;
    keys(): IterableIterator<K>;
    values(): IterableIterator<V>;
    entries(): IterableIterator<[K, V]>;
  }

  /**
   * MapConstructor interface.
   */
  export interface MapConstructor {
    new (): Map<any, any>;
    new <K, V>(): Map<K, V>;
    prototype: Map<any, any>;
  }

  /**
   * WeakMap interface.
   */
  interface WeakMap<K, V> {
    clear(): void;
    delete(key: K): boolean;
    get(key: K): V;
    has(key: K): boolean;
    set(key: K, value?: V): WeakMap<K, V>;
  }

  /**
   * WeakMapConstructor interface.
   */
  interface WeakMapConstructor {
    new (): WeakMap<any, any>;
    new <K, V>(): WeakMap<K, V>;
    prototype: WeakMap<any, any>;
  }

  const hasOwn = Object.prototype.hasOwnProperty;

  namespace HashMap {
    const downLevel = !Support.Objects.Create && !Support.Objects.Proto;
    // create an object in dictionary mode (a.k.a. "slow" mode in v8)
    export const create = Support.Objects.Create
      ? <V>() => makeDictionary(Object.create(null) as HashMap<V>)
      : Support.Objects.Proto
        ? <V>() => makeDictionary({ __proto__: null as any } as HashMap<V>)
        : <V>() => makeDictionary({} as HashMap<V>);

    export const has = downLevel
      ? <V>(map: HashMap<V>, key: string | number | symbol) => hasOwn.call(map, key)
      : <V>(map: HashMap<V>, key: string | number | symbol) => key in map;

    export const get = downLevel
      ? <V>(map: HashMap<V>, key: string | number | symbol): V | undefined => hasOwn.call(map, key) ? map[key] : undefined
      : <V>(map: HashMap<V>, key: string | number | symbol): V | undefined => map[key];

    function makeDictionary<T>(obj: T): T {
      (<any>obj).__ = undefined;
      delete (<any>obj).__;
      return obj;
    }
  }

  declare const WeakMap: WeakMapConstructor;
  declare const Map: MapConstructor;
  export const __Map: typeof Map = !Support.Iterables.UseMapPolyfill && typeof Map === 'function' && typeof Map.prototype.entries === 'function' ? Map : __createMapPolyfill();
  export const __WeakMap: typeof WeakMap = !Support.Iterables.UseMapPolyfill && typeof WeakMap === 'function' ? WeakMap : __createWeakMapPolyfill();

  /**
   * Naive Map shim.
   * @returns Maps.MapConstructor
   */
  function __createMapPolyfill(): MapConstructor {
    const cacheSentinel = {};
    const arraySentinel: any[] = [];

    class MapIterator<K, V, R extends (K | V | [K, V])> implements IterableIterator<R> {
      private _keys: K[];
      private _values: V[];
      private _index = 0;
      private _selector: (key: K, value: V) => R;
      constructor(keys: K[], values: V[], selector: (key: K, value: V) => R) {
        this._keys = keys;
        this._values = values;
        this._selector = selector;
      }
      '@@iterator'() { return this; }
      [Types.IteratorSymbol]() { return this; }
      next(): IteratorResult<R> {
        const index = this._index;
        if (index >= 0 && index < this._keys.length) {
          const result = this._selector(this._keys[index], this._values[index]);
          if (index + 1 >= this._keys.length) {
            this._index = -1;
            this._keys = arraySentinel;
            this._values = arraySentinel;
          }
          else {
            this._index++;
          }
          return { value: result, done: false };
        }
        return { value: <never>undefined, done: true };
      }
      throw(error: any): IteratorResult<R> {
        if (this._index >= 0) {
          this._index = -1;
          this._keys = arraySentinel;
          this._values = arraySentinel;
        }
        throw error;
      }
      return(value?: R): IteratorResult<R> {
        if (this._index >= 0) {
          this._index = -1;
          this._keys = arraySentinel;
          this._values = arraySentinel;
        }
        return { value: <never>value, done: true };
      }
    }

    return class Map<K, V> {
      private _keys: K[] = [];
      private _values: (V | undefined)[] = [];
      private _cacheKey = cacheSentinel;
      private _cacheIndex = -2;
      get size() { return this._keys.length; }
      has(key: K): boolean { return this._find(key, /*insert*/ false) >= 0; }
      get(key: K): V | undefined {
        const index = this._find(key, /*insert*/ false);
        return index >= 0 ? this._values[index] : undefined;
      }
      set(key: K, value: V): this {
        const index = this._find(key, /*insert*/ true);
        this._values[index] = value;
        return this;
      }
      delete(key: K): boolean {
        const index = this._find(key, /*insert*/ false);
        if (index >= 0) {
          const size = this._keys.length;
          for (let i = index + 1; i < size; i++) {
            this._keys[i - 1] = this._keys[i];
            this._values[i - 1] = this._values[i];
          }
          this._keys.length--;
          this._values.length--;
          if (key === this._cacheKey) {
            this._cacheKey = cacheSentinel;
            this._cacheIndex = -2;
          }
          return true;
        }
        return false;
      }
      clear(): void {
        this._keys.length = 0;
        this._values.length = 0;
        this._cacheKey = cacheSentinel;
        this._cacheIndex = -2;
      }
      keys() { return new MapIterator(this._keys, this._values, getKey); }
      values() { return new MapIterator(this._keys, this._values, getValue); }
      entries() { return new MapIterator(this._keys, this._values, getEntry); }
      '@@iterator'() { return this.entries(); }
      [Types.IteratorSymbol]() { return this.entries(); }
      private _find(key: K, insert?: boolean): number {
        if (this._cacheKey !== key) {
          this._cacheIndex = this._keys.indexOf(this._cacheKey = key);
        }
        if (this._cacheIndex < 0 && insert) {
          this._cacheIndex = this._keys.length;
          this._keys.push(key);
          this._values.push(undefined);
        }
        return this._cacheIndex;
      }
    };

    function getKey<K, V>(key: K, _: V) {
      return key;
    }

    function getValue<K, V>(_: K, value: V) {
      return value;
    }

    function getEntry<K, V>(key: K, value: V) {
      return [key, value] as [K, V];
    }
  }

  function __createWeakMapPolyfill(): WeakMapConstructor {
    const keys = HashMap.create<boolean>();
    const rootKey = __createUniqueKey();
    return class WeakMap<K, V> {
      private _key = __createUniqueKey();

      has(target: K): boolean {
        const table = __getWeakMapTable<K>(target, /*create*/ false);
        return table !== undefined ? HashMap.has(table, this._key) : false;
      }
      get(target: K): V {
        const table = __getWeakMapTable<K>(target, /*create*/ false);
        return table !== undefined ? HashMap.get(table, this._key) : undefined;
      }
      set(target: K, value: V): WeakMap<K, V> {
        const table = __getWeakMapTable<K>(target, /*create*/ true);
        table[this._key] = value;
        return this;
      }
      delete(target: K): boolean {
        const table = __getWeakMapTable<K>(target, /*create*/ false);
        return table !== undefined ? delete table[this._key] : false;
      }
      clear(): void {
        // NOTE: not a real clear, just makes the previous data unreachable
        this._key = __createUniqueKey();
      }
    };

    function __createUniqueKey(): string {
      let key: string;
      do key = '@@WeakMap@@' + UUIDS.create();
      while (HashMap.has(keys, key));
      keys[key] = true;
      return key;
    }

    function __getWeakMapTable<K>(target: K, create: boolean): HashMap<any> | undefined {
      if (!hasOwn.call(target, rootKey)) {
        if (!create) return undefined;
        Object.defineProperty(target, rootKey, { value: HashMap.create<any>() });
      }
      return (<any>target)[rootKey];
    }
  }
}
