// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {Support} from './support';
import {Types} from './types';
import {Objects} from './objects';
import {Iterables} from './iterables';
import {Iterators} from './iterators';
import {Maps} from './maps';

/**
 * Helper for Set objects (WIP)
 */
export namespace Sets {
  import Iterable = Iterables.Iterable;
  import IterableIterator = Iterables.IterableIterator;

  export interface Set<T> extends Iterable<T> {
    size: number;
    has(value: T): boolean;
    add(value: T): this;
    delete(value: T): boolean;
    clear(): void;
    keys(): IterableIterator<T>;
    values(): IterableIterator<T>;
    entries(): IterableIterator<[T, T]>;
  }

  export interface SetConstructor {
    new (): Set<any>;
    new <T>(): Set<T>;
    prototype: Set<any>;
  }

  declare const Set: SetConstructor;
  export const __Set: typeof Set = !Support.Iterables.UseMapPolyfill && typeof Set === 'function' && typeof Set.prototype.entries === 'function' ? Set : __createPolyfill();

  function __createPolyfill(): SetConstructor {
    return class Set<T> {
      private _map = new Maps.__Map<any, any>();
      get size() { return this._map.size; }
      has(value: T): boolean { return this._map.has(value); }
      add(value: T): Set<T> { return this._map.set(value, value), this; }
      delete(value: T): boolean { return this._map.delete(value); }
      clear(): void { this._map.clear(); }
      keys() { return this._map.keys(); }
      values() { return this._map.values(); }
      entries() { return this._map.entries(); }
      '@@iterator'() { return this.keys(); }
      [Types.IteratorSymbol]() { return this.keys(); }
    };
  }
}
