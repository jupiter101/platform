// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

export namespace Objects {

  /**
   * Retrieves array of object property names and symbols.
   * @param obj
   */
  export const keys = (obj: any) => Reflect.ownKeys(obj);

  /**
   * Object key, value generator.
   * @example
   *
   * for (const [key, value] of TS.Objects.entries(TestDomain)) {
   *  console.log(`${key}: ${value}`);
   * }
   *
   * @param obj
   */
  export function *entries(obj: any) {
    const propKeys = keys(obj);
    for (const propKey of propKeys) {
      yield [propKey, obj[propKey]];
    }
  }

  /**
   * Better Object.assign due to consideration of inherited properties and all property attributes.
   * @param target
   * @param sources
   * @returns {any}
   */
  function merge(target: any, ...sources: any[]) {
    for (const source of sources) {
      for (const key of keys(source)) {
        const desc = Object.getOwnPropertyDescriptor(source, key);
        Object.defineProperty(target, key, desc);
      }
    }
    return target;
  }

  /**
   * Clones a given source.
   * @param source object
   * @param keepProto true -> keeps the original prototype (default: false)
   * @returns any
   */
  function clone(source: any, keepProto: boolean = false): any {
    const target = keepProto ? Object.create(Object.getPrototypeOf(source)) : {};
    for (const key of keys(source)) {
      const desc = Object.getOwnPropertyDescriptor(source, key);
      Object.defineProperty(target, key, desc);
    }
    return target;
  }

}
