// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:no-eval
import * as TS from './lang';
import {IFormat, DateFormatter} from './format';
import {PatternCompiler, DateParser} from './format/dateparser';


{
  let formatter: IFormat = new DateFormatter('de', 'dd.MM.yyyy');

  // formatter.parse('2', 'dd|pastcurrent', 'd|pastcurrent').format(); // => 02.11.2017
  // formatter.parse('2', 'dd|past', 'd|past').format(); // => 02.11.2017
  // formatter.parse('2', 'dd|futurecurrent', 'd|futurecurrent').format(); // => 02.12.2017
  // formatter.parse('2', 'dd|future', 'd|future').format(); // => 02.12.2017
  //
  // formatter.parse('13', 'dd|pastcurrent', 'd|pastcurrent').format(); // => 13.11.2017
  // formatter.parse('13', 'dd|past', 'd|past').format(); // => 13.10.2017
  // formatter.parse('13', 'dd|futurecurrent', 'd|futurecurrent').format(); // => 13.11.2017
  // formatter.parse('13', 'dd|future', 'd|future').format(); // => 13.12.2017
  //
  // formatter.parse('17', 'dd|pastcurrent', 'd|pastcurrent').format(); // => 17.10.2017
  // formatter.parse('17', 'dd|past', 'd|past').format(); // => 17.10.2017
  // formatter.parse('17', 'dd|futurecurrent', 'd|futurecurrent').format(); // => 17.11.2017
  // formatter.parse('17', 'dd|future', 'd|future').format(); // => 17.11.2017
  //
  // // ###
  console.log(formatter.parse('1.12', 'ddMM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format()); // => 02.10.2017
  // formatter.parse('2.10', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 02.10.2017
  // formatter.parse('2.10', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 02.10.2017
  // formatter.parse('2.10', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 02.10.2018
  // formatter.parse('2.10', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 02.10.2018
  //
  // formatter.parse('13.10', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 13.10.2017
  // formatter.parse('13.10', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 13.10.2017
  // formatter.parse('13.10', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 13.10.2018
  // formatter.parse('13.10', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 13.10.2018
  //
  // formatter.parse('14.10', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 14.10.2017
  // formatter.parse('14.10', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 14.10.2017
  // formatter.parse('14.10', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 14.10.2018
  // formatter.parse('14.10', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 14.10.2018
  //
  // // ##
  // console.log(formatter.parse('2.11', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(undefined, 'EEEE dd.MM.yyyy')); // => 02.11.2017
  // formatter.parse('2.11', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 02.11.2017
  // formatter.parse('2.11', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 02.11.2018
  // formatter.parse('2.11', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 02.11.2018
  //
  // formatter.parse('13.11', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 13.11.2017
  // formatter.parse('13.11', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 13.11.2016
  // formatter.parse('13.11', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 13.11.2017
  // formatter.parse('13.11', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 13.11.2018
  //
  // formatter.parse('14.11.', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 14.11.2016
  // formatter.parse('14.11.', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 14.11.2016
  // formatter.parse('14.11.', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 14.11.2017
  // formatter.parse('14.11.', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 14.11.2017
  //
  //
  // // ##
  // formatter.parse('2.12', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 02.12.2016
  // formatter.parse('2.12', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 02.12.2016
  // formatter.parse('2.12', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 02.12.2017
  // formatter.parse('2.12', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 02.12.2017
  //
  // formatter.parse('13.12', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 13.12.2016
  // formatter.parse('13.12', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 13.12.2016
  // formatter.parse('13.12', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 13.12.2017
  // formatter.parse('13.12', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 13.12.2017
  //
  // formatter.parse('14.12.', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent').format(); // => 14.12.2016
  // formatter.parse('14.12.', 'd.MM|past', 'dd.MM|past', 'dd.M|past').format(); // => 14.12.2016
  // formatter.parse('14.12.', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent').format(); // => 14.12.2017
  // formatter.parse('14.12.', 'd.MM|future', 'dd.MM|future', 'dd.M|future').format(); // => 14.12.2017
  //
  //
  // // ##
  // formatter.parse('02.11.17', 'dd.MM.yy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent', 'dd|pastcurrent', 'd|pastcurrent').format(); // => 02.12.2016
  // formatter.parse('2.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|past', 'dd.MM|past', 'dd.M|past', 'dd|past', 'd|past').format(); // => 02.12.2016
  // formatter.parse('2.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent', 'dd|futurecurrent', 'd|futurecurrent').format(); // => 02.12.2017
  // formatter.parse('2.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|future', 'dd.MM|future', 'dd.M|future', 'dd|future', 'd|future').format(); // => 02.12.2017
  //
  // formatter.parse('13.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent', 'd.MM.yy', 'dd.MM.yy', 'dd.M.yy').format(); // => 13.12.2016
  // formatter.parse('13.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|past', 'dd.MM|past', 'dd.M|past', 'dd|past', 'd|past').format(); // => 13.12.2016
  // formatter.parse('13.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent', 'dd|futurecurrent', 'd|futurecurrent').format(); // => 13.12.2017
  // formatter.parse('13.11.17', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|future', 'dd.MM|future', 'dd.M|future', 'dd.M|future', 'dd|future', 'd|future').format(); // => 13.12.2017
  //
  // formatter.parse('14.11.17.', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|pastcurrent', 'dd.MM|pastcurrent', 'dd.M|pastcurrent', 'd.MM.yy', 'dd.MM.yy', 'dd.M.yy').format(); // => 14.12.2016
  // formatter.parse('14.11.17.', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|past', 'dd.MM|past', 'dd.M|past', 'dd|past', 'd|past').format(); // => 14.12.2016
  // formatter.parse('14.11.17.', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|futurecurrent', 'dd.MM|futurecurrent', 'dd.M|futurecurrent', 'd.MM.yy', 'dd.MM.yy', 'dd.M.yy').format(); // => 14.12.2017
  // formatter.parse('14.11.17.', 'dd.MM.yyyy HH:mm:ss', 'dd.MM.yy HH:mm', 'd.MM|future', 'dd.MM|future', 'dd.M|future', 'dd.M|future', 'dd|future', 'd|future').format(); // => 14.12.2017
  //

  // formatter.parse('2', 'dd.MM.yyyy HH:mm:ss', 'dd|current').format(); // => 02.11.2017
  // formatter.parse('2.11', 'dd.MM.yyyy HH:mm:ss', 'dd|current').format(); // => 02.11.2017
}

{

  // let result: Date = DateParser.parse('12.11.2017 23:14', ['dd/MM/yyyy HH:mm']);
  // console.log('####### DateParser.parse: ');
  // console.log(result);
  // console.log('####### DateParser.parse.');
  // console.log('####### DateFormatter.format: ');
  // let formatter: IFormat = new DateFormatter('de');
  // console.log(formatter.format(result, 'dd/MM/yyyy HH:mm'));
  // console.log('####### DateFormatter.format.');

  // let result = DateParser.parse('2.11.2 23:14', ['d/MM/y', 'dd/MM/yy']);
  // console.log('####### DateParser.parse: ');
  // console.log( (result ? result.toDateString() : 'INVALID DATE'));
  // console.log('####### DateParser.parse.');
  // console.log('####### DateFormatter.format: ');
  // if (result) {
  //   let formatter2: IFormat = new DateFormatter('de');
  //   console.log(formatter2.format(result, 'dd/MM/yyyy HH:mm'));
  // }
  // console.log('####### DateFormatter.format.');

  // result = DateParser.parse('13', ['dd']);
  // console.log('####### DateParser.parse: ');
  // console.log(result.toDateString());
  // console.log('####### DateParser.parse.');
  // console.log('####### DateFormatter.format: ');
  // let formatter3: IFormat = new DateFormatter('de');
  // console.log(formatter3.format(result, 'dd/MM/yyyy HH:mm'));
  // console.log('####### DateFormatter.format.');
  //
  // result = DateParser.parse('1312', ['ddMM|past']);
  // console.log('####### DateParser.parse: ');
  // console.log(result.toDateString());
  // console.log('####### DateParser.parse.');
  // console.log('####### DateFormatter.format: ');
  // let formatter4: IFormat = new DateFormatter('de');
  // console.log(formatter4.format(result, 'dd/MM/yyyy HH:mm'));
  // console.log('####### DateFormatter.format.');
  //
  //
  // console.log('####### DateParser.parse: ');
  // result = DateParser.parse('3102', ['ddMM|pastcurrent']);
  // console.log( (result ? result.toDateString() : 'INVALID DATE'));
  // console.log('####### DateParser.parse.');
  // console.log('####### DateFormatter.format: ');
  // if (result) {
  //   let formatter5: IFormat = new DateFormatter('de');
  //   console.log(formatter5.format(result, 'dd/MM/yyyy HH:mm'));
  // }
  //
  // console.log('####### DateFormatter.format.');
}


{

  // /^(\d{1,2})[\/\-.]{0,1}(d{1,2})[\/\-. ]{0,1}(\d{0,4})[\/\-. ]{0,1}$/
  let pfn_dd_MM_yyyy: Function = PatternCompiler.compile('dd.MM.yyyy');
  let pfn_dd: Function = PatternCompiler.compile('dd.');
  let pfn_dd_MM: Function = PatternCompiler.compile('dd.MM');
  // console.log('12.3.2017'.match(pfn_dd_MM_yyyy()));
  // console.log(pfn_dd_MM_yyyy().exec('1/12/99'));
  // console.log(pfn_dd_MM_yyyy().exec('011299'));
  //
  // '011299'.replace(pfn_dd_MM_yyyy(), (...rest) => {
  //   console.log(rest);
  //   return '';
  // });
  //
  // console.log(pfn_dd().exec('12'));
  // console.log(pfn_dd().exec('12.'));
  // console.log(pfn_dd().exec('1.'));
  // //
  // console.log(pfn_dd_MM().exec('12.12'));
  // console.log(pfn_dd_MM().exec('1.12'));
  // console.log(pfn_dd_MM().exec('1/12'));
  // console.log(pfn_dd_MM().exec('1.2'));
  // console.log(pfn_dd_MM().exec('1/2'));
  // console.log(pfn_dd_MM().exec('112'));
  // console.log(pfn_dd_MM().exec('110299'));
  // console.log(pfn_dd_MM().exec('110299')[2]);
  // console.log(pfn_dd_MM().exec('1.12.99'));
  // console.log(new Date().toDateString());
  // console.log(new Date().toISOString());

  // /^(0?[1-9]|[12][0-9]|3[01])[\/\-. ]{0,1}(0?[1-9]|1[012])[\/\-. ]{0,1}(\d{1,4})[\/-. ]{0,1}$/
}
