// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * General interface to parse a string according a given format.
 */
export interface IFormatParser {
  parse(value: string, ...parsehints: string[]): this;
}

/**
 * General interface for implementing a formatter for date, numbers and strings.
 */
export interface IFormat extends IFormatParser {
  format(date?: Date, format?: string): string;
}
