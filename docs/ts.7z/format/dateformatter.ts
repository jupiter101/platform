// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import {DateParser} from './dateparser';
import {IFormat} from './format.interface';

type FormatFunction = (date: Date, locale: string) => string;

const FORMATTER_CACHE = new Map<string, string[]>();
const FORMAT_SYMBOL_MATCHER =
  /((?:[^yMLdHhmsazZEwGjJ']+)|(?:'(?:[^']|'')*')|(?:E+|y+|M+|L+|d+|H+|h+|J+|j+|m+|s+|a|z|Z|G+|w+))(.*)/;

const STANDARD_FORMAT_SYMBOL_PROCESSOR_MAP: {[format: string]: FormatFunction} = {
  // Keys are quoted so they do not get renamed during closure compilation.
  'yMMMdjms': dateFormatProcessor(mergeOptions([
    digitFormatOptionSetter('year', 1),
    nameFormatOptionSetter('month', 3),
    digitFormatOptionSetter('day', 1),
    digitFormatOptionSetter('hour', 1),
    digitFormatOptionSetter('minute', 1),
    digitFormatOptionSetter('second', 1),
  ])),
  'yMdjm': dateFormatProcessor(mergeOptions([
    digitFormatOptionSetter('year', 1), digitFormatOptionSetter('month', 1), digitFormatOptionSetter('day', 1),
    digitFormatOptionSetter('hour', 1), digitFormatOptionSetter('minute', 1)
  ])),
  'yMMMMEEEEd': dateFormatProcessor(mergeOptions([
    digitFormatOptionSetter('year', 1), nameFormatOptionSetter('month', 4), nameFormatOptionSetter('weekday', 4),
    digitFormatOptionSetter('day', 1)
  ])),
  'yMMMMd': dateFormatProcessor(
    mergeOptions([digitFormatOptionSetter('year', 1), nameFormatOptionSetter('month', 4), digitFormatOptionSetter('day', 1)])),
  'yMMMd': dateFormatProcessor(
    mergeOptions([digitFormatOptionSetter('year', 1), nameFormatOptionSetter('month', 3), digitFormatOptionSetter('day', 1)])),
  'yMd': dateFormatProcessor(
    mergeOptions([digitFormatOptionSetter('year', 1), digitFormatOptionSetter('month', 1), digitFormatOptionSetter('day', 1)])),
  'jms': dateFormatProcessor(mergeOptions(
    [digitFormatOptionSetter('hour', 1), digitFormatOptionSetter('second', 1), digitFormatOptionSetter('minute', 1)])),
  'jm': dateFormatProcessor(mergeOptions([digitFormatOptionSetter('hour', 1), digitFormatOptionSetter('minute', 1)]))
};

const FORMAT_SYMBOL_PROCESSOR_MAP: {[format: string]: FormatFunction} = {
  // Keys are quoted so they do not get renamed.
  'yyyy': dateFormatProcessor(digitFormatOptionSetter('year', 4)),
  'yy': dateFormatProcessor(digitFormatOptionSetter('year', 2)),
  'y': dateFormatProcessor(digitFormatOptionSetter('year', 1)),
  'MMMM': dateFormatProcessor(nameFormatOptionSetter('month', 4)),
  'MMM': dateFormatProcessor(nameFormatOptionSetter('month', 3)),
  'MM': dateFormatProcessor(digitFormatOptionSetter('month', 2)),
  'M': dateFormatProcessor(digitFormatOptionSetter('month', 1)),
  'LLLL': dateFormatProcessor(nameFormatOptionSetter('month', 4)),
  'L': dateFormatProcessor(nameFormatOptionSetter('month', 1)),
  'dd': dateFormatProcessor(digitFormatOptionSetter('day', 2)),
  'd': dateFormatProcessor(digitFormatOptionSetter('day', 1)),
  'HH': digitFormatProcessor(
    hourFormatProcessor(dateFormatProcessor(hour12FormatOptionSetter(digitFormatOptionSetter('hour', 2), false)))),
  'H': hourFormatProcessor(dateFormatProcessor(hour12FormatOptionSetter(digitFormatOptionSetter('hour', 1), false))),
  'hh': digitFormatProcessor(
    hourFormatProcessor(dateFormatProcessor(hour12FormatOptionSetter(digitFormatOptionSetter('hour', 2), true)))),
  'h': hourFormatProcessor(dateFormatProcessor(hour12FormatOptionSetter(digitFormatOptionSetter('hour', 1), true))),
  'jj': dateFormatProcessor(digitFormatOptionSetter('hour', 2)),
  'j': dateFormatProcessor(digitFormatOptionSetter('hour', 1)),
  'mm': digitFormatProcessor(dateFormatProcessor(digitFormatOptionSetter('minute', 2))),
  'm': dateFormatProcessor(digitFormatOptionSetter('minute', 1)),
  'ss': digitFormatProcessor(dateFormatProcessor(digitFormatOptionSetter('second', 2))),
  's': dateFormatProcessor(digitFormatOptionSetter('second', 1)),
  // while ISO 8601 requires fractions to be prefixed with `.` or `,`
  // we can be just safely rely on using `sss` since we currently don't support single or two digit
  // fractions
  'sss': dateFormatProcessor(digitFormatOptionSetter('second', 3)),
  'EEEE': dateFormatProcessor(nameFormatOptionSetter('weekday', 4)),
  'EEE': dateFormatProcessor(nameFormatOptionSetter('weekday', 3)),
  'EE': dateFormatProcessor(nameFormatOptionSetter('weekday', 2)),
  'E': dateFormatProcessor(nameFormatOptionSetter('weekday', 1)),
  'a': hourClockFormatProcessor(dateFormatProcessor(hour12FormatOptionSetter(digitFormatOptionSetter('hour', 1), true))),
  'Z': timeZoneFormatProcessor('short'),
  'z': timeZoneFormatProcessor('long'),
  'ww': dateFormatProcessor({}),  // Week of year, padded (00-53). Week 01 is the week with the first Thursday of the year. not support ?
  'w': dateFormatProcessor({}),  // Week of year (0-53). Week 1 is the week with the first Thursday of the year not support ?
  'G': dateFormatProcessor(nameFormatOptionSetter('era', 1)),
  'GG': dateFormatProcessor(nameFormatOptionSetter('era', 2)),
  'GGG': dateFormatProcessor(nameFormatOptionSetter('era', 3)),
  'GGGG': dateFormatProcessor(nameFormatOptionSetter('era', 4))
};

/**
 * Padding digit.
 * @param {FormatFunction} inner
 * @returns {FormatFunction}
 */
function digitFormatProcessor(inner: FormatFunction): FormatFunction {
  return (date: Date, locale: string): string => {
    const result = inner(date, locale);
    return result.length === 1 ? '0' + result : result;
  };
}

/**
 * Extracts hourCycle string.
 * @param {FormatFunction} inner
 * @returns {FormatFunction}
 */
function hourClockFormatProcessor(inner: FormatFunction): FormatFunction {
  return (date: Date, locale: string): string => inner(date, locale).split(' ')[1];
}

/**
 * Extracts hour string.
 * @param {FormatFunction} inner
 * @returns {FormatFunction}
 */
function hourFormatProcessor(inner: FormatFunction): FormatFunction {
  return (date: Date, locale: string): string => inner(date, locale).split(' ')[0];
}

/**
 * Formats date with Intl.DateTimeFormat#format.
 * Ignores  left-to-right mark (LRM) and right-to-left mark (RLM) control chars.
 * @param {Date} date
 * @param {string} locale
 * @param {Intl.DateTimeFormatOptions} options
 * @returns {string}
 */
function intlDateFormat(date: Date, locale: string, options: Intl.DateTimeFormatOptions): string {
  return new Intl.DateTimeFormat(locale, options).format(date).replace(/[\u200e\u200f]/g, '');
}

/**
 * Formats date with timezone information.
 * @param {string} timezone
 * @returns {FormatFunction}
 */
function timeZoneFormatProcessor(timezone: string): FormatFunction {
  // To workaround `Intl` API restriction for single timezone let format with 24 hours
  const options = {hour: '2-digit', hour12: false, timeZoneName: timezone};
  return (date: Date, locale: string): string => {
    const result = intlDateFormat(date, locale, options);
    // Then extract first 3 letters that related to hours
    return result ? result.substring(3) : '';
  };
}

/**
 * Whether to use 12-hour time (as opposed to 24-hour time). Possible values are true and false;
 * the default is locale dependent. This option overrides the hc language tag and/or the hourCycle
 * option in case both are present.
 * @param {Intl.DateTimeFormatOptions} options
 * @param {boolean} value
 * @returns {Intl.DateTimeFormatOptions}
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
 */
function hour12FormatOptionSetter(
  options: Intl.DateTimeFormatOptions, value: boolean): Intl.DateTimeFormatOptions {
  options.hour12 = value;
  return options;
}

/**
 * Whether to use numeric or 2-digit representation.
 * @param {string} prop
 * @param {number} len
 * @returns {Intl.DateTimeFormatOptions}
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
 */
function digitFormatOptionSetter(prop: string, len: number): Intl.DateTimeFormatOptions {
  const result: {[k: string]: string} = {};
  result[prop] = len === 2 ? '2-digit' : 'numeric';
  return result;
}

/**
 * Wheter to use "narrow", "short" or "long" representation for names.
 * @param {string} prop
 * @param {number} len
 * @returns {Intl.DateTimeFormatOptions}
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
 */
function nameFormatOptionSetter(prop: string, len: number): Intl.DateTimeFormatOptions {
  const result: {[k: string]: string} = {};
  if (len < 4) {
    result[prop] = len > 1 ? 'short' : 'narrow';
  } else {
    result[prop] = 'long';
  }
  return result;
}

/**
 * Merges Intl.DateTimeFormatOptions.
 * @param {Intl.DateTimeFormatOptions[]} options
 * @returns {Intl.DateTimeFormatOptions}
 */
function mergeOptions(options: Intl.DateTimeFormatOptions[]): Intl.DateTimeFormatOptions {
  return options.reduce((merged, opt) => ({...merged, ...opt}), {});
}

/**
 * Intl.DateTimeFormat#format entry point.
 * @param {Intl.DateTimeFormatOptions} ret
 * @returns {FormatFunction}
 */
function dateFormatProcessor(ret: Intl.DateTimeFormatOptions): FormatFunction {
  return (date: Date, locale: string): string => intlDateFormat(date, locale, ret);
}


/**
 * Entry function to format a date.
 * @param {string} format
 * @param {Date} date
 * @param {string} locale
 * @returns {string}
 */
function dateFormatter(format: string, date: Date, locale: string): string {
  const completionHintMatcher = /\|(pastcurrent|futurecurrent|past|current|future)/g;
  let completionHint: string;

  // extract completion hint
  format = format.replace(completionHintMatcher, (match, hint) => {
    completionHint = hint;
    return '';
  });

  // extract and run a standard format processor
  const fn = STANDARD_FORMAT_SYMBOL_PROCESSOR_MAP[format];
  if (fn) return fn(date, locale);

  // test cache for available format key / symbol parts
  const cacheKey = format;
  let parts = FORMATTER_CACHE.get(cacheKey);

  if (!parts) {
    parts = [];
    let match: RegExpExecArray|null;
    FORMAT_SYMBOL_MATCHER.exec(format);

    let _format: string|null = format;
    while (_format) {
      match = FORMAT_SYMBOL_MATCHER.exec(_format);
      if (match) {
        parts = parts.concat(match.slice(1));
        _format = parts.pop() !;
      } else {
        parts.push(_format);
        _format = null;
      }
    }
    FORMATTER_CACHE.set(cacheKey, parts);
  }

  return parts.reduce((text, part) => {
    const fn = FORMAT_SYMBOL_PROCESSOR_MAP[part];
    return text + (fn ? fn(date, locale) : setTime(part));
  }, '');
}

/**
 * Sets the time component format.
 * @param {string} part
 * @returns {string}
 */
function setTime(part: string): string {
  return part === '\'\'' ? '\'' : part.replace(/(^'|'$)/g, '').replace(/''/g, '\'');
}


/**
 * Date/Time Formatter implementing the IFormat interface.
 */
export class DateFormatter implements IFormat {
  private _date: Date;
  constructor(private _locale: string, private _format?: string) {}

  format(date?: Date, format?: string): string {
    const dt: Date = date ? date : (this._date ? this._date : undefined);
    const fmt: string = format ? format : (this._format ? this._format : undefined);
    if (!fmt || !dt) { return ''; }
    return dateFormatter(fmt, dt, this._locale);
  }

  parse(value: string, ...parsehints: string[]): this {
    this._date = DateParser.parse(value, parsehints);
    return this;
  }
}
