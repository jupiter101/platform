// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

import * as TS from './lang';

{
  console.log(`TS.Support.Objects.Create: ${TS.Support.Objects.Create}`);
  console.log(`TS.Support.Objects.Proto: ${TS.Support.Objects.Proto}`);
  console.log(`TS.Support.Types.Symbols: ${TS.Support.Types.Symbols}`);

  console.log(`TS.Support.Cryptos.Standard: ${TS.Support.Cryptos.Standard}`);
  console.log(`TS.Support.Cryptos.Microsoft: ${TS.Support.Cryptos.Microsoft}`);

  console.log(`TS.Support.Iterables.Uint8Arrays: ${TS.Support.Iterables.Uint8Arrays}`);
  console.log(`TS.Support.Iterables.UseMapPolyfill: ${TS.Support.Iterables.UseMapPolyfill}`);

}
