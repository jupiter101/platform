// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Inject, LOCALE_ID, Pipe, PipeTransform} from '@angular/core';
import {DateFormatter} from './dateformatter';
import {TIDEDateFormat, TIDEDateFormatPattern} from './dateformat';
import * as TS from '../lang/index';


/**
 * Simple Date Formatter pipe.
 *
 * TODO add logic to connect domain object to pipe (to retrieve parser hints and target format)
 * TODO add logic to handle i18n format pattern for TIDEDateFormat
 *
 */
@Pipe({name: 'date', pure: true})
export class IntlDatePipe implements PipeTransform {
  private _dateFormatter: DateFormatter;
  constructor(@Inject(LOCALE_ID) private _locale: string) {
    this._dateFormatter = new DateFormatter(_locale, TIDEDateFormatPattern.from(_locale)(TIDEDateFormat.Y_M_D));
  }

  transform(value: any, pattern: string = 'mediumDate'): string|null {
    if (TS.Values.isBlank(value) || value !== value) return null;
    if (typeof value === 'string') {
      value = value.trim();
    }

    return this._dateFormatter.parse(value, pattern).format();
  }
}
