// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Format annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Format(TIDEDateFormat.CURRENT_MD, TIDEDateFormat.CURRENT_M_D, TIDEDateFormat.CURRENT_M_D2)
 *  myprop: Object
 * }
 * ```
 *
 */
export const Format = (...args: string[]): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyFormat, target, {
      k: propertyKey,
      v: { k: 'format', v: args },
    });
  };
};
