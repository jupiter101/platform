// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * MaxLength annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @MaxLength(255)
 *  myprop: Array
 *
 *  @MaxLength(255)
 *  myprop2: string
 * }
 * ```
 *
 */
export const MaxLength = (max: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey, v: { k: 'maxlength', v: TS.Validators.MaxLengthValidator(max) },
    });
  };
};
