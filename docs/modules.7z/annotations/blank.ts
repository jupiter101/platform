// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';
import BlankValidator = TS.Validators.BlankValidator;
/**
 * Blank annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Blank
 *  myprop: string
 * }
 * ```
 *
 */
export const Blank = (): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'blank', v: BlankValidator },
    });
  };
};
