// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Size annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Size(0, 50)
 *  myprop: []
 * }
 * ```
 *
 */
export const Size = (min: number, max: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'size', v: TS.Validators.SizeValidator(min, max) },
    });
  };
};
