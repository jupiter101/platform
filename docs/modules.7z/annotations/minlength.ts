// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * MinLength annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @MinLength(5)
 *  myprop: Array
 *
 *  @MinLength(5)
 *  myprop2: string
 * }
 * ```
 *
 */
export const MinLength = (min: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'minlength', v: TS.Validators.MinLengthValidator(min) },
    });
  };
};
