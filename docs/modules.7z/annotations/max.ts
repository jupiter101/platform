// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import * as TS from '../lang/index';

/**
 * Max annotation.
 *
 * ### Example
 *
 * ```
 * class Domain {
 *
 *  @Max(255)
 *  myprop: number
 * }
 * ```
 *
 */
export const Max = (max: number): PropertyDecorator => {
  return (target: Object, propertyKey: string | symbol) => {
    TS.MetaOld.setPropertyMetadata(TS.MetaOld.MetaDataType.PropertyValidator, target, {
      k: propertyKey,
      v: { k: 'max', v: TS.Validators.MaxValidator(max) },
    });
  };
};
