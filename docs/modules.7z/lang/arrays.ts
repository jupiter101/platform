// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for Arraqy objects.
 *
 * TODO use of destructuring for Array.from
 *
 */
export namespace Arrays {
  export const isArray = (value: any): boolean => Array.isArray(value);
  export const create = <T>(size: number, mapper: (v: T, i: number) => T) => Array.from<T>(new Array<T>(size), mapper);

  /**
   * Removes holes from an array.
   *
   * @example Remove NaN and undefined entries
   *
   * ```typescript
   * Arrays.removeHoles([1, NaN, 2, undefined], (v) => (!isNaN(v - parseFloat(v))) && true ));
   * ```
   *
   * @param {T[]} value
   * @param {(obj?) => boolean} predicate
   * @see http://exploringjs.com/es6/ch_arrays.html#sec_array-holes
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  export const removeHoles = <T>(value: T[], predicate: (obj?: any) => boolean = () => true) => value.filter(predicate);
  export const flatten = <T>(a: T[][]) => (<T[]>[]).concat(...a);

  /**
   * Returns an array containing all elements of the input iterable.
   *
   * @example
   * // return [0,1,2]
   * list( range( 3 ) ) ;
   *
   * @param {Iterable} iterable - The input iterable.
   * @returns {Array}
   *
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  export const list = ( iterable: any ) => Array.from( iterable );
}
