// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Types} from './types';



export namespace Support {
  declare const crypto: Crypto;
  declare const msCrypto: Crypto;
  declare const process: any;

  export namespace Objects {
    export const Create: boolean = typeof Object.create === 'function'; // feature test for Object.create support
    export const Proto: boolean = typeof Object.create === 'function'; // feature test for Object.create support
  }

  export namespace Types {
    export const Symbols: boolean = typeof Symbol === 'function';
  }

  export namespace Cryptos {
    export const Standard: boolean = typeof crypto !== 'undefined';
    export const Microsoft: boolean = typeof msCrypto !== 'undefined';
  }

  export namespace Iterables {
    export const Uint8Arrays: boolean = typeof Uint8Array === 'function';
    export const UseMapPolyfill: boolean = typeof process === 'object' && process.env && process.env['TIDE_USE_MAP_POLYFILL'] === 'true';
  }

}
