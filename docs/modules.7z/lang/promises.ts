// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
/**
 * Helper for Promise objects (WIP)
 */
export namespace Promises {
  export const isPromise = (obj: any): obj is Promise<any> => !!obj && typeof obj.then === 'function';
}
