// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

export namespace MetaOld {
  export enum MetaDataType {
    PropertyValidator,
    PropertyFormat,
    PropertyAny
  }

  export type TIDEMetadata = Map<string | symbol, Map<string | symbol, any>>;

  export interface TIDEMetadataEntry {
    k: string | symbol;
    v: TIDEPropertyMetadataEntry;
  }

  export interface TIDEPropertyMetadataEntry {
    k: string | symbol;
    v: any;
  }

  function getMetadataTypeString(t: MetaDataType): string {
    switch (t) {
      case MetaDataType.PropertyValidator:
        return '__@tide/meta__/valid';
      case MetaDataType.PropertyFormat:
        return '__@tide/meta__/format';
      default:
        return '__@tide/meta__';
    }
  }

  // export function getMetadata(type: MetaDataType, instance: Object): TIDEMetadata {
  //   return Object.getPrototypeOf(instance).constructor[getMetadataTypeString(type)];
  // }

  export function getPropertyMetadata(type: MetaDataType, instance: Object, property: string): TIDEMetadata {
    return Object.getPrototypeOf(instance).constructor[getMetadataTypeString(type)].get(property);
  }

  export function setPropertyMetadata( type: MetaDataType, sourceProto: any, entry: TIDEMetadataEntry) {
    if (!entry || !sourceProto || !sourceProto.constructor) {
      return;
    }
    const metaKey = getMetadataTypeString(type);
    const ctor = sourceProto.constructor;
    const meta: TIDEMetadata = ctor.hasOwnProperty(metaKey)
      ? (ctor as any)[metaKey]
      : Object.defineProperty(ctor, metaKey, { value: new Map() })[
        getMetadataTypeString(type)
        ];
    meta.has(entry.k)
      ? (meta.get(entry.k) || new Map()).set(entry.v.k, entry.v.v)
      : meta.set(entry.k, new Map().set(entry.v.k, entry.v.v));
  }
}
