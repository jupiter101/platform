// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

export namespace Buffers {
  export interface Buffer {
    [offset: number]: number;
    length: number;
  }
}
