// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Randoms} from './randoms';

export namespace UUIDS {
  const UUID_SIZE = 16;
  export const create = () => {
    const data = Randoms.generateRandomBytes(UUID_SIZE);
    // mark as random - RFC 4122 § 4.4
    data[6] = data[6] & 0x4f | 0x40;
    data[8] = data[8] & 0xbf | 0x80;
    let result = '';
    for (let offset = 0; offset < UUID_SIZE; ++offset) {
      const byte = data[offset];
      if (offset === 4 || offset === 6 || offset === 8) result += '-';
      if (byte < 16) result += '0';
      result += byte.toString(16).toLowerCase();
    }
    return result;
  };
}
