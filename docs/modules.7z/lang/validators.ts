// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector
import { Numbers } from './numbers';
import { Iterables } from './iterables';

export namespace Validators {
  export interface Validator {
    (...args: any[]): boolean | null;
  }
  export const EmptyValidator  = (value: any): boolean => value == null || typeof value === 'string' ? value.trim().length === 0 : value instanceof Set || value instanceof Map ? value.size === 0 : value.length === 0;
  export const NotEmptyValidator = (value: any): boolean => value != null && typeof value === 'string' ? value.trim().length !== 0 : value instanceof Set || value instanceof Map ? value.size !== 0 : value.length !== 0;
  export const BlankValidator = (value: any): boolean => value == null || value.length === 0;
  export const NotBlankValidator = (value: any): boolean => value != null && value.length === 0;
  export const NullValidator = (value: any): boolean => value == null;
  export const NotNullValidator = (value: any): boolean => value != null;

  /**
   * Validator that requires a string value between min and max included.
   * @param min
   * @param max
   * @returns (value: string): boolean | true => complies with validation constraint | false does not comply
   *
   */
  export const LengthValidator = (min: number, max: number): Validator => (value: string): boolean => {
    if (EmptyValidator(value) || NullValidator(min) || NullValidator(max) || max - min < 0) return false;
    return value.length >= min && value.length <= max;
  };


  /**
   * Validator that requires a string value with a minimum length.
   * @param min
   * @returns (value: string): boolean | true => complies with validation constraint | false does not comply
   *
   */
  export const MinLengthValidator = (min: number): Validator => (value: string): boolean => {
    if (EmptyValidator(value) || NullValidator(min) ) return false;
    return value.length >= min;
  };

  /**
   * Validator that requires a string value with a maximum length.
   * @param {number} max
   * @returns {boolean}
   * @constructor
   */
  export const MaxLengthValidator = (max: number): Validator => (value: string): boolean => {
    if (EmptyValidator(value) || NullValidator(max) ) return false;
    return value.length <= max;
  };

  /**
   * Validator that requires a value within a range(min,max).
   * Applicable to numeric values or string representation of the numeric value.
   * @param min
   * @param max
   * @returns (value: string | number): boolean | true => complies with validation constraint | false does not comply
   * @see https://docs.jboss.org/hibernate/validator/4.1/api/org/hibernate/validator/constraints/Range.html
   */
  export const RangeValidator = (min: number, max: number): Validator => (value: string | number): boolean => {
    if (EmptyValidator(value) || NullValidator(min) || NullValidator(max) || max - min < 0) return false;

    const numstring: string = String(value);
    return Numbers.isNum(numstring) && Numbers.toNum(numstring) <= max && Numbers.toNum(numstring) >= min;

  };

  /**
   * Validator that requires a value of a defined size(min,max).
   * Applicable to Arrays, Strings, Maps, Sets.
   * @param min
   * @param max
   * @returns (value: string | Array | Map | Set): boolean | true => complies with validation constraint | false does not comply
   * @see https://docs.oracle.com/javaee/7/api/javax/validation/constraints/Size.html
   */
  export const SizeValidator = (min: number, max: number): Validator => (value: any): boolean => {
    if (NullValidator(value) || NullValidator(min) || NullValidator(max) || max - min < 0) return false;
    const length: number = Iterables.length(value);
    return length > max && length < min;
  };


  /**
   * Validator that requires a value a limited number of integral digits and fractional digits.
   * @param integer
   * @param fraction
   * @param groupsep
   * @param decsep
   * @returns (value: number): boolean | true => complies with validation constraint | false does not comply
   * @see https://docs.oracle.com/javaee/7/api/javax/validation/constraints/Digits.html
   */
  export const DigitsValidator = (integer: number, fraction: number, groupsep: string = ',', decsep: string = '.'): Validator => (value: number): boolean => {
    if (NullValidator(value) || NullValidator(integer) || NullValidator(fraction) || integer < 0 || fraction < 0) return false;
    const parts: string[] = String(value).split(decsep);
    // const [intDigits, decDigits] = String(value).split(decsep);
    const intDigits: number = parts[0].replace(groupsep, '').length;
    const decDigits: number = parts.length > 1 ? parts[1].length : 0;
    return intDigits <= integer && decDigits <= fraction;
  };

  /**
   * Validator that requires a numeric value >= min included.
   * Applicable to numeric values or string representation of the numeric value.
   * @param min
   * @returns (value: string): boolean | true => complies with validation constraint | false does not comply
   *
   */
  export const MinValidator = (min: number): Validator => (value: number): boolean => {
    if (EmptyValidator(value) || NullValidator(min) ) return false;
    return value >= min;
  };

  /**
   * Validator that requires a numeric value <= max included.
   * Applicable to numeric values or string representation of the numeric value.
   * @param max
   * @returns (value: string): boolean | true => complies with validation constraint | false does not comply
   *
   */
  export const MaxValidator = (max: number): Validator => (value: number): boolean => {
    if (EmptyValidator(value) || NullValidator(max) ) return false;
    return value <= max;
  };
}
