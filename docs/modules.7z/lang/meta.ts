// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
import { Types } from './types';
import {Maps} from './maps';
import {Sets} from './sets';
import {Iterators} from './iterators';


export namespace Meta {
  import Map = Maps.Map;

  /**
   * [[Metadata]] internal slot
   * All ordinary objects have an internal slot called [[Metadata]].
   * The value of this internal slot is either null or a Map object and is used for storing metadata for an object.
   */
  const Metadata = new Maps.__WeakMap<any, Map<string | symbol | undefined, Map<any, any>>>();

  /**
   * Define a unique metadata entry on the target.
   * @param metadataKey A key used to store and retrieve metadata.
   * @param metadataValue A value that contains attached metadata.
   * @param target The target object on which to define metadata.
   * @param propertyKey (Optional) The property key for the target.
   * @example
   *
   *     class Example {
   *         // property declarations are not part of ES6, though they are valid in TypeScript:
   *         // static staticProperty;
   *         // property;
   *
   *         constructor(p) { }
   *         static staticMethod(p) { }
   *         method(p) { }
   *     }
   *
   *     // constructor
   *     TS.Meta.defineMetadata("custom:annotation", options, Example);
   *
   *     // property (on constructor)
   *     TS.Meta.defineMetadata("custom:annotation", options, Example, "staticProperty");
   *
   *     // property (on prototype)
   *     TS.Meta.defineMetadata("custom:annotation", options, Example.prototype, "property");
   *
   *     // method (on constructor)
   *     TS.Meta.defineMetadata("custom:annotation", options, Example, "staticMethod");
   *
   *     // method (on prototype)
   *     TS.Meta.defineMetadata("custom:annotation", options, Example.prototype, "method");
   *
   *     // decorator factory as metadata-producing annotation.
   *     function MyAnnotation(options): Decorator {
   *         return (target, key?) => TS.Meta.defineMetadata("custom:annotation", options, target, key);
   *     }
   *
   */
  export function defineMetadata(metadataKey: any, metadataValue: any, target: any, propertyKey?: string | symbol): void {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    return __defineOwnMetadata(metadataKey, metadataValue, target, propertyKey);
  }

  /**
   * Gets a value indicating whether the target object or its prototype chain has the provided metadata key defined.
   * @param metadataKey A key used to store and retrieve metadata.
   * @param target The target object on which the metadata is defined.
   * @param propertyKey (Optional) The property key for the target.
   * @returns `true` if the metadata key was defined on the target object or its prototype chain; otherwise, `false`.
   * @example
   *
   *     class Example {
   *         // property declarations are not part of ES6, though they are valid in TypeScript:
   *         // static staticProperty;
   *         // property;
   *
   *         constructor(p) { }
   *         static staticMethod(p) { }
   *         method(p) { }
   *     }
   *
   *     // constructor
   *     result = TS.Meta.hasMetadata("custom:annotation", Example);
   *
   *     // property (on constructor)
   *     result = TS.Meta.hasMetadata("custom:annotation", Example, "staticProperty");
   *
   *     // property (on prototype)
   *     result = TS.Meta.hasMetadata("custom:annotation", Example.prototype, "property");
   *
   *     // method (on constructor)
   *     result = TS.Meta.hasMetadata("custom:annotation", Example, "staticMethod");
   *
   *     // method (on prototype)
   *     result = TS.Meta.hasMetadata("custom:annotation", Example.prototype, "method");
   *
   */
  export function hasMetadata(metadataKey: any, target: any, propertyKey?: string | symbol): boolean {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    return __hasMetadata(metadataKey, target, propertyKey);
  }

  /**
   * Gets the metadata value for the provided metadata key on the target object or its prototype chain.
   * @param metadataKey A key used to store and retrieve metadata.
   * @param target The target object on which the metadata is defined.
   * @param propertyKey (Optional) The property key for the target.
   * @returns The metadata value for the metadata key if found; otherwise, `undefined`.
   * @example
   *
   *     class Example {
   *         // property declarations are not part of ES6, though they are valid in TypeScript:
   *         // static staticProperty;
   *         // property;
   *
   *         constructor(p) { }
   *         static staticMethod(p) { }
   *         method(p) { }
   *     }
   *
   *     // constructor
   *     result = TS.Meta.getMetadata("custom:annotation", Example);
   *
   *     // property (on constructor)
   *     result = TS.Meta.getMetadata("custom:annotation", Example, "staticProperty");
   *
   *     // property (on prototype)
   *     result = TS.Meta.getMetadata("custom:annotation", Example.prototype, "property");
   *
   *     // method (on constructor)
   *     result = TS.Meta.getMetadata("custom:annotation", Example, "staticMethod");
   *
   *     // method (on prototype)
   *     result = TS.Meta.getMetadata("custom:annotation", Example.prototype, "method");
   *
   */
  export function getMetadata(metadataKey: any, target: any, propertyKey?: string | symbol): any {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    return __getMetadata(metadataKey, target, propertyKey);
  }

  /**
   * Deletes the metadata entry from the target object with the provided key.
   * @param metadataKey A key used to store and retrieve metadata.
   * @param target The target object on which the metadata is defined.
   * @param propertyKey (Optional) The property key for the target.
   * @returns `true` if the metadata entry was found and deleted; otherwise, false.
   * @example
   *
   *     class Example {
   *         // property declarations are not part of ES6, though they are valid in TypeScript:
   *         // static staticProperty;
   *         // property;
   *
   *         constructor(p) { }
   *         static staticMethod(p) { }
   *         method(p) { }
   *     }
   *
   *     // constructor
   *     result = Reflect.deleteMetadata("custom:annotation", Example);
   *
   *     // property (on constructor)
   *     result = TS.Meta.deleteMetadata("custom:annotation", Example, "staticProperty");
   *
   *     // property (on prototype)
   *     result = TS.Meta.deleteMetadata("custom:annotation", Example.prototype, "property");
   *
   *     // method (on constructor)
   *     result = TS.Meta.deleteMetadata("custom:annotation", Example, "staticMethod");
   *
   *     // method (on prototype)
   *     result = TS.Meta.deleteMetadata("custom:annotation", Example.prototype, "method");
   *
   */
  export function deleteMetadata(metadataKey: any, target: any, propertyKey?: string | symbol): boolean {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    const metadataMap = __getMetadataMap(target, propertyKey, /*Create*/ false);
    if (Types.isUndefined(metadataMap)) return false;
    if (!metadataMap.delete(metadataKey)) return false;
    if (metadataMap.size > 0) return true;
    const targetMetadata = Metadata.get(target);
    targetMetadata.delete(propertyKey);
    if (targetMetadata.size > 0) return true;
    Metadata.delete(target);
    return true;
  }

  /**
   * Gets the unique metadata keys defined on the target object.
   * @param target The target object on which the metadata is defined.
   * @param propertyKey (Optional) The property key for the target.
   * @returns An array of unique metadata keys.
   * @example
   *
   *     class Example {
   *         // property declarations are not part of ES6, though they are valid in TypeScript:
   *         // static staticProperty;
   *         // property;
   *
   *         constructor(p) { }
   *         static staticMethod(p) { }
   *         method(p) { }
   *     }
   *
   *     // constructor
   *     result = TS.Meta.getOwnMetadataKeys(Example);
   *
   *     // property (on constructor)
   *     result = TS.Meta.getOwnMetadataKeys(Example, "staticProperty");
   *
   *     // property (on prototype)
   *     result = TS.Meta.getOwnMetadataKeys(Example.prototype, "property");
   *
   *     // method (on constructor)
   *     result = TS.Meta.getOwnMetadataKeys(Example, "staticMethod");
   *
   *     // method (on prototype)
   *     result = TS.Meta.getOwnMetadataKeys(Example.prototype, "method");
   *
   */
  export function getMetadataKeys(target: any, propertyKey?: string | symbol): any[] {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    return __metadataKeys(target, propertyKey);
  }

  /**
   * Gets the unique metadata keys defined on the target object.
   * @param target The target object on which the metadata is defined.
   * @param propertyKey (Optional) The property key for the target.
   * @returns An array of unique metadata keys.
   * @example
   *
   *     class Example {
      *         // property declarations are not part of ES6, though they are valid in TypeScript:
      *         // static staticProperty;
      *         // property;
      *
      *         constructor(p) { }
      *         static staticMethod(p) { }
      *         method(p) { }
      *     }
   *
   *     // constructor
   *     result = Reflect.getOwnMetadataKeys(Example);
   *
   *     // property (on constructor)
   *     result = Reflect.getOwnMetadataKeys(Example, "staticProperty");
   *
   *     // property (on prototype)
   *     result = Reflect.getOwnMetadataKeys(Example.prototype, "property");
   *
   *     // method (on constructor)
   *     result = Reflect.getOwnMetadataKeys(Example, "staticMethod");
   *
   *     // method (on prototype)
   *     result = Reflect.getOwnMetadataKeys(Example.prototype, "method");
   *
   */
  export function getOwnMetadataKeys(target: any, propertyKey?: string | symbol): any[] {
    if (!Types.isObject(target)) throw new TypeError();
    if (!Types.isUndefined(propertyKey)) propertyKey = Types.Converter.toPropertyKey(propertyKey);
    return __ownMetadataKeys(target, propertyKey);
  }

  /**
   * Tests for available metadata assigned to own or inherited  property.
   * @param key Metadata key
   * @param target object
   * @param property key
   * @returns 'true' if the target holds the property.
   * @private
   */
  function __hasMetadata(key: any, target: any, property: string | symbol | undefined): boolean {
    const hasOwn = __hasOwnMetadata(key, target, property);
    if (hasOwn) return true;
    const parent = __getPrototypeOf(target);
    if (!Types.isNull(parent)) return __hasMetadata(key, parent, property);
    return false;
  }

  /**
   * Tests for available metadata assigned to own property.
   * @param key Metadata key
   * @param target object
   * @param property key
   * @returns 'true' if the target holds the property.
   * @private
   */
  function __hasOwnMetadata(key: any, target: any, property: string | symbol | undefined): boolean {
    const metadataMap = __getMetadataMap(target, property, /*Create*/ false);
    if (Types.isUndefined(metadataMap)) return false;
    return Types.Converter.toBoolean(metadataMap.has(key));
  }

  /**
   * Retrieve available metadata assigned to own or inherited  property.
   * @param key Metadata key
   * @param target object
   * @param property key
   * @returns {any}
   * @private
   */
  function __getMetadata(key: any, target: any, property: string | symbol | undefined): any {
    const hasOwn = __hasOwnMetadata(key, target, property);
    if (hasOwn) return __getOwnMetadata(key, target, property);
    const parent = __getPrototypeOf(target);
    if (!Types.isNull(parent)) return __getMetadata(key, parent, property);
    return undefined;
  }

  /**
   * Retrieve available metadata assigned to own property.
   * @param key Metadata key
   * @param target object
   * @param property key
   * @returns {any}
   * @private
   */
  function __getOwnMetadata(key: any, target: any, property: string | symbol | undefined): any {
    const metadataMap = __getMetadataMap(target, property, /*Create*/ false);
    if (Types.isUndefined(metadataMap)) return undefined;
    return metadataMap.get(key);
  }

  /**
   * Defines metadata assigned to own property.
   * @param key
   * @param value
   * @param target
   * @param property
   * @private
   */
  function __defineOwnMetadata(key: any, value: any, target: any, property: string | symbol | undefined): void {
    const metadataMap = __getMetadataMap(target, property, /*Create*/ true);
    metadataMap.set(key, value);
  }

  /**
   * Retrieves metadata keys for targets own or inherited property.
   * @param target
   * @param property
   * @returns any[]
   * @private
   */
  function __metadataKeys(target: any, property: string | symbol | undefined): any[] {
    const ownKeys = __ownMetadataKeys(target, property);
    const parent = __getPrototypeOf(target);
    if (parent === null) return ownKeys;
    const parentKeys = __metadataKeys(parent, property);
    if (parentKeys.length <= 0) return ownKeys;
    if (ownKeys.length <= 0) return parentKeys;
    const set = new Sets.__Set<any>();
    const keys: any[] = [];
    for (const key of ownKeys) {
      const hasKey = set.has(key);
      if (!hasKey) {
        set.add(key);
        keys.push(key);
      }
    }
    for (const key of parentKeys) {
      const hasKey = set.has(key);
      if (!hasKey) {
        set.add(key);
        keys.push(key);
      }
    }
    return keys;
  }

  /**
   * etrieves metadata keys for targets own property.
   * @param target
   * @param {string | symbol} property
   * @returns {any[]}
   * @private
   */
  function __ownMetadataKeys(target: any, property: string | symbol | undefined): any[] {
    const keys: any[] = [];
    const metadataMap = __getMetadataMap(target, property, /*Create*/ false);
    if (Types.isUndefined(metadataMap)) return keys;
    const keysObj = metadataMap.keys();
    const iterator = Iterators.GetIterator(keysObj);
    let k = 0;
    while (true) {
      const next = Iterators.IteratorStep(iterator);
      if (!next) {
        keys.length = k;
        return keys;
      }
      const nextValue = Iterators.IteratorValue(next);
      try {
        keys[k] = nextValue;
      }
      catch (e) {
        try {
          Iterators.IteratorClose(iterator);
        }
        finally {
          throw e;
        }
      }
      k++;
    }
  }

  /**
   * Retrieves object prototype.
   * @param O
   * @returns {any}
   * @private
   * @see https://tc39.github.io/ecma262/#sec-ordinarygetprototypeof
   */
  function __getPrototypeOf(target: any): any {
    const proto = Object.getPrototypeOf(target);
    if (typeof target !== 'function' || target === Types.FunctionPrototype) return proto;

    // TypeScript doesn't set __proto__ in ES5, as it's non-standard.
    // Try to determine the superclass constructor. Compatible implementations
    // must either set __proto__ on a subclass constructor to the superclass constructor,
    // or ensure each class has a valid `constructor` property on its prototype that
    // points back to the constructor.

    // If this is not the same as Function.[[Prototype]], then this is definately inherited.
    // This is the case when in ES6 or when using __proto__ in a compatible browser.
    if (proto !== Types.FunctionPrototype) return proto;

    // If the super prototype is Object.prototype, null, or undefined, then we cannot determine the heritage.
    const prototype = target.prototype;
    const prototypeProto = prototype && Object.getPrototypeOf(prototype);
    if (prototypeProto == null || prototypeProto === Object.prototype) return proto;

    // If the constructor was not a function, then we cannot determine the heritage.
    const constructor = prototypeProto.constructor;
    if (typeof constructor !== 'function') return proto;

    // If we have some kind of self-reference, then we cannot determine the heritage.
    if (constructor === target) return proto;

    // we have a pretty good guess at the heritage.
    return constructor;
  }

  /**
   * Gets the Metadata map and if not available, creates it.
   * @param O
   * @param P
   * @param Create
   * @returns Map<any, any>
   * @private
   */
  function __getMetadataMap(target: any, property: string | symbol | undefined, Create: boolean): Map<any, any> | undefined {
    let targetMetadata = Metadata.get(target);
    if (Types.isUndefined(targetMetadata)) {
      if (!Create) return undefined;
      targetMetadata = new Maps.__Map<string | symbol | undefined, Maps.Map<any, any>>();
      Metadata.set(target, targetMetadata);
    }
    let metadataMap = targetMetadata.get(property);
    if (Types.isUndefined(metadataMap)) {
      if (!Create) return undefined;
      metadataMap = new Maps.__Map<any, any>();
      targetMetadata.set(property, metadataMap);
    }
    return metadataMap;
  }

}

