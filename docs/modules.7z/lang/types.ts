// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types
// tslint:disable:import-spacing
// tslint:disable:component-selector

import {Support} from './support';

/**
 * ECMAScript type helper
 * @see https://tc39.github.io/ecma262/#sec-ecmascript-language-types
 */
export namespace Types {

  declare const Symbol: { iterator: symbol, toPrimitive: symbol};
  export const ToPrimitiveSymbol = Support.Types.Symbols && typeof Symbol.toPrimitive !== 'undefined' ? Symbol.toPrimitive : '@@toPrimitive';
  // export const ToStringTagSymbol = Support.Types.Symbols && typeof Symbol.toStringTag !== 'undefined' ? Symbol.toStringTag : '@@toStringTag';
  export const IteratorSymbol = Support.Types.Symbols && typeof Symbol.iterator !== 'undefined' ? Symbol.iterator : '@@iterator';


  export const FunctionPrototype = Object.getPrototypeOf(Function);

  /**
   * ECMAScript Language Types
   */
  export const enum Tag {
    Undefined,
    Null,
    Boolean,
    String,
    Symbol,
    Number,
    Object
  }

  /**
   * ECMAScript Data Types and Values
   * @param x
   * @returns
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-ecmascript-data-types-and-values
   */
  export function Type(x: any): Tag {
    if (x === null) return Tag.Null;
    switch (typeof x) {
      case 'undefined': return Tag.Undefined;
      case 'boolean': return Tag.Boolean;
      case 'string': return Tag.String;
      case 'symbol': return Tag.Symbol;
      case 'number': return Tag.Number;
      case 'object': return x === null ? Tag.Null : Tag.Object;
      default: return Tag.Object;
    }
  }

  /**
   * The Undefined Type
   * @param x
   * @returns
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-ecmascript-language-types-undefined-type
   */
  export const isUndefined = (x: any): x is undefined => x === undefined;

  /**
   * The Null Type
   * @param x
   * @returns
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-ecmascript-language-types-null-type
   */
  export const isNull = (x: any): x is null => x === null;

  /**
   * The Symbol Type
   * @param x
   * @returns
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-ecmascript-language-types-symbol-type
   */
  export const isSymbol = (x: any): x is symbol => typeof x === 'symbol';

  /**
   * The Object Type
   * @param {boolean | string | symbol | number | T} x
   * @returns
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-object-type
   */
  export const isObject = <T>(x: T | undefined | null | boolean | string | symbol | number): x is T => {
    return typeof x === 'object' ? x !== null : typeof x === 'function';
  };

  /**
   * ECMAScript Testing and Comparison class
   * @see https://tc39.github.io/ecma262/#sec-testing-and-comparison-operations
   */
  export class Comparer {
    /**
     * The operation isArray takes one argument.
     * @param argument
     * @returns argument is any[]
     *
     * @see https://tc39.github.io/ecma262/#sec-isarray
     */
    static isArray(argument: any): argument is any[] {
      return Array.isArray
        ? Array.isArray(argument)
        : argument instanceof Object
          ? argument instanceof Array
          : Object.prototype.toString.call(argument) === '[object Array]';
    }

    /**
     * The abstract operation IsCallable determines if argument, which must be
     * an ECMAScript language value, is a callable function with a [[Call]] internal method.
     * NOTE: This is an approximation as we cannot check for [[Call]] internal method is not possible.
     * @param argument
     * @returns argument is Function
     *
     * @see https://tc39.github.io/ecma262/#sec-iscallable
     */
    static isCallable(argument: any): argument is Function {
      return typeof argument === 'function';
    }

    /**
     * The abstract operation IsConstructor determines if argument, which must be
     * an ECMAScript language value, is a function object with a [[Construct]] internal method.
     * NOTE: This is an approximation as we cannot check for [[Construct]] internal method is not possible.
     * @param argument
     * @returns argument is Function
     *
     * @see https://tc39.github.io/ecma262/#sec-isconstructor
     */
    static isConstructor(argument: any): argument is Function {
      return typeof argument === 'function';
    }

    // 7.2.7 IsPropertyKey(argument)
    // https://tc39.github.io/ecma262/#sec-ispropertykey
    /**
     * The abstract operation IsPropertyKey determines if argument, which must be
     * an ECMAScript language value, is a value that may be used as a property key.
     * @param argument
     * @returns argument is string | symbol
     *
     * @see https://tc39.github.io/ecma262/#sec-ispropertykey
     */
    static isPropertyKey(argument: any): argument is string | symbol {
      switch (Type(argument)) {
        case Tag.String: return true;
        case Tag.Symbol: return true;
        default: return false;
      }
    }
  }

  /**
   * The operation getMethod is used to get the value of a specific property of
   * an ECMAScript language value when the value of the property is expected to be a function.
   * The operation is called with arguments V and P where V is the ECMAScript language value,
   * P is the property key.
   * @param V
   * @param P
   * @returns {Function}
   * @constructor
   *
   * @see https://tc39.github.io/ecma262/#sec-getmethod
   */
  export function getMethod(V: any, P: any): Function | undefined {
    const func = V[P];
    if (func === undefined || func === null) return undefined;
    if (!Comparer.isCallable(func)) throw new TypeError();
    return func;
  }

  /**
   * ECMAScript Type conversion class
   * @see https://tc39.github.io/ecma262/#sec-type-conversion
   */
  export class Converter {
    /**
     * The operation toPrimitive converts its input argument to a non-Object type.
     * If an object is capable of converting to more than one primitive type, it may use the
     * optional hint PreferredType to favour that type.
     * @param input
     * @param PreferredType
     * @returns boolean | string | symbol | number
     *
     * @see https://tc39.github.io/ecma262/#sec-toprimitive
     */
    static toPrimitive(input: any, PreferredType?: Tag): undefined | null | boolean | string | symbol | number {
      switch (Type(input)) {
        case Tag.Undefined: return input;
        case Tag.Null: return input;
        case Tag.Boolean: return input;
        case Tag.String: return input;
        case Tag.Symbol: return input;
        case Tag.Number: return input;
      }
      const hint: 'string' | 'number' | 'default' = PreferredType === Tag.String ? 'string' : PreferredType === Tag.Number ? 'number' : 'default';
      const exoticToPrim = getMethod(input, ToPrimitiveSymbol);
      if (exoticToPrim !== undefined) {
        const result = exoticToPrim.call(input, hint);
        if (isObject(result)) throw new TypeError();
        return result;
      }
      return Converter.ordinaryToPrimitive(input, hint === 'default' ? 'number' : hint);
    }

    /**
     * The operation toBoolean converts argument to a value of type Boolean
     * @param argument
     * @returns boolean
     *
     * @see https://tc39.github.io/ecma262/#sec-toboolean
     * @see https://tc39.github.io/ecma262/#table-10
     */
    static toBoolean(argument: any): boolean {
      return !!argument;
    }

    /**
     * The operation toString converts argument to a value of type String.
     * @param argument
     * @returns string
     *
     * @see https://tc39.github.io/ecma262/#sec-tostring
     * @see https://tc39.github.io/ecma262/#table-12
     */
    static toString(argument: any): string {
      return '' + argument;
    }

    /**
     * The operation toPropertyKey converts argument to a value that can be used as a property key.
     * @param argument
     * @returns string | symbol
     *
     * @see https://tc39.github.io/ecma262/#sec-topropertykey
     */
    static toPropertyKey(argument: any): string | symbol {
      const key = Converter.toPrimitive(argument, Tag.String);
      if (isSymbol(key)) return key;
      return Converter.toString(key);
    }

    /**
     * Standard toPrimitive conversion method.
     * @param O
     * @param hint
     * @returns boolean | string | symbol | number
     * @see https://tc39.github.io/ecma262/#sec-ordinarytoprimitive
     */
    private static ordinaryToPrimitive(O: any, hint: 'string' | 'number'): undefined | null | boolean | string | symbol | number {
      if (hint === 'string') {
        const toString = O.toString;
        if (Comparer.isCallable(toString)) {
          const result = toString.call(O);
          if (!isObject(result)) return result;
        }
        const valueOf = O.valueOf;
        if (Comparer.isCallable(valueOf)) {
          const result = valueOf.call(O);
          if (!isObject(result)) return result;
        }
      }
      else {
        const valueOf = O.valueOf;
        if (Comparer.isCallable(valueOf)) {
          const result = valueOf.call(O);
          if (!isObject(result)) return result;
        }
        const toString = O.toString;
        if (Comparer.isCallable(toString)) {
          const result = toString.call(O);
          if (!isObject(result)) return result;
        }
      }
      throw new TypeError();
    }
  }
}
