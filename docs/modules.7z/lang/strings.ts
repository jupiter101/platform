// tslint:disable:no-trailing-whitespace
// tslint:disable:no-inferrable-types

/**
 * Helper for string object.
 *
 * TODO use of destructuring for Array.from
 */
export namespace Strings {
  /**
   * Converts string to real array.
   * Strings are is array-like but no real arrays.
   * @param {string} value
   * TODO Fix Angular 5.0 compiler(ngc) error: the type annotation on @param is redundant with its TypeScript type, remove the {...} part
   */
  export const toArray = (value: string) => Array.from(value);
  export const removeSuffix = (value: string, suffix: string) => value.endsWith(suffix) ? value.substring(0, value.length - suffix.length) : value;
}

